package com.example.data

import com.example.model.Achievement
import com.example.model.Arena
import com.example.model.Enemy
import com.example.model.EnemyBehavior
import com.example.model.MasteryLevel
import com.example.model.PlayerSaveData
import com.example.model.Wand
import com.example.model.WandTrait
import kotlin.random.Random

object ArenaCatalog {
  val arenas: List<Arena> = listOf(
    Arena(
      id = "arena_courtyard",
      name = "Sanctum Courtyard",
      subtitle = "Neutral dueling stone with balanced arcane currents.",
      attackModifier = 0,
      shieldModifier = 0
    ),
    Arena(
      id = "arena_cloister",
      name = "Obsidian Cloister",
      subtitle = "Shadowed pillars amplify offensive bolts (+3 Attack).",
      attackModifier = 3,
      shieldModifier = 0
    ),
    Arena(
      id = "arena_bastion",
      name = "Aegis Conservatory",
      subtitle = "Runed marble reinforces protective barriers (+4 Shield).",
      attackModifier = 0,
      shieldModifier = 4
    ),
    Arena(
      id = "arena_crypt",
      name = "Forbidden Crypt",
      subtitle = "Volatile ley lines surge with raw destructive force (+5 Attack).",
      attackModifier = 5,
      shieldModifier = -2
    )
  )
}

object EnemyCatalog {
  val enemies: List<Enemy> = listOf(
    Enemy(
      id = "de_acolyte",
      name = "Rookwood Acolyte",
      title = "Stage I · Fast Striker",
      stageNumber = 1,
      maxHp = 85,
      attack = 2,
      defense = 1,
      reactionDelayMs = 1100L,
      availableSpellIds = listOf("lumos_spark", "stupefy", "flipendo", "protego"),
      difficulty = 1,
      behavior = EnemyBehavior.FAST_ATTACKER,
      description = "Swift apprentice who probes defenses with low-cooldown kinetic bolts."
    ),
    Enemy(
      id = "de_pyromancer",
      name = "Dolohov Pyromancer",
      title = "Stage II · Aggressive",
      stageNumber = 2,
      maxHp = 105,
      attack = 4,
      defense = 2,
      reactionDelayMs = 1050L,
      availableSpellIds = listOf("incendio", "confringo", "ignis_flare", "stupefy", "episkey"),
      difficulty = 2,
      behavior = EnemyBehavior.AGGRESSIVE,
      description = "Relentless fire-caster stacking sustained Burn damage every round."
    ),
    Enemy(
      id = "de_wardbreaker",
      name = "Selwyn Wardkeeper",
      title = "Stage III · Defensive",
      stageNumber = 3,
      maxHp = 125,
      attack = 3,
      defense = 4,
      reactionDelayMs = 1000L,
      availableSpellIds = listOf("protego", "protego_maxima", "episkey", "glacius", "expelliarmus"),
      difficulty = 3,
      behavior = EnemyBehavior.DEFENSIVE,
      description = "Methodical duelist raising layered barriers and mending injuries under pressure."
    ),
    Enemy(
      id = "de_hexer",
      name = "Lestrange Counter-Hexer",
      title = "Stage IV · Counter-Focused",
      stageNumber = 4,
      maxHp = 145,
      attack = 5,
      defense = 3,
      reactionDelayMs = 950L,
      availableSpellIds = listOf("confundo", "petrificus", "expelliarmus", "glacius", "protego", "sectum_slash"),
      difficulty = 4,
      behavior = EnemyBehavior.COUNTER_FOCUSED,
      description = "Tactical enforcer dismantling wards with Stun, Weaken, and Control charms."
    ),
    Enemy(
      id = "de_lord_shadow",
      name = "Vespera the Arch-Wraith",
      title = "Stage V · Heavy Attacker",
      stageNumber = 5,
      maxHp = 175,
      attack = 7,
      defense = 5,
      reactionDelayMs = 900L,
      availableSpellIds = listOf("crucio_umbra", "oblivion_fracture", "fiendfyre_coil", "aegis_maxima", "vulnera_sanentur", "arcane_nova"),
      difficulty = 5,
      behavior = EnemyBehavior.HEAVY_ATTACKER,
      description = "High-command Death Eater duelist channeling devastating Forbidden and Nova arts."
    )
  )
}

object WandCatalog {
  val wands: List<Wand> = listOf(
    Wand(
      id = "wand_oak_phoenix",
      name = "Oak & Phoenix",
      wood = "English Oak",
      core = "Phoenix Feather",
      description = "Balanced academy wand prized by loyal duelists for crisp offensive focus.",
      castingAccuracyBonus = 4,
      manaEfficiencyPercent = 8,
      spellPowerBonus = 4,
      castingSpeed = 7,
      cooldownReduction = 0,
      maxHpBonus = 5,
      maxManaBonus = 5,
      passiveTrait = WandTrait.SOLAR_FOCUS,
      primaryColorHex = 0xFF8B5A2B,
      secondaryColorHex = 0xFF5C3A1B,
      coreGlowColorHex = 0xFFFFB74D
    ),
    Wand(
      id = "wand_willow_unicorn",
      name = "Willow & Unicorn",
      wood = "Weeping Willow",
      core = "Unicorn Tail Hair",
      description = "Supple restorative wand attuned to healing charms and enduring vitality.",
      castingAccuracyBonus = 5,
      manaEfficiencyPercent = 10,
      spellPowerBonus = 2,
      castingSpeed = 6,
      cooldownReduction = 0,
      maxHpBonus = 15,
      maxManaBonus = 10,
      passiveTrait = WandTrait.VITAL_BLOOM,
      primaryColorHex = 0xFF9E8A63,
      secondaryColorHex = 0xFF6B5B3E,
      coreGlowColorHex = 0xFFE0F7FA
    ),
    Wand(
      id = "wand_yew_dragon",
      name = "Yew & Dragonheart",
      wood = "Carved Yew",
      core = "Dragon Heartstring",
      description = "Fierce crimson-grain wand built for devastating critical offensive strikes.",
      castingAccuracyBonus = 2,
      manaEfficiencyPercent = 4,
      spellPowerBonus = 6,
      castingSpeed = 6,
      cooldownReduction = 0,
      maxHpBonus = 5,
      maxManaBonus = 0,
      passiveTrait = WandTrait.SHADOW_PIERCE,
      primaryColorHex = 0xFF6E2C23,
      secondaryColorHex = 0xFF421812,
      coreGlowColorHex = 0xFFFF7043
    ),
    Wand(
      id = "wand_elder_astral",
      name = "Elder & Astral",
      wood = "Silver Elder",
      core = "Astral Crystal",
      description = "Storied sanctum relic granting swift cooldown recovery and celestial Mana flow.",
      castingAccuracyBonus = 4,
      manaEfficiencyPercent = 14,
      spellPowerBonus = 4,
      castingSpeed = 7,
      cooldownReduction = 1,
      maxHpBonus = 0,
      maxManaBonus = 15,
      passiveTrait = WandTrait.CHRONO_SPARK,
      primaryColorHex = 0xFF7B776F,
      secondaryColorHex = 0xFF4D4A44,
      coreGlowColorHex = 0xFF80DEEA
    ),
    Wand(
      id = "wand_cypress_griffin",
      name = "Cypress & Griffin",
      wood = "Ancient Cypress",
      core = "Griffin Talon",
      description = "Steadies the caster's focus for superior spell recognition accuracy.",
      castingAccuracyBonus = 8,
      manaEfficiencyPercent = 8,
      spellPowerBonus = 3,
      castingSpeed = 7,
      cooldownReduction = 0,
      maxHpBonus = 5,
      maxManaBonus = 5,
      passiveTrait = WandTrait.RUNE_PRECISION,
      primaryColorHex = 0xFF7D6242,
      secondaryColorHex = 0xFF4F3C26,
      coreGlowColorHex = 0xFFFFD54F
    ),
    Wand(
      id = "wand_holly_ember",
      name = "Holly & Ember",
      wood = "Winter Holly",
      core = "Ember Feather",
      description = "Responsive guardian wand reinforcing protective barriers in tense duels.",
      castingAccuracyBonus = 5,
      manaEfficiencyPercent = 10,
      spellPowerBonus = 3,
      castingSpeed = 8,
      cooldownReduction = 0,
      maxHpBonus = 10,
      maxManaBonus = 5,
      passiveTrait = WandTrait.AEGIS_WEAVE,
      primaryColorHex = 0xFFA68B6B,
      secondaryColorHex = 0xFF6E5840,
      coreGlowColorHex = 0xFFFF8A65
    ),
    Wand(
      id = "wand_hawthorn_thestral",
      name = "Hawthorn & Thestral",
      wood = "Dark Hawthorn",
      core = "Thestral Tail Hair",
      description = "Enigmatic duelist wand capable of threading sharp critical casts and rapid recasts.",
      castingAccuracyBonus = 3,
      manaEfficiencyPercent = 6,
      spellPowerBonus = 5,
      castingSpeed = 7,
      cooldownReduction = 1,
      maxHpBonus = 0,
      maxManaBonus = 5,
      passiveTrait = WandTrait.SHADOW_PIERCE,
      primaryColorHex = 0xFF4B3D47,
      secondaryColorHex = 0xFF2D232A,
      coreGlowColorHex = 0xFFB39DDB
    ),
    Wand(
      id = "wand_vine_kelpie",
      name = "Vine & Kelpie",
      wood = "Twisted Vine",
      core = "Kelpie Mane",
      description = "Deep-flowing arcane conduit offering unmatched Mana efficiency and capacity.",
      castingAccuracyBonus = 5,
      manaEfficiencyPercent = 18,
      spellPowerBonus = 2,
      castingSpeed = 6,
      cooldownReduction = 0,
      maxHpBonus = 5,
      maxManaBonus = 20,
      passiveTrait = WandTrait.MANA_WELL,
      primaryColorHex = 0xFF4A6B4E,
      secondaryColorHex = 0xFF2C422F,
      coreGlowColorHex = 0xFF4DB6AC
    ),
    Wand(
      id = "wand_walnut_thunderbird",
      name = "Walnut & Thunderbird",
      wood = "Black Walnut",
      core = "Thunderbird Feather",
      description = "Lightning-quick focus built for rapid-fire incantations and reduced cooldowns.",
      castingAccuracyBonus = 4,
      manaEfficiencyPercent = 8,
      spellPowerBonus = 5,
      castingSpeed = 9,
      cooldownReduction = 1,
      maxHpBonus = 0,
      maxManaBonus = 0,
      passiveTrait = WandTrait.TEMPEST_PACE,
      primaryColorHex = 0xFF4E342E,
      secondaryColorHex = 0xFF2E1E1A,
      coreGlowColorHex = 0xFF64B5F6
    ),
    Wand(
      id = "wand_ash_wampus",
      name = "Ash & Wampus",
      wood = "White Ash",
      core = "Wampus Cat Hair",
      description = "Dependable wand tuned to clear vocal articulation and resilient wardwork.",
      castingAccuracyBonus = 7,
      manaEfficiencyPercent = 10,
      spellPowerBonus = 3,
      castingSpeed = 7,
      cooldownReduction = 0,
      maxHpBonus = 10,
      maxManaBonus = 5,
      passiveTrait = WandTrait.RUNE_PRECISION,
      primaryColorHex = 0xFFBFA888,
      secondaryColorHex = 0xFF8C775A,
      coreGlowColorHex = 0xFFFFCA28
    ),
    Wand(
      id = "wand_cedar_serpent",
      name = "Cedar & Serpent",
      wood = "Red Cedar",
      core = "Horned Serpent Horn",
      description = "Resonant high-power wand amplifying every offensive incantation.",
      castingAccuracyBonus = 3,
      manaEfficiencyPercent = 6,
      spellPowerBonus = 6,
      castingSpeed = 6,
      cooldownReduction = 0,
      maxHpBonus = 5,
      maxManaBonus = 0,
      passiveTrait = WandTrait.SOLAR_FOCUS,
      primaryColorHex = 0xFF8C3B2B,
      secondaryColorHex = 0xFF572116,
      coreGlowColorHex = 0xFFAED581
    ),
    Wand(
      id = "wand_rowan_moonstone",
      name = "Rowan & Moonstone",
      wood = "Mountain Rowan",
      core = "Moonstone Core",
      description = "Pure defensive wand weaving shimmering wards while conserving Mana.",
      castingAccuracyBonus = 6,
      manaEfficiencyPercent = 12,
      spellPowerBonus = 2,
      castingSpeed = 7,
      cooldownReduction = 0,
      maxHpBonus = 15,
      maxManaBonus = 10,
      passiveTrait = WandTrait.AEGIS_WEAVE,
      primaryColorHex = 0xFF7D6B5D,
      secondaryColorHex = 0xFF4E4137,
      coreGlowColorHex = 0xFF90CAF9
    ),
    Wand(
      id = "wand_ebony_rougarou",
      name = "Ebony & Rougarou",
      wood = "Jet Ebony",
      core = "Rougarou Hair",
      description = "Unforgiving combat wand favoring aggressive tempo and fast spell recovery.",
      castingAccuracyBonus = 3,
      manaEfficiencyPercent = 5,
      spellPowerBonus = 5,
      castingSpeed = 8,
      cooldownReduction = 1,
      maxHpBonus = 0,
      maxManaBonus = 5,
      passiveTrait = WandTrait.TEMPEST_PACE,
      primaryColorHex = 0xFF2B2B33,
      secondaryColorHex = 0xFF16161B,
      coreGlowColorHex = 0xFFEF5350
    ),
    Wand(
      id = "wand_maple_sylph",
      name = "Maple & Sylph",
      wood = "Sugar Maple",
      core = "Sylph Wing",
      description = "Feather-light traveler's wand restoring brisk Mana reserves between rounds.",
      castingAccuracyBonus = 6,
      manaEfficiencyPercent = 16,
      spellPowerBonus = 2,
      castingSpeed = 9,
      cooldownReduction = 0,
      maxHpBonus = 0,
      maxManaBonus = 15,
      passiveTrait = WandTrait.CHRONO_SPARK,
      primaryColorHex = 0xFFC59B6D,
      secondaryColorHex = 0xFF8E6A42,
      coreGlowColorHex = 0xFF81D4FA
    ),
    Wand(
      id = "wand_cherry_sunburst",
      name = "Cherry & Sunburst",
      wood = "Blossom Cherry",
      core = "Sunburst Hair",
      description = "Luminous wand pairing graceful restoration with balanced offensive potency.",
      castingAccuracyBonus = 5,
      manaEfficiencyPercent = 12,
      spellPowerBonus = 4,
      castingSpeed = 7,
      cooldownReduction = 0,
      maxHpBonus = 10,
      maxManaBonus = 10,
      passiveTrait = WandTrait.VITAL_BLOOM,
      primaryColorHex = 0xFF9E5258,
      secondaryColorHex = 0xFF663035,
      coreGlowColorHex = 0xFFFFAB91
    ),
    Wand(
      id = "wand_blackthorn_basalt",
      name = "Blackthorn & Basalt",
      wood = "Gnarled Blackthorn",
      core = "Basalt Spark",
      description = "Battle-hardened guardian wand granting rugged stamina and staunch wards.",
      castingAccuracyBonus = 4,
      manaEfficiencyPercent = 8,
      spellPowerBonus = 4,
      castingSpeed = 5,
      cooldownReduction = 0,
      maxHpBonus = 20,
      maxManaBonus = 5,
      passiveTrait = WandTrait.AEGIS_WEAVE,
      primaryColorHex = 0xFF3E3A37,
      secondaryColorHex = 0xFF23201E,
      coreGlowColorHex = 0xFFFFE082
    )
  )

  fun hasWand(id: String): Boolean = wands.any { it.id == id }

  fun getById(id: String): Wand = wands.firstOrNull { it.id == id } ?: wands.first()

  fun randomWand(random: Random = Random.Default): Wand = wands[random.nextInt(wands.size)]
}

object AchievementCatalog {
  fun buildAchievements(save: PlayerSaveData): List<Achievement> {
    val learnedCount = save.spellProgressMap.values.count { it.unlocked }
    val masteredCount = save.spellProgressMap.values.count { it.masteryLevel == MasteryLevel.MASTERED }

    fun item(id: String, title: String, desc: String, target: Int, current: Int): Achievement {
      val clamped = current.coerceAtMost(target)
      val unlocked = id in save.unlockedAchievementIds || current >= target
      return Achievement(
        id = id,
        title = title,
        description = desc,
        targetCount = target,
        currentCount = if (unlocked) target else clamped,
        unlocked = unlocked
      )
    }

    return listOf(
      item("learn_first_spell", "First Incantation", "Learn your first new spell through practice & voice.", 2, learnedCount),
      item("learn_five_spells", "Apprentice Archivist", "Unlock at least 5 spells in your Spell Library.", 5, learnedCount),
      item("master_spell", "True Mastery", "Reach Mastered rank on any spell.", 1, masteredCount),
      item("voice_caster", "Voice of Arcane", "Cast 5 spells cleanly using voice incantations.", 5, save.voiceCastsSucceeded),
      item("complete_first_battle", "Baptism of Sparks", "Complete your first duel in any combat mode.", 1, save.battlesCompleted),
      item("defeat_death_eater", "Order Defender", "Defeat a Death Eater stage enemy.", 1, save.deathEatersDefeated),
      item("clear_all_stages", "Champion of the Sanctum", "Clear all 5 Death Eater stages.", 5, save.highestStageCleared),
      item("win_free_battle", "Arena Sovereign", "Win a Free Battle match.", 1, save.freeBattlesWon),
      item("perform_combo", "Arcane Synergy", "Trigger a predefined Spell Combo in combat.", 1, save.combosPerformed),
      item("perfect_practice", "Flawless Form", "Complete a practice cast with 95%+ accuracy.", 1, save.perfectPractices)
    )
  }
}
