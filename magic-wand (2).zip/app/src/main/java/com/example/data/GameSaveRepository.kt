package com.example.data

import android.content.Context
import com.example.model.AppSettings
import com.example.model.MasteryLevel
import com.example.model.PlayerSaveData
import com.example.model.Spell
import com.example.model.SpellProgress
import com.example.model.ThemePreference
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class GameSaveRepository(private val context: Context) {

  private val saveFile = File(context.filesDir, "magic_wand_save.json")
  private val lock = Any()

  fun load(spells: List<Spell>): PlayerSaveData = synchronized(lock) {
    val raw = if (saveFile.exists()) {
      runCatching { saveFile.readText() }.getOrNull()
    } else {
      null
    }
    val parsed = if (raw.isNullOrBlank()) {
      PlayerSaveData()
    } else {
      runCatching { parseJson(raw) }.getOrElse { PlayerSaveData() }
    }
    val needsWandAssignment = !WandCatalog.hasWand(parsed.selectedWandId)
    val defaulted = ensureDefaults(parsed, spells)
    if (!saveFile.exists() || needsWandAssignment) {
      save(defaulted)
    }
    return defaulted
  }

  fun save(data: PlayerSaveData) = synchronized(lock) {
    val jsonText = toJson(data).toString(2)
    val tempFile = File(context.filesDir, "magic_wand_save.json.tmp")
    tempFile.writeText(jsonText)
    if (!tempFile.renameTo(saveFile)) {
      saveFile.writeText(jsonText)
      tempFile.delete()
    }
  }

  fun resetAll(spells: List<Spell>): PlayerSaveData = synchronized(lock) {
    if (saveFile.exists()) {
      saveFile.delete()
    }
    val fresh = ensureDefaults(PlayerSaveData(), spells)
    save(fresh)
    return fresh
  }

  private fun ensureDefaults(data: PlayerSaveData, spells: List<Spell>): PlayerSaveData {
    val updatedMap = data.spellProgressMap.toMutableMap()
    for (spell in spells) {
      val existing = updatedMap[spell.id]
      if (existing == null) {
        if (spell.starterUnlocked) {
          updatedMap[spell.id] = SpellProgress(
            spellId = spell.id,
            successfulPractices = spell.requiredPractice,
            totalAttempts = spell.requiredPractice,
            totalAccuracySum = spell.requiredPractice * 90,
            bestAccuracy = 90,
            unlocked = true,
            masteryLevel = MasteryLevel.LEARNED
          )
        } else {
          updatedMap[spell.id] = SpellProgress(
            spellId = spell.id,
            successfulPractices = 0,
            totalAttempts = 0,
            totalAccuracySum = 0,
            bestAccuracy = 0,
            unlocked = false,
            masteryLevel = MasteryLevel.LOCKED
          )
        }
      }
    }
    val assignedWandId = if (WandCatalog.hasWand(data.selectedWandId)) {
      data.selectedWandId
    } else {
      WandCatalog.randomWand().id
    }
    return data.copy(
      spellProgressMap = updatedMap,
      selectedWandId = assignedWandId
    )
  }

  private fun toJson(data: PlayerSaveData): JSONObject {
    val root = JSONObject()
    val progressObj = JSONObject()
    data.spellProgressMap.forEach { (id, prog) ->
      val p = JSONObject()
      p.put("spellId", prog.spellId)
      p.put("successfulPractices", prog.successfulPractices)
      p.put("totalAttempts", prog.totalAttempts)
      p.put("totalAccuracySum", prog.totalAccuracySum)
      p.put("bestAccuracy", prog.bestAccuracy)
      p.put("unlocked", prog.unlocked)
      p.put("masteryLevel", prog.masteryLevel.name)
      progressObj.put(id, p)
    }
    root.put("spellProgressMap", progressObj)
    root.put("highestStageCleared", data.highestStageCleared)
    root.put("battlesCompleted", data.battlesCompleted)
    root.put("deathEatersDefeated", data.deathEatersDefeated)
    root.put("freeBattlesWon", data.freeBattlesWon)
    root.put("combosPerformed", data.combosPerformed)
    root.put("perfectPractices", data.perfectPractices)
    root.put("voiceCastsSucceeded", data.voiceCastsSucceeded)
    data.recentSpellId?.let { root.put("recentSpellId", it) }
    root.put("selectedWandId", data.selectedWandId)

    val achArr = JSONArray()
    data.unlockedAchievementIds.forEach { achArr.put(it) }
    root.put("unlockedAchievementIds", achArr)

    val settingsObj = JSONObject()
    settingsObj.put("wizardName", data.settings.wizardName)
    settingsObj.put("hapticsEnabled", data.settings.hapticsEnabled)
    settingsObj.put("soundChimeEnabled", data.settings.soundChimeEnabled)
    settingsObj.put("showPatternHints", data.settings.showPatternHints)
    settingsObj.put("voiceCastingInCombat", data.settings.voiceCastingInCombat)
    settingsObj.put("themePreference", data.settings.themePreference.name)
    root.put("settings", settingsObj)
    return root
  }

  private fun parseJson(text: String): PlayerSaveData {
    val root = JSONObject(text)
    val progressMap = mutableMapOf<String, SpellProgress>()
    val progressObj = root.optJSONObject("spellProgressMap")
    if (progressObj != null) {
      val keys = progressObj.keys()
      while (keys.hasNext()) {
        val key = keys.next()
        val p = progressObj.getJSONObject(key)
        val mastery = runCatching {
          MasteryLevel.valueOf(p.optString("masteryLevel", "LOCKED"))
        }.getOrDefault(MasteryLevel.LOCKED)
        progressMap[key] = SpellProgress(
          spellId = p.optString("spellId", key),
          successfulPractices = p.optInt("successfulPractices", 0),
          totalAttempts = p.optInt("totalAttempts", 0),
          totalAccuracySum = p.optInt("totalAccuracySum", 0),
          bestAccuracy = p.optInt("bestAccuracy", 0),
          unlocked = p.optBoolean("unlocked", false),
          masteryLevel = mastery
        )
      }
    }

    val achSet = mutableSetOf<String>()
    val achArr = root.optJSONArray("unlockedAchievementIds")
    if (achArr != null) {
      for (i in 0 until achArr.length()) {
        achSet.add(achArr.getString(i))
      }
    }

    val sObj = root.optJSONObject("settings")
    val settings = if (sObj != null) {
      AppSettings(
        wizardName = sObj.optString("wizardName", "Apprentice").ifBlank { "Apprentice" },
        hapticsEnabled = sObj.optBoolean("hapticsEnabled", true),
        soundChimeEnabled = sObj.optBoolean("soundChimeEnabled", true),
        showPatternHints = sObj.optBoolean("showPatternHints", true),
        voiceCastingInCombat = sObj.optBoolean("voiceCastingInCombat", true),
        themePreference = runCatching {
          ThemePreference.valueOf(sObj.optString("themePreference", "DARK"))
        }.getOrDefault(ThemePreference.DARK)
      )
    } else {
      AppSettings()
    }

    return PlayerSaveData(
      spellProgressMap = progressMap,
      highestStageCleared = root.optInt("highestStageCleared", 0),
      battlesCompleted = root.optInt("battlesCompleted", 0),
      deathEatersDefeated = root.optInt("deathEatersDefeated", 0),
      freeBattlesWon = root.optInt("freeBattlesWon", 0),
      combosPerformed = root.optInt("combosPerformed", 0),
      perfectPractices = root.optInt("perfectPractices", 0),
      voiceCastsSucceeded = root.optInt("voiceCastsSucceeded", 0),
      recentSpellId = root.optString("recentSpellId", "lumos_spark").ifBlank { "lumos_spark" },
      selectedWandId = root.optString("selectedWandId", ""),
      unlockedAchievementIds = achSet,
      settings = settings
    )
  }
}
