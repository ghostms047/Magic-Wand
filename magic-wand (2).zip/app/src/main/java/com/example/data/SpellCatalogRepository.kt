package com.example.data

import android.content.Context
import com.example.model.ComboDefinition
import com.example.model.Spell
import com.example.model.SpellCategory
import com.example.model.StatusEffectType
import org.json.JSONArray

class SpellCatalogRepository(private val context: Context? = null) {

  private var cachedSpells: List<Spell>? = null
  private var cachedCombos: List<ComboDefinition>? = null

  fun getAllSpells(): List<Spell> {
    cachedSpells?.let { return it }
    val json = context?.assets?.open("spells.json")?.bufferedReader()?.use { it.readText() }
      ?: return emptyList()
    return parseSpellsJson(json).also { cachedSpells = it }
  }

  fun getAllCombos(): List<ComboDefinition> {
    cachedCombos?.let { return it }
    val json = context?.assets?.open("combos.json")?.bufferedReader()?.use { it.readText() }
      ?: return emptyList()
    return parseCombosJson(json).also { cachedCombos = it }
  }

  fun getSpellById(id: String): Spell? = getAllSpells().firstOrNull { it.id == id }

  companion object {
    fun parseSpellsJson(jsonText: String): List<Spell> {
      val array = JSONArray(jsonText)
      val result = ArrayList<Spell>(array.length())
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        val patternArray = obj.getJSONArray("patternNodes")
        val nodes = ArrayList<Int>(patternArray.length())
        for (j in 0 until patternArray.length()) {
          nodes.add(patternArray.getInt(j))
        }
        val variantsArr = obj.optJSONArray("voiceVariants")
        val variants = ArrayList<String>()
        if (variantsArr != null) {
          for (v in 0 until variantsArr.length()) {
            variants.add(variantsArr.getString(v))
          }
        }
        result.add(
          Spell(
            id = obj.getString("id"),
            name = obj.getString("name"),
            category = SpellCategory.valueOf(obj.getString("category")),
            description = obj.getString("description"),
            difficulty = obj.getInt("difficulty"),
            requiredPractice = obj.getInt("requiredPractice"),
            cooldown = obj.getInt("cooldown"),
            combatAvailable = obj.getBoolean("combatAvailable"),
            starterUnlocked = obj.optBoolean("starterUnlocked", false),
            baseDamage = obj.getInt("baseDamage"),
            baseShield = obj.getInt("baseShield"),
            baseHeal = obj.getInt("baseHeal"),
            statusType = StatusEffectType.valueOf(obj.optString("statusType", "NONE")),
            statusMagnitude = obj.optInt("statusMagnitude", 0),
            statusDuration = obj.optInt("statusDuration", 0),
            patternNodes = nodes,
            patternHint = obj.optString("patternHint", ""),
            phoneticIpa = obj.optString("phoneticIpa", ""),
            phoneticGuide = obj.optString("phoneticGuide", obj.getString("name")),
            voiceVariants = variants,
            manaCost = obj.optInt("manaCost", 14)
          )
        )
      }
      return result
    }

    fun parseCombosJson(jsonText: String): List<ComboDefinition> {
      val array = JSONArray(jsonText)
      val result = ArrayList<ComboDefinition>(array.length())
      for (i in 0 until array.length()) {
        val obj = array.getJSONObject(i)
        result.add(
          ComboDefinition(
            id = obj.getString("id"),
            name = obj.getString("name"),
            firstSpellId = obj.getString("firstSpellId"),
            secondSpellId = obj.getString("secondSpellId"),
            bonusDamage = obj.optInt("bonusDamage", 0),
            bonusShield = obj.optInt("bonusShield", 0),
            bonusHeal = obj.optInt("bonusHeal", 0),
            shatterEnemyShield = obj.optBoolean("shatterEnemyShield", false),
            description = obj.getString("description")
          )
        )
      }
      return result
    }
  }
}
