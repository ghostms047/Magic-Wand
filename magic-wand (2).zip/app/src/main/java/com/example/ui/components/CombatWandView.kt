package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.Wand
import com.example.voice.VoiceSessionState
import com.example.voice.VoiceUiPhase

/**
 * Vertical Wand Canvas rendering the player's uniquely assigned Wand (wood, handle wrap, core glow)
 * with subtle reactive aura while holding to cast.
 */
@Composable
fun VerticalWandIllustration(
  wand: Wand,
  isListening: Boolean,
  rmsLevel: Float,
  modifier: Modifier = Modifier
) {
  val transition = rememberInfiniteTransition(label = "wandAura")
  val pulse by transition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.25f,
    animationSpec = infiniteRepeatable(
      animation = tween(600),
      repeatMode = RepeatMode.Reverse
    ),
    label = "wandPulse"
  )

  val primaryWood = Color(wand.primaryColorHex)
  val secondaryWood = Color(wand.secondaryColorHex)
  val coreGlow = Color(wand.coreGlowColorHex)

  Canvas(modifier = modifier) {
    val cx = size.width / 2f
    val topY = size.height * 0.12f
    val tipRadius = size.width * 0.08f
    val hiltTopY = size.height * 0.70f
    val bottomY = size.height * 0.94f

    // Tip arcane aura glow
    val glowRadius = if (isListening) {
      (size.width * 0.28f) * (pulse + rmsLevel * 0.45f)
    } else {
      size.width * 0.16f
    }
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(
          coreGlow.copy(alpha = if (isListening) 0.72f else 0.34f),
          coreGlow.copy(alpha = 0f)
        ),
        center = Offset(cx, topY),
        radius = glowRadius
      ),
      radius = glowRadius,
      center = Offset(cx, topY)
    )

    // Tapered shaft from tip to hilt
    val topHalf = tipRadius * 0.65f
    val midHalf = size.width * 0.095f
    val shaftPath = Path().apply {
      moveTo(cx - topHalf, topY)
      lineTo(cx + topHalf, topY)
      lineTo(cx + midHalf, hiltTopY)
      lineTo(cx - midHalf, hiltTopY)
      close()
    }
    drawPath(
      path = shaftPath,
      brush = Brush.horizontalGradient(
        colors = listOf(secondaryWood, primaryWood, secondaryWood),
        startX = cx - midHalf,
        endX = cx + midHalf
      )
    )

    // Carved decorative ferrule rings at hilt transition
    drawRoundRect(
      color = coreGlow.copy(alpha = 0.85f),
      topLeft = Offset(cx - midHalf * 1.22f, hiltTopY - 4.dp.toPx()),
      size = Size(midHalf * 2.44f, 6.dp.toPx()),
      cornerRadius = CornerRadius(4.dp.toPx())
    )

    // Ergonomic lower grip / handle
    val gripHalf = size.width * 0.115f
    val gripPath = Path().apply {
      moveTo(cx - gripHalf, hiltTopY + 3.dp.toPx())
      lineTo(cx + gripHalf, hiltTopY + 3.dp.toPx())
      lineTo(cx + gripHalf * 1.15f, bottomY)
      lineTo(cx - gripHalf * 1.15f, bottomY)
      close()
    }
    drawPath(
      path = gripPath,
      brush = Brush.horizontalGradient(
        colors = listOf(secondaryWood, primaryWood.copy(alpha = 0.9f), secondaryWood),
        startX = cx - gripHalf * 1.2f,
        endX = cx + gripHalf * 1.2f
      )
    )

    // Pommel cap
    drawCircle(
      color = coreGlow.copy(alpha = 0.9f),
      radius = gripHalf * 0.92f,
      center = Offset(cx, bottomY)
    )

    // Glowing rune core spark at wand tip
    drawCircle(
      color = if (isListening) Color.White else coreGlow,
      radius = if (isListening) tipRadius * 0.85f else tipRadius * 0.55f,
      center = Offset(cx, topY)
    )

    // Subtle helical wrap accent along the grip
    val gripSpan = bottomY - hiltTopY
    for (i in 1..3) {
      val y = hiltTopY + (gripSpan * (i / 4f))
      drawLine(
        color = coreGlow.copy(alpha = 0.45f),
        start = Offset(cx - gripHalf, y - 3.dp.toPx()),
        end = Offset(cx + gripHalf, y + 3.dp.toPx()),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
      )
    }
  }
}

/**
 * Minimal, ergonomic Vertical Wand + Hold-to-Cast Combat Control.
 * Designed so the player holds the phone like a wand: Press & Hold -> Speak Spell -> Release -> Cast.
 */
@Composable
fun CombatWandControlCard(
  wand: Wand,
  enabled: Boolean,
  voiceState: VoiceSessionState,
  feedbackMessage: String?,
  onHoldStart: () -> Unit,
  onHoldRelease: () -> Unit,
  onFallbackSubmit: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var hasMicPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  var permissionDeniedOnce by remember { mutableStateOf(false) }
  var isFingerHeld by remember { mutableStateOf(false) }
  var fallbackText by remember { mutableStateOf("") }

  val currentEnabled by rememberUpdatedState(enabled)
  val currentHasPermission by rememberUpdatedState(hasMicPermission)
  val currentSpeechAvailable by rememberUpdatedState(voiceState.isSpeechServiceAvailable)
  val currentOnHoldStart by rememberUpdatedState(onHoldStart)
  val currentOnHoldRelease by rememberUpdatedState(onHoldRelease)

  LaunchedEffect(enabled) {
    if (!enabled) {
      isFingerHeld = false
    }
  }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    hasMicPermission = granted
    if (!granted) {
      permissionDeniedOnce = true
    }
  }

  val isListening = voiceState.phase == VoiceUiPhase.LISTENING || isFingerHeld
  val isProcessing = voiceState.phase == VoiceUiPhase.PROCESSING

  val statusText = when {
    !enabled -> "Opponent turn — brace your wards..."
    !hasMicPermission -> "Grant microphone permission to cast spells with your voice."
    !voiceState.isSpeechServiceAvailable -> "Speech recognition unavailable on this device. Enter incantation below."
    isListening -> if (voiceState.partialText.isNotBlank()) {
      "Listening: \"${voiceState.partialText}\""
    } else {
      "Listening... Speak any spell, then release!"
    }
    isProcessing -> "Channeling incantation..."
    !feedbackMessage.isNullOrBlank() -> feedbackMessage
    else -> "Hold the Wand button, speak a spell, and release to cast."
  }

  val buttonColor by animateColorAsState(
    targetValue = when {
      !enabled -> MaterialTheme.colorScheme.surfaceVariant
      isListening -> Color(wand.coreGlowColorHex)
      isProcessing -> MaterialTheme.colorScheme.secondary
      else -> MaterialTheme.colorScheme.primary
    },
    label = "castBtnColor"
  )

  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(
      1.5.dp,
      if (isListening) Color(wand.coreGlowColorHex) else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
    ),
    modifier = modifier
      .fillMaxWidth()
      .testTag("combat_wand_panel")
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
      // Wand Identity Badge
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
      ) {
        Icon(
          imageVector = Icons.Filled.AutoFixHigh,
          contentDescription = null,
          tint = Color(wand.coreGlowColorHex),
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "${wand.name} • ${wand.passiveTrait.displayName}",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      // Vertical Wand Visual Centerpiece
      VerticalWandIllustration(
        wand = wand,
        isListening = isListening,
        rmsLevel = voiceState.rmsLevel,
        modifier = Modifier
          .width(120.dp)
          .height(210.dp)
          .testTag("vertical_wand_visual")
      )

      // Concise Live Status / Cast Feedback
      Surface(
        color = when (voiceState.phase) {
          VoiceUiPhase.REJECTED -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f)
          VoiceUiPhase.SUCCESS -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.75f)
          VoiceUiPhase.LISTENING -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.8f)
          else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
        },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = statusText,
          style = MaterialTheme.typography.bodyMedium,
          textAlign = TextAlign.Center,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        )
      }

      if (!hasMicPermission) {
        Button(
          onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
          modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("combat_grant_mic_btn")
        ) {
          Icon(Icons.Filled.Mic, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(if (permissionDeniedOnce) "Allow Microphone Permission" else "Enable Microphone to Cast")
        }
      } else if (voiceState.isSpeechServiceAvailable) {
        // Dedicated Hold-to-Cast Wand Trigger
        Surface(
          color = buttonColor,
          shape = RoundedCornerShape(28.dp),
          shadowElevation = if (isListening) 8.dp else 2.dp,
          modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(28.dp))
            .pointerInput(Unit) {
              awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                if (!currentEnabled || !currentHasPermission || !currentSpeechAvailable) {
                  return@awaitEachGesture
                }
                isFingerHeld = true
                currentOnHoldStart()
                waitForUpOrCancellation()
                if (isFingerHeld) {
                  isFingerHeld = false
                  currentOnHoldRelease()
                }
              }
            }
            .testTag("hold_to_cast_button")
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 16.dp)
          ) {
            Box(
              contentAlignment = Alignment.Center,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.16f))
            ) {
              Icon(
                imageVector = if (isListening) Icons.Filled.GraphicEq else Icons.Filled.Mic,
                contentDescription = if (isListening) "Listening" else "Hold to speak spell",
                tint = if (isListening) Color.Black else MaterialTheme.colorScheme.onPrimary
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = when {
                !enabled -> "OPPONENT TURN"
                isListening -> "RELEASE TO CAST"
                isProcessing -> "CASTING..."
                else -> "HOLD WAND TO CAST"
              },
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = when {
                !enabled -> MaterialTheme.colorScheme.onSurfaceVariant
                isListening -> Color.Black
                else -> MaterialTheme.colorScheme.onPrimary
              }
            )
          }
        }
      }

      // Deterministic text input fallback ONLY when device has no SpeechRecognizer service
      if (hasMicPermission && !voiceState.isSpeechServiceAvailable) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          OutlinedTextField(
            value = fallbackText,
            onValueChange = { fallbackText = it },
            label = { Text("Speak / Enter Spell Name") },
            singleLine = true,
            enabled = enabled,
            modifier = Modifier
              .weight(1f)
              .testTag("combat_fallback_input")
          )
          Button(
            onClick = {
              val spoken = fallbackText.trim()
              if (spoken.isNotEmpty()) {
                fallbackText = ""
                onFallbackSubmit(spoken)
              }
            },
            enabled = enabled && fallbackText.isNotBlank(),
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("combat_fallback_cast_btn")
          ) {
            Text("Cast")
          }
        }
      }
    }
  }
}
