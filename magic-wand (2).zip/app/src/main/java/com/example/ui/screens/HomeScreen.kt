package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.WandCatalog
import com.example.model.MasteryLevel
import com.example.model.PlayerSaveData
import com.example.model.Spell
import com.example.ui.AppDestination

@Composable
fun HomeScreen(
  saveData: PlayerSaveData,
  allSpells: List<Spell>,
  onNavigate: (AppDestination) -> Unit,
  onOpenSpellDetail: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  val learnedCount = saveData.spellProgressMap.values.count { it.unlocked }
  val masteredCount = saveData.spellProgressMap.values.count { it.masteryLevel == MasteryLevel.MASTERED }
  val activeWand = WandCatalog.getById(saveData.selectedWandId)
  val recentSpell = allSpells.firstOrNull { it.id == saveData.recentSpellId }
    ?: allSpells.firstOrNull { it.starterUnlocked }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    // Hero Identity Banner
    item {
      Box(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
          .height(195.dp)
          .clip(RoundedCornerShape(22.dp))
      ) {
        Image(
          painter = painterResource(id = R.drawable.img_arcane_sanctum),
          contentDescription = "Wizard sanctum study desk",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize()
        )
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors = listOf(
                  Color.Black.copy(alpha = 0.22f),
                  Color.Black.copy(alpha = 0.82f)
                )
              )
            )
        )
        Column(
          verticalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier
            .fillMaxSize()
            .padding(18.dp)
        ) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f),
              shape = RoundedCornerShape(10.dp)
            ) {
              Text(
                text = "MAGIC WAND",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
              )
            }
            Text(
              text = saveData.settings.wizardName,
              style = MaterialTheme.typography.labelMedium,
              color = Color.White.copy(alpha = 0.9f)
            )
          }

          Column {
            Text(
              text = "Learn. Speak. Duel.",
              style = MaterialTheme.typography.headlineMedium,
              color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Wand: ${activeWand.name} • ${activeWand.passiveTrait.displayName}",
              style = MaterialTheme.typography.bodySmall,
              color = Color.White.copy(alpha = 0.88f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
            )
          }
        }
      }
    }

    // Progression Snapshot
    item {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          SummaryStatTile("Learned", "$learnedCount/${allSpells.size}", Modifier.weight(1f))
          SummaryStatTile("Mastered", "$masteredCount", Modifier.weight(1f))
          SummaryStatTile("Stages", "${saveData.highestStageCleared}/5", Modifier.weight(1f))
        }
        if (recentSpell != null) {
          val recentProg = saveData.spellProgressMap[recentSpell.id]
          Card(
            onClick = { onOpenSpellDetail(recentSpell.id) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Recent Spell: ${recentSpell.name}",
                  style = MaterialTheme.typography.titleSmall
                )
                Text(
                  text = "${recentSpell.phoneticGuide} • ${recentProg?.masteryLevel?.displayName ?: "Locked"} (${recentProg?.averageAccuracy ?: 0}% acc)",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
                )
              }
              Text(
                text = "Inspect",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
        }
      }
    }

    // Primary Actions: Practice, Battle, Spell Library
    item {
      Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Primary Spellcraft", style = MaterialTheme.typography.titleLarge)

        Button(
          onClick = { onNavigate(AppDestination.PRACTICE) },
          shape = RoundedCornerShape(16.dp),
          modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("home_nav_practice")
        ) {
          Icon(Icons.Filled.Mic, contentDescription = null)
          Spacer(modifier = Modifier.width(10.dp))
          Text("PRACTICE & VOICE SPELLCASTING", modifier = Modifier.padding(vertical = 8.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          HomeActionCard(
            title = "Death Eater Battle",
            subtitle = "Voice-cast duels across 5 stages",
            icon = Icons.Filled.Shield,
            accent = MaterialTheme.colorScheme.error,
            onClick = { onNavigate(AppDestination.DEATH_EATER_BATTLE) },
            modifier = Modifier
              .weight(1f)
              .testTag("home_nav_death_eater")
          )
          HomeActionCard(
            title = "Spell Library",
            subtitle = "${allSpells.size} incantations & phonetics",
            icon = Icons.Filled.MenuBook,
            accent = MaterialTheme.colorScheme.primary,
            onClick = { onNavigate(AppDestination.SPELL_LIBRARY) },
            modifier = Modifier
              .weight(1f)
              .testTag("home_nav_library")
          )
        }

        HomeWideActionCard(
          title = "Free Battle & Sandbox",
          subtitle = "Custom arenas, HP, turn timer & test all ${allSpells.size} spells",
          icon = Icons.Filled.SportsKabaddi,
          onClick = { onNavigate(AppDestination.FREE_BATTLE) },
          modifier = Modifier.testTag("home_nav_free_battle")
        )
      }
    }

    // Secondary Actions: Local Multiplayer, Wand, Achievements, Settings
    item {
      Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Sanctum & Multiplayer", style = MaterialTheme.typography.titleLarge)

        HomeWideActionCard(
          title = "Local Multiplayer (LAN)",
          subtitle = "Host or join offline Wi-Fi duels with voice spellcasting",
          icon = Icons.Filled.Wifi,
          onClick = { onNavigate(AppDestination.LOCAL_MULTIPLAYER) },
          modifier = Modifier.testTag("home_nav_lan")
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
          HomeActionCard(
            title = "Wand",
            subtitle = activeWand.name,
            icon = Icons.Filled.AutoFixHigh,
            accent = MaterialTheme.colorScheme.secondary,
            onClick = { onNavigate(AppDestination.WAND) },
            modifier = Modifier
              .weight(1f)
              .testTag("home_nav_wand")
          )
          HomeActionCard(
            title = "Achievements",
            subtitle = "${saveData.unlockedAchievementIds.size}/10 unlocked",
            icon = Icons.Filled.EmojiEvents,
            accent = MaterialTheme.colorScheme.tertiary,
            onClick = { onNavigate(AppDestination.ACHIEVEMENTS) },
            modifier = Modifier
              .weight(1f)
              .testTag("home_nav_achievements")
          )
        }

        HomeWideActionCard(
          title = "Settings",
          subtitle = "Voice combat mode, theme, pattern hints & save reset",
          icon = Icons.Filled.Settings,
          onClick = { onNavigate(AppDestination.SETTINGS) },
          modifier = Modifier.testTag("home_nav_settings")
        )
      }
    }
  }
}

@Composable
private fun SummaryStatTile(label: String, value: String, modifier: Modifier = Modifier) {
  Card(
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
    modifier = modifier
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 10.dp, horizontal = 8.dp)
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.primary
      )
      Text(
        text = label,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@Composable
private fun HomeActionCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accent: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    onClick = onClick,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
    modifier = modifier.minimumInteractiveComponentSize()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Surface(
        color = accent.copy(alpha = 0.16f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.size(38.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = title,
            tint = accent,
            modifier = Modifier.size(22.dp)
          )
        }
      }
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
      )
      Spacer(modifier = Modifier.height(3.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis
      )
    }
  }
}

@Composable
private fun HomeWideActionCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    onClick = onClick,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
    modifier = modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(14.dp)
    ) {
      Surface(
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.size(42.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = title,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(22.dp)
          )
        }
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}
