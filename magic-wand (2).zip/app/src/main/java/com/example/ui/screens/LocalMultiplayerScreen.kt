package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.WandCatalog
import com.example.model.DiscoveredHost
import com.example.model.LanMatchStatus
import com.example.network.LanRole
import com.example.network.LanUiState
import com.example.ui.components.CombatWandControlCard
import com.example.ui.components.CombatantHudCard
import com.example.ui.components.ComboBannerCard
import com.example.voice.VoiceSessionState

@Composable
fun LocalMultiplayerScreen(
  lanState: LanUiState,
  discoveredHosts: List<DiscoveredHost>,
  assignedWandId: String,
  voiceState: VoiceSessionState,
  voiceFeedback: String?,
  onStartHost: (Int) -> Unit,
  onToggleHostReady: () -> Unit,
  onStartDiscovery: () -> Unit,
  onStopDiscovery: () -> Unit,
  onConnectToHost: (String, String) -> Unit,
  onSendClientReady: () -> Unit,
  onHoldStart: () -> Unit,
  onHoldRelease: () -> Unit,
  onFallbackSubmit: (String) -> Unit,
  onDisconnect: () -> Unit,
  modifier: Modifier = Modifier
) {
  var isScanning by remember { mutableStateOf(false) }

  DisposableEffect(Unit) {
    onDispose {
      onStopDiscovery()
    }
  }

  if (lanState.role == LanRole.None && !lanState.isConnecting) {
    LanLobbySetupView(
      lanState = lanState,
      discoveredHosts = discoveredHosts,
      isScanning = isScanning,
      onStartHost = onStartHost,
      onToggleScan = {
        if (isScanning) {
          isScanning = false
          onStopDiscovery()
        } else {
          isScanning = true
          onStartDiscovery()
        }
      },
      onConnectToHost = { ip, port ->
        isScanning = false
        onStopDiscovery()
        onConnectToHost(ip, port)
      },
      modifier = modifier
    )
    return
  }

  val match = lanState.matchState
  val isHost = lanState.role is LanRole.Host
  val localPlayerId = if (isHost) "host" else "client"

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = when (val r = lanState.role) {
                is LanRole.Host -> "HOSTING ROOM ${r.gameId}"
                is LanRole.Client -> "JOINED ${r.hostIp}:${r.port}"
                LanRole.None -> "CONNECTING..."
              },
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.primary
            )
            OutlinedButton(
              onClick = onDisconnect,
              modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("lan_disconnect_btn")
            ) {
              Text("Leave")
            }
          }

          if (lanState.role is LanRole.Host) {
            Text(
              text = "IP: ${lanState.role.ipAddress}  •  Port: ${lanState.role.port}",
              style = MaterialTheme.typography.labelSmall
            )
          }
          Text(text = lanState.statusBanner, style = MaterialTheme.typography.bodySmall)

          lanState.errorBanner?.let { err ->
            Text(
              text = err,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.error
            )
          }
        }
      }
    }

    if (match != null) {
      if (match.status == LanMatchStatus.WAITING_FOR_PLAYER || match.status == LanMatchStatus.LOBBY_READY_CHECK) {
        val hostWand = WandCatalog.getById(match.hostState.wandId)
        val clientWand = WandCatalog.getById(match.clientState.wandId)
        item {
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier
              .widthIn(max = 640.dp)
              .fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
              Text("Duel Ready Check", style = MaterialTheme.typography.titleMedium)
              Text(
                text = "Host (${match.hostName} • ${hostWand.name}): ${if (match.hostReady) "READY" else "Not Ready"}",
                style = MaterialTheme.typography.bodyMedium
              )
              Text(
                text = "Challenger (${match.clientName} • ${clientWand.name}): ${if (match.clientReady) "READY" else "Waiting"}",
                style = MaterialTheme.typography.bodyMedium
              )
              if (match.status == LanMatchStatus.LOBBY_READY_CHECK) {
                Button(
                  onClick = { if (isHost) onToggleHostReady() else onSendClientReady() },
                  modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("lan_ready_btn")
                ) {
                  val alreadyReady = if (isHost) match.hostReady else match.clientReady
                  Text(if (alreadyReady) "Ready Confirmed" else "Mark Ready to Duel")
                }
              }
            }
          }
        }
      }

      if (match.status == LanMatchStatus.IN_PROGRESS || match.status == LanMatchStatus.FINISHED) {
        val localState = if (isHost) match.hostState else match.clientState
        val remoteState = if (isHost) match.clientState else match.hostState
        val isMyTurn = match.status == LanMatchStatus.IN_PROGRESS && match.activeTurnPlayerId == localPlayerId
        val localWand = WandCatalog.getById(localState.wandId.ifBlank { assignedWandId })

        item {
          Text(
            text = "Round ${match.roundNumber} • ${if (isMyTurn) "YOUR TURN" else "OPPONENT TURN"}",
            style = MaterialTheme.typography.titleMedium,
            color = if (isMyTurn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
              .widthIn(max = 640.dp)
              .fillMaxWidth()
          )
        }

        item {
          CombatantHudCard(
            combatant = remoteState,
            isActiveTurn = match.status == LanMatchStatus.IN_PROGRESS && match.activeTurnPlayerId != localPlayerId,
            isOpponent = true,
            modifier = Modifier.widthIn(max = 640.dp)
          )
        }

        item {
          ComboBannerCard(bannerText = match.comboBanner, modifier = Modifier.widthIn(max = 640.dp))
        }

        item {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = MaterialTheme.shapes.small,
            modifier = Modifier
              .widthIn(max = 640.dp)
              .fillMaxWidth()
          ) {
            Text(
              text = match.lastEventText,
              style = MaterialTheme.typography.bodySmall,
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
            )
          }
        }

        item {
          CombatantHudCard(
            combatant = localState,
            isActiveTurn = isMyTurn,
            isOpponent = false,
            modifier = Modifier.widthIn(max = 640.dp)
          )
        }

        if (match.status == LanMatchStatus.FINISHED) {
          val iWon = match.winnerId == localPlayerId
          item {
            Card(
              colors = CardDefaults.cardColors(
                containerColor = if (iWon) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer
              ),
              modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                  text = if (iWon) "LAN DUEL VICTORY!" else "LAN DUEL DEFEAT",
                  style = MaterialTheme.typography.headlineSmall
                )
                Text(text = match.lastEventText, style = MaterialTheme.typography.bodyMedium)
                if (isHost) {
                  Button(
                    onClick = onToggleHostReady,
                    modifier = Modifier
                      .fillMaxWidth()
                      .minimumInteractiveComponentSize()
                  ) {
                    Text("Request Rematch")
                  }
                }
              }
            }
          }
        } else {
          item {
            CombatWandControlCard(
              wand = localWand,
              enabled = isMyTurn,
              voiceState = voiceState,
              feedbackMessage = voiceFeedback,
              onHoldStart = onHoldStart,
              onHoldRelease = onHoldRelease,
              onFallbackSubmit = onFallbackSubmit,
              modifier = Modifier.widthIn(max = 640.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LanLobbySetupView(
  lanState: LanUiState,
  discoveredHosts: List<DiscoveredHost>,
  isScanning: Boolean,
  onStartHost: (Int) -> Unit,
  onToggleScan: () -> Unit,
  onConnectToHost: (String, String) -> Unit,
  modifier: Modifier = Modifier
) {
  var hostPortText by remember { mutableStateOf("8080") }
  var joinIpText by remember { mutableStateOf("") }
  var joinPortText by remember { mutableStateOf("8080") }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Local Multiplayer (LAN)", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "Duel another device on the same Wi-Fi network or hotspot using your bonded Wand and voice.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        lanState.errorBanner?.let { err ->
          Spacer(modifier = Modifier.height(6.dp))
          Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = err,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
              modifier = Modifier.padding(12.dp)
            )
          }
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Dns, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Host a Local Duel", style = MaterialTheme.typography.titleLarge)
          }
          Text(
            text = "Starts an authoritative local duel server on this device.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedTextField(
            value = hostPortText,
            onValueChange = { if (it.length <= 5) hostPortText = it.filter { ch -> ch.isDigit() } },
            label = { Text("Server Port (default 8080)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Button(
            onClick = {
              val port = hostPortText.toIntOrNull()?.takeIf { it in 1024..65535 } ?: 8080
              onStartHost(port)
            },
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("lan_create_game_btn")
          ) {
            Text("Create Local Game")
          }
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Wifi, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Join Local Game", style = MaterialTheme.typography.titleLarge)
          }

          OutlinedButton(
            onClick = onToggleScan,
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("lan_scan_btn")
          ) {
            Icon(Icons.Filled.Radar, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isScanning) "Scanning LAN... (Tap to Stop)" else "Scan Local Network for Hosts")
          }

          if (discoveredHosts.isNotEmpty()) {
            Text("Discovered Hosts", style = MaterialTheme.typography.titleSmall)
            discoveredHosts.forEach { host ->
              Card(
                onClick = { onConnectToHost(host.ipAddress, host.port.toString()) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
                modifier = Modifier
                  .fillMaxWidth()
                  .minimumInteractiveComponentSize()
              ) {
                Row(
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                ) {
                  Column {
                    Text("${host.hostName} (${host.gameId})", style = MaterialTheme.typography.titleSmall)
                    Text("${host.ipAddress}:${host.port}", style = MaterialTheme.typography.labelSmall)
                  }
                  Text("Join", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                }
              }
            }
          } else if (isScanning) {
            Text(
              text = "Listening for Magic Wand hosts on your Wi-Fi... You can also enter IP and Port below.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          OutlinedTextField(
            value = joinIpText,
            onValueChange = { joinIpText = it.trim() },
            label = { Text("Host IP Address (e.g. 192.168.1.25)") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("lan_ip_input")
          )
          OutlinedTextField(
            value = joinPortText,
            onValueChange = { if (it.length <= 5) joinPortText = it.filter { ch -> ch.isDigit() } },
            label = { Text("Port (e.g. 8080)") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("lan_port_input")
          )
          Button(
            onClick = { onConnectToHost(joinIpText, joinPortText) },
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("lan_join_btn")
          ) {
            Text("Join Local Game")
          }
        }
      }
    }
  }
}
