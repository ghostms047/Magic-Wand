package com.example.model

enum class NetworkMessageType {
  PLAYER_JOIN,
  PLAYER_READY,
  CAST_SPELL,
  SPELL_RESULT,
  DAMAGE,
  SHIELD,
  ROUND_START,
  ROUND_END,
  MATCH_END,
  PLAYER_DISCONNECT,
  STATE_SYNC,
  ERROR,
  PING,
  PONG
}

data class NetworkMessage(
  val type: NetworkMessageType,
  val senderId: String,
  val sequence: Long = 0L,
  val spellId: String? = null,
  val playerName: String? = null,
  val text: String? = null,
  val damageAmount: Int = 0,
  val shieldAmount: Int = 0,
  val wandId: String? = null,
  val voiceAccuracy: Int = 85,
  val matchState: MatchState? = null
)

enum class LanMatchStatus {
  WAITING_FOR_PLAYER,
  LOBBY_READY_CHECK,
  IN_PROGRESS,
  FINISHED,
  DISCONNECTED
}

data class MatchState(
  val matchId: String,
  val hostId: String = "host",
  val clientId: String = "client",
  val hostName: String = "Host Wizard",
  val clientName: String = "Challenger",
  val hostReady: Boolean = false,
  val clientReady: Boolean = false,
  val roundNumber: Int = 1,
  val maxHp: Int = 120,
  val activeTurnPlayerId: String = "host",
  val hostState: PlayerState,
  val clientState: PlayerState,
  val status: LanMatchStatus = LanMatchStatus.WAITING_FOR_PLAYER,
  val lastEventText: String = "Waiting for challenger...",
  val comboBanner: String? = null,
  val winnerId: String? = null
)

data class DiscoveredHost(
  val gameId: String,
  val hostName: String,
  val ipAddress: String,
  val port: Int,
  val lastSeenMs: Long = System.currentTimeMillis()
)
