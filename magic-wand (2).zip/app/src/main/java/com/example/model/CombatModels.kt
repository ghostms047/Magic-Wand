package com.example.model

enum class CombatPhase {
  IDLE,
  PLAYER_TURN,
  ENEMY_TURN,
  EFFECT_RESOLUTION,
  ROUND_END,
  VICTORY,
  DEFEAT
}

enum class CombatMode {
  DEATH_EATER_STAGE,
  FREE_BATTLE,
  SANDBOX_BATTLE
}

enum class CastQualityTier(val displayName: String) {
  WEAK("Weak Cast"),
  STANDARD("Clean Cast"),
  STRONG("Strong Cast"),
  CRITICAL("Critical Cast")
}

data class ActiveStatus(
  val type: StatusEffectType,
  val magnitude: Int,
  val remainingTurns: Int
)

data class PlayerState(
  val id: String,
  val name: String,
  val maxHp: Int,
  val hp: Int,
  val maxMana: Int = 100,
  val mana: Int = 100,
  val manaRegen: Int = 18,
  val shield: Int = 0,
  val attackBonus: Int = 0,
  val defense: Int = 0,
  val shieldBonus: Int = 0,
  val healBonus: Int = 0,
  val wandId: String = "wand_oak_phoenix",
  val cooldowns: Map<String, Int> = emptyMap(),
  val statuses: List<ActiveStatus> = emptyList(),
  val lastSpellId: String? = null
) {
  val isStunned: Boolean
    get() = statuses.any { it.type == StatusEffectType.STUN && it.remainingTurns > 0 }

  val weakenPercent: Int
    get() = statuses.filter { it.type == StatusEffectType.WEAKEN && it.remainingTurns > 0 }
      .maxOfOrNull { it.magnitude } ?: 0

  val reflectPercent: Int
    get() = statuses.filter { it.type == StatusEffectType.WARD_REFLECT && it.remainingTurns > 0 }
      .maxOfOrNull { it.magnitude } ?: 0
}

data class CombatAction(
  val actorId: String,
  val spellId: String
)

data class CombatLogEntry(
  val round: Int,
  val message: String,
  val isCombo: Boolean = false,
  val isHighlight: Boolean = false
)

data class Arena(
  val id: String,
  val name: String,
  val subtitle: String,
  val attackModifier: Int = 0,
  val shieldModifier: Int = 0
)

data class CombatState(
  val mode: CombatMode = CombatMode.DEATH_EATER_STAGE,
  val phase: CombatPhase = CombatPhase.IDLE,
  val stageNumber: Int = 1,
  val arena: Arena,
  val roundNumber: Int = 1,
  val maxRounds: Int = 20,
  val turnSecondsLimit: Int = 0,
  val remainingTurnSeconds: Int = 0,
  val difficultyMultiplier: Float = 1.0f,
  val sandboxUnlockAll: Boolean = false,
  val enemy: Enemy? = null,
  val player: PlayerState,
  val opponent: PlayerState,
  val availableSpells: List<Spell> = emptyList(),
  val logs: List<CombatLogEntry> = emptyList(),
  val activeComboBanner: String? = null,
  val lastCastQuality: CastQualityTier? = null,
  val lastEventSummary: String = "Hold the wand and speak a spell."
)
