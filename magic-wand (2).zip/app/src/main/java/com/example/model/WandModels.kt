package com.example.model

enum class WandTrait(val displayName: String, val summary: String) {
  SOLAR_FOCUS("Solar Focus", "Boosts offensive spell potency and arcane focus."),
  AEGIS_WEAVE("Aegis Weave", "Strengthens defensive wards and protective shields."),
  MANA_WELL("Mana Well", "Expands Mana reserves and reduces spell Mana cost."),
  TEMPEST_PACE("Tempest Pace", "Accelerates spell cadence and trims cooldowns."),
  RUNE_PRECISION("Rune Precision", "Sharpens voice & rune casting accuracy tolerance."),
  VITAL_BLOOM("Vital Bloom", "Enhances healing charms and raises maximum vitality."),
  CHRONO_SPARK("Chrono Spark", "Accelerates Mana recovery between duel rounds."),
  SHADOW_PIERCE("Shadow Pierce", "Empowers high-accuracy pronunciations into Critical casts.")
}

data class Wand(
  val id: String,
  val name: String,
  val wood: String,
  val core: String,
  val description: String,
  val castingAccuracyBonus: Int,
  val manaEfficiencyPercent: Int,
  val spellPowerBonus: Int,
  val castingSpeed: Int,
  val cooldownReduction: Int,
  val maxHpBonus: Int = 0,
  val maxManaBonus: Int = 0,
  val passiveTrait: WandTrait,
  val primaryColorHex: Long,
  val secondaryColorHex: Long,
  val coreGlowColorHex: Long
)
