package com.example.engine

import com.example.model.Spell
import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class PronunciationMatchResult(
  val isMatch: Boolean,
  val recognizedText: String,
  val confidencePercent: Int,
  val feedback: String
)

data class SpellVoiceMatchResult(
  val isMatch: Boolean,
  val spell: Spell?,
  val recognizedText: String,
  val rawConfidencePercent: Int,
  val effectiveConfidencePercent: Int,
  val feedback: String
)

/**
 * Deterministic local pronunciation & multi-spell matcher (zero AI/ML).
 * Normalizes speech-recognition hypotheses, evaluates exact/variant strings,
 * and computes normalized Levenshtein + phonetic-skeleton similarity.
 */
object PronunciationMatcher {

  private const val ACCEPT_THRESHOLD = 74
  private const val WAND_BONUS_MIN_RAW_SCORE = 68

  fun evaluate(spell: Spell, hypotheses: List<String>): PronunciationMatchResult {
    val cleanedHypotheses = hypotheses.map { it.trim() }.filter { it.isNotEmpty() }
    if (cleanedHypotheses.isEmpty()) {
      return PronunciationMatchResult(
        isMatch = false,
        recognizedText = "",
        confidencePercent = 0,
        feedback = "No speech detected. Say \"${spell.name}\" (${spell.phoneticGuide})."
      )
    }

    val (bestScore, bestSpoken) = scoreSpell(spell, cleanedHypotheses)
    val accepted = bestScore >= ACCEPT_THRESHOLD
    val feedback = if (accepted) {
      "Recognized \"$bestSpoken\" (${bestScore}% match)."
    } else {
      "Heard \"$bestSpoken\" (${bestScore}%). Expected \"${spell.name}\" (${spell.phoneticGuide})."
    }

    return PronunciationMatchResult(
      isMatch = accepted,
      recognizedText = bestSpoken,
      confidencePercent = bestScore,
      feedback = feedback
    )
  }

  /**
   * Matches a spoken utterance across all eligible spells simultaneously without
   * requiring the player to pre-select a spell in combat.
   */
  fun matchBestSpell(
    candidates: List<Spell>,
    hypotheses: List<String>,
    wandAccuracyBonus: Int = 0
  ): SpellVoiceMatchResult {
    val cleanedHypotheses = hypotheses.map { it.trim() }.filter { it.isNotEmpty() }
    if (cleanedHypotheses.isEmpty()) {
      return SpellVoiceMatchResult(
        isMatch = false,
        spell = null,
        recognizedText = "",
        rawConfidencePercent = 0,
        effectiveConfidencePercent = 0,
        feedback = "No speech detected. Hold the wand button and speak a spell."
      )
    }
    if (candidates.isEmpty()) {
      return SpellVoiceMatchResult(
        isMatch = false,
        spell = null,
        recognizedText = cleanedHypotheses.first(),
        rawConfidencePercent = 0,
        effectiveConfidencePercent = 0,
        feedback = "No eligible spells available to cast."
      )
    }

    data class ScoredCandidate(
      val spell: Spell,
      val rawScore: Int,
      val effectiveScore: Int,
      val spoken: String
    )

    val wandBonus = (wandAccuracyBonus / 2).coerceIn(0, 5)
    val scored = candidates.map { spell ->
      val (raw, spoken) = scoreSpell(spell, cleanedHypotheses)
      val effective = if (raw >= WAND_BONUS_MIN_RAW_SCORE) {
        (raw + wandBonus).coerceAtMost(100)
      } else {
        raw
      }
      ScoredCandidate(spell = spell, rawScore = raw, effectiveScore = effective, spoken = spoken)
    }.sortedWith(
      compareByDescending<ScoredCandidate> { it.rawScore }
        .thenByDescending { it.effectiveScore }
    )

    val best = scored.first()
    val second = scored.getOrNull(1)

    if (best.effectiveScore < ACCEPT_THRESHOLD) {
      return SpellVoiceMatchResult(
        isMatch = false,
        spell = null,
        recognizedText = best.spoken,
        rawConfidencePercent = best.rawScore,
        effectiveConfidencePercent = best.effectiveScore,
        feedback = "Unrecognized incantation: \"${best.spoken}\" (${best.rawScore}%)."
      )
    }

    // Reject ambiguous low-confidence near-ties across distinct spells
    if (second != null && best.rawScore < 86 && (best.rawScore - second.rawScore) <= 1) {
      return SpellVoiceMatchResult(
        isMatch = false,
        spell = null,
        recognizedText = best.spoken,
        rawConfidencePercent = best.rawScore,
        effectiveConfidencePercent = best.effectiveScore,
        feedback = "Unclear incantation \"${best.spoken}\" — pronounce the spell clearly."
      )
    }

    return SpellVoiceMatchResult(
      isMatch = true,
      spell = best.spell,
      recognizedText = best.spoken,
      rawConfidencePercent = best.rawScore,
      effectiveConfidencePercent = best.effectiveScore,
      feedback = "Recognized ${best.spell.name} (${best.effectiveScore}%)"
    )
  }

  private fun scoreSpell(spell: Spell, cleanedHypotheses: List<String>): Pair<Int, String> {
    val targets = (listOf(spell.name) + spell.voiceVariants)
      .map { normalizeText(it) }
      .filter { it.isNotEmpty() }
      .distinct()

    var bestScore = 0
    var bestSpoken = cleanedHypotheses.first()

    for (rawSpoken in cleanedHypotheses) {
      val normSpoken = normalizeText(rawSpoken)
      if (normSpoken.isEmpty()) continue

      val candidatesToCheck = buildList<Pair<String, Int>> {
        // Full utterance has 0 penalty
        add(normSpoken to 0)
        val words = normSpoken.split(' ').filter { it.isNotBlank() }
        if (words.size in 2..6) {
          for (i in 0 until words.size - 1) {
            add("${words[i]} ${words[i + 1]}" to 4)
          }
          for (w in words) {
            if (w.length >= 5) {
              add(w to 10)
            }
          }
        }
      }

      for ((candidate, penalty) in candidatesToCheck) {
        for (target in targets) {
          val score = (similarityPercent(candidate, target) - penalty).coerceAtLeast(0)
          if (score > bestScore) {
            bestScore = score
            bestSpoken = rawSpoken
          }
        }
      }
    }
    return bestScore to bestSpoken
  }

  internal fun normalizeText(input: String): String {
    val decomposed = Normalizer.normalize(input.lowercase(), Normalizer.Form.NFD)
    val ascii = decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    return ascii
      .replace(Regex("[^a-z0-9\\s]"), " ")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  private fun phoneticSkeleton(text: String): String {
    return text
      .replace(" ", "")
      .replace("ph", "f")
      .replace("ae", "e")
      .replace("qu", "kw")
      .replace("x", "ks")
      .replace("ck", "k")
      .replace("c", "k")
      .replace("y", "i")
      .replace(Regex("(.)\\1+"), "$1")
  }

  private fun similarityPercent(spoken: String, target: String): Int {
    if (spoken == target) return 100
    val compactSpoken = spoken.replace(" ", "")
    val compactTarget = target.replace(" ", "")
    if (compactSpoken == compactTarget) return 98

    val rawSim = levenshteinRatio(compactSpoken, compactTarget)
    val phonSim = levenshteinRatio(phoneticSkeleton(spoken), phoneticSkeleton(target))
    val combined = max(rawSim, phonSim * 0.96f)
    return (combined * 100f).roundToInt().coerceIn(0, 100)
  }

  private fun levenshteinRatio(a: String, b: String): Float {
    val maxLen = max(a.length, b.length)
    if (maxLen == 0) return 1f
    val dist = levenshteinDistance(a, b)
    return (1f - (dist.toFloat() / maxLen.toFloat())).coerceIn(0f, 1f)
  }

  private fun levenshteinDistance(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length

    var prev = IntArray(b.length + 1) { it }
    var curr = IntArray(b.length + 1)

    for (i in 1..a.length) {
      curr[0] = i
      for (j in 1..b.length) {
        val cost = if (a[i - 1] == b[j - 1]) 0 else 1
        curr[j] = min(
          min(curr[j - 1] + 1, prev[j] + 1),
          prev[j - 1] + cost
        )
      }
      val tmp = prev
      prev = curr
      curr = tmp
    }
    return prev[b.length]
  }
}
