package com.example.engine

import com.example.model.CastQualityTier
import com.example.model.MasteryLevel
import com.example.model.Spell
import com.example.model.SpellProgress
import com.example.model.Wand
import com.example.model.WandTrait
import kotlin.math.roundToInt

data class CastCalculation(
  val manaCost: Int,
  val effectiveAccuracy: Int,
  val powerMultiplier: Float,
  val qualityTier: CastQualityTier,
  val cooldownReduction: Int
)

data class WandCombatBonuses(
  val attackBonus: Int,
  val shieldBonus: Int,
  val healBonus: Int,
  val maxHpBonus: Int,
  val maxManaBonus: Int,
  val manaRegenBonus: Int,
  val practiceGraceBonus: Int
)

/**
 * Deterministic spell-cast potency & Mana calculator combining:
 * 1. Voice recognition accuracy
 * 2. Spell Mastery & total practice experience
 * 3. Assigned Wand modifiers & passive trait
 */
object CastCalculator {

  fun wandBonuses(wand: Wand): WandCombatBonuses {
    val basePower = wand.spellPowerBonus
    val attack = when (wand.passiveTrait) {
      WandTrait.SOLAR_FOCUS -> basePower + 2
      WandTrait.SHADOW_PIERCE -> basePower + 1
      else -> basePower
    }
    val shield = when (wand.passiveTrait) {
      WandTrait.AEGIS_WEAVE -> basePower + 3
      else -> (basePower / 2)
    }
    val heal = when (wand.passiveTrait) {
      WandTrait.VITAL_BLOOM -> basePower + 3
      else -> (basePower / 2)
    }
    val extraMana = if (wand.passiveTrait == WandTrait.MANA_WELL) 10 else 0
    val manaRegen = if (wand.passiveTrait == WandTrait.CHRONO_SPARK) 4 else 0
    val grace = if (wand.passiveTrait == WandTrait.RUNE_PRECISION) 6 else 2

    return WandCombatBonuses(
      attackBonus = attack,
      shieldBonus = shield,
      healBonus = heal,
      maxHpBonus = wand.maxHpBonus,
      maxManaBonus = wand.maxManaBonus + extraMana,
      manaRegenBonus = manaRegen,
      practiceGraceBonus = grace
    )
  }

  fun effectiveManaCost(spell: Spell, wand: Wand): Int {
    val traitSavings = if (wand.passiveTrait == WandTrait.MANA_WELL) 5 else 0
    val efficiency = (wand.manaEfficiencyPercent + traitSavings).coerceIn(0, 35)
    return ((spell.manaCost * (100 - efficiency)) / 100f)
      .roundToInt()
      .coerceAtLeast(4)
  }

  fun evaluateCast(
    spell: Spell,
    voiceAccuracyPercent: Int,
    progress: SpellProgress?,
    wand: Wand
  ): CastCalculation {
    val manaCost = effectiveManaCost(spell, wand)
    val clampedVoice = voiceAccuracyPercent.coerceIn(50, 100)
    val effectiveAcc = (clampedVoice + (wand.castingAccuracyBonus / 2)).coerceIn(50, 100)

    val masteryBonus = when (progress?.masteryLevel) {
      MasteryLevel.MASTERED -> 0.16f
      MasteryLevel.SKILLED -> 0.10f
      MasteryLevel.LEARNED -> 0.04f
      MasteryLevel.LEARNING -> -0.05f
      else -> 0f
    }

    val experienceBonus = ((progress?.successfulPractices ?: 0).coerceAtMost(20) * 0.004f)
    val avgAccBonus = if ((progress?.totalAttempts ?: 0) > 0 && (progress?.averageAccuracy ?: 0) >= 88) {
      0.03f
    } else {
      0f
    }

    // Accuracy factor: 70 -> 0.82f, 85 -> 0.94f, 100 -> 1.06f
    val accuracyFactor = 0.78f + ((effectiveAcc - 65).coerceIn(0, 35) * 0.008f)
    val traitBonus = if (wand.passiveTrait == WandTrait.SHADOW_PIERCE && effectiveAcc >= 88) 0.08f else 0f

    val multiplier = (accuracyFactor + masteryBonus + experienceBonus + avgAccBonus + traitBonus)
      .coerceIn(0.72f, 1.38f)

    val tier = when {
      multiplier >= 1.18f -> CastQualityTier.CRITICAL
      multiplier >= 1.02f -> CastQualityTier.STRONG
      multiplier >= 0.86f -> CastQualityTier.STANDARD
      else -> CastQualityTier.WEAK
    }

    return CastCalculation(
      manaCost = manaCost,
      effectiveAccuracy = effectiveAcc,
      powerMultiplier = multiplier,
      qualityTier = tier,
      cooldownReduction = wand.cooldownReduction
    )
  }
}
