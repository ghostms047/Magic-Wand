package com.example.engine

import com.example.model.Enemy
import com.example.model.EnemyBehavior
import com.example.model.PlayerState
import com.example.model.Spell
import com.example.model.SpellCategory
import com.example.model.StatusEffectType

object EnemyDecisionEngine {

  /**
   * Deterministic rule-based state machine selecting the enemy's next spell.
   * Zero AI/ML — driven purely by behavior profile, cooldowns, HP thresholds, and player state.
   */
  fun chooseSpell(
    enemy: Enemy,
    enemyState: PlayerState,
    playerState: PlayerState,
    allSpellsById: Map<String, Spell>,
    roundNumber: Int
  ): Spell? {
    val offCooldown = enemy.availableSpellIds
      .mapNotNull { allSpellsById[it] }
      .filter { (enemyState.cooldowns[it.id] ?: 0) == 0 }
    val readySpells = offCooldown
      .filter { it.manaCost <= enemyState.mana }
      .ifEmpty { offCooldown.filter { it.manaCost <= 14 } }

    if (readySpells.isEmpty()) {
      return allSpellsById["lumos_spark"] ?: allSpellsById.values.firstOrNull()
    }

    val hpPercent = (enemyState.hp * 100) / enemyState.maxHp.coerceAtLeast(1)
    val playerHasHighShield = playerState.shield >= 15

    return when (enemy.behavior) {
      EnemyBehavior.FAST_ATTACKER -> {
        // Prefers low-cooldown offensive spells; rarely shields when low HP
        if (hpPercent <= 35 && enemyState.shield == 0) {
          readySpells.firstOrNull { it.baseShield > 0 }
        } else {
          null
        } ?: readySpells.minWithOrNull(compareBy<Spell> { it.cooldown }.thenByDescending { it.baseDamage })
      }

      EnemyBehavior.AGGRESSIVE -> {
        // Prioritizes Burn/Damage, heals only when critically injured (<25%)
        if (hpPercent < 25) {
          readySpells.firstOrNull { it.baseHeal > 0 }
        } else {
          null
        } ?: readySpells.maxWithOrNull(
          compareBy<Spell> { it.baseDamage + if (it.statusType == StatusEffectType.BURN) 8 else 0 }
            .thenBy { it.cooldown }
        )
      }

      EnemyBehavior.DEFENSIVE -> {
        // Maintains shields proactively, heals below 55% HP, otherwise controls/attacks
        when {
          hpPercent < 55 && readySpells.any { it.baseHeal > 0 } ->
            readySpells.filter { it.baseHeal > 0 }.maxByOrNull { it.baseHeal }
          enemyState.shield < 12 && readySpells.any { it.baseShield > 0 } ->
            readySpells.filter { it.baseShield > 0 }.maxByOrNull { it.baseShield }
          else ->
            readySpells.maxByOrNull { it.baseDamage + it.baseShield }
        }
      }

      EnemyBehavior.COUNTER_FOCUSED -> {
        // Strips player shields/buffs with Control spells, stuns when player is aggressive, punishes openings
        when {
          playerHasHighShield && readySpells.any { it.category == SpellCategory.CONTROL } ->
            readySpells.filter { it.category == SpellCategory.CONTROL }.maxByOrNull { it.baseDamage }
          roundNumber % 3 == 0 && readySpells.any { it.statusType == StatusEffectType.STUN } ->
            readySpells.first { it.statusType == StatusEffectType.STUN }
          enemyState.shield == 0 && hpPercent < 60 && readySpells.any { it.baseShield > 0 } ->
            readySpells.filter { it.baseShield > 0 }.maxByOrNull { it.baseShield }
          else ->
            readySpells.maxByOrNull { it.baseDamage + if (it.statusType == StatusEffectType.WEAKEN) 6 else 0 }
        }
      }

      EnemyBehavior.HEAVY_ATTACKER -> {
        // Alternates defensive/regen setup with highest-power Forbidden/Special spells
        when {
          hpPercent < 40 && readySpells.any { it.baseHeal > 0 } ->
            readySpells.filter { it.baseHeal > 0 }.maxByOrNull { it.baseHeal }
          enemyState.shield == 0 && roundNumber % 3 == 1 && readySpells.any { it.baseShield > 0 } ->
            readySpells.filter { it.baseShield > 0 }.maxByOrNull { it.baseShield }
          else ->
            readySpells.maxByOrNull { it.baseDamage }
        }
      }
    } ?: readySpells.first()
  }
}
