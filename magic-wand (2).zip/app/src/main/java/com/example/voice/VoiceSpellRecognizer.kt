package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceUiPhase {
  IDLE,
  LISTENING,
  PROCESSING,
  RECOGNIZED,
  REJECTED,
  SUCCESS,
  UNAVAILABLE
}

data class VoiceSessionState(
  val phase: VoiceUiPhase = VoiceUiPhase.IDLE,
  val partialText: String = "",
  val spokenText: String = "",
  val rmsLevel: Float = 0f,
  val statusMessage: String = "Tap the microphone and speak the spell.",
  val isSpeechServiceAvailable: Boolean = true
)

/**
 * Lifecycle-safe wrapper around Android's native SpeechRecognizer.
 * Supports both tap-to-listen (Practice Mode) and press-hold-release (Combat Wand Mode).
 * Operates strictly on the Main Looper as required by Android SpeechRecognizer.
 */
class VoiceSpellRecognizer(context: Context) {

  private val appContext = context.applicationContext
  private val mainHandler = Handler(Looper.getMainLooper())
  private var recognizer: SpeechRecognizer? = null
  private var isListeningActive = false
  private var isHoldSession = false
  private var holdStartTimeMs = 0L
  private var latestPartialText = ""
  private var currentCallback: ((List<String>) -> Unit)? = null
  private var pendingTimeoutRunnable: Runnable? = null

  private val _state = MutableStateFlow(
    VoiceSessionState(
      isSpeechServiceAvailable = SpeechRecognizer.isRecognitionAvailable(appContext)
    )
  )
  val state: StateFlow<VoiceSessionState> = _state.asStateFlow()

  fun checkAvailability(): Boolean {
    val available = SpeechRecognizer.isRecognitionAvailable(appContext)
    if (!available) {
      _state.value = _state.value.copy(
        phase = VoiceUiPhase.UNAVAILABLE,
        isSpeechServiceAvailable = false,
        statusMessage = "On-device Speech Recognition service is unavailable on this device."
      )
    }
    return available
  }

  /**
   * Tap-to-listen flow used by Practice Mode.
   */
  fun startListening(promptLabel: String, onHypotheses: (List<String>) -> Unit) {
    startInternal(
      promptMessage = "Listening for $promptLabel...",
      holdMode = false,
      onHypotheses = onHypotheses
    )
  }

  /**
   * Press-and-hold flow used by Wand Combat Mode.
   */
  fun beginHoldListening(onHypotheses: (List<String>) -> Unit) {
    startInternal(
      promptMessage = "Listening... Speak your spell, then release.",
      holdMode = true,
      onHypotheses = onHypotheses
    )
  }

  /**
   * Called when player releases the Hold-to-Cast Wand button.
   * Stops active capture so Android SpeechRecognizer finalizes hypotheses,
   * with a safety timeout so the UI can never hang in PROCESSING.
   */
  fun releaseHoldAndFinalize() {
    mainHandler.post {
      if (!isListeningActive || !isHoldSession) return@post
      val heldMs = SystemClock.elapsedRealtime() - holdStartTimeMs
      val partial = latestPartialText.trim()

      if (heldMs < MIN_HOLD_DURATION_MS && partial.isEmpty()) {
        val cb = currentCallback
        stopInternal()
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.REJECTED,
          rmsLevel = 0f,
          statusMessage = "Hold the wand button while speaking a spell."
        )
        cb?.invoke(emptyList())
        return@post
      }

      _state.value = _state.value.copy(
        phase = VoiceUiPhase.PROCESSING,
        rmsLevel = 0f,
        statusMessage = "Channeling incantation..."
      )

      runCatching { recognizer?.stopListening() }
      scheduleProcessingFailsafe()
    }
  }

  private fun startInternal(
    promptMessage: String,
    holdMode: Boolean,
    onHypotheses: (List<String>) -> Unit
  ) {
    mainHandler.post {
      if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.UNAVAILABLE,
          isSpeechServiceAvailable = false,
          statusMessage = "Speech recognition service unavailable on this device."
        )
        return@post
      }

      stopInternal()
      currentCallback = onHypotheses
      isHoldSession = holdMode
      holdStartTimeMs = SystemClock.elapsedRealtime()
      latestPartialText = ""

      try {
        val sr = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = sr
        sr.setRecognitionListener(createListener())

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
          putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
          putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
          putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
          if (holdMode) {
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
          }
        }

        isListeningActive = true
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.LISTENING,
          statusMessage = promptMessage,
          isSpeechServiceAvailable = true
        )
        sr.startListening(intent)
      } catch (e: Exception) {
        isListeningActive = false
        isHoldSession = false
        currentCallback = null
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.UNAVAILABLE,
          isSpeechServiceAvailable = false,
          statusMessage = "Could not start microphone recognition: ${e.message ?: "Unavailable"}"
        )
      }
    }
  }

  private fun scheduleProcessingFailsafe() {
    cancelProcessingFailsafe()
    val timeoutTask = Runnable {
      if (!isListeningActive) return@Runnable
      val cb = currentCallback
      val fallbackPartial = latestPartialText.trim()
      stopInternal()
      if (fallbackPartial.isNotEmpty()) {
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.RECOGNIZED,
          spokenText = fallbackPartial,
          rmsLevel = 0f
        )
        cb?.invoke(listOf(fallbackPartial))
      } else {
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.REJECTED,
          rmsLevel = 0f,
          statusMessage = "No speech detected. Hold button and pronounce a spell."
        )
        cb?.invoke(emptyList())
      }
    }
    pendingTimeoutRunnable = timeoutTask
    mainHandler.postDelayed(timeoutTask, POST_RELEASE_TIMEOUT_MS)
  }

  private fun cancelProcessingFailsafe() {
    pendingTimeoutRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingTimeoutRunnable = null
  }

  fun markAccepted(spokenText: String, feedback: String) {
    _state.value = _state.value.copy(
      phase = VoiceUiPhase.SUCCESS,
      spokenText = spokenText,
      rmsLevel = 0f,
      statusMessage = feedback
    )
  }

  fun markRejected(spokenText: String, feedback: String) {
    _state.value = _state.value.copy(
      phase = VoiceUiPhase.REJECTED,
      spokenText = spokenText,
      rmsLevel = 0f,
      statusMessage = feedback
    )
  }

  fun resetToIdle(message: String = "Tap the microphone and speak the spell.") {
    mainHandler.post {
      stopInternal()
      _state.value = VoiceSessionState(
        phase = VoiceUiPhase.IDLE,
        statusMessage = message,
        isSpeechServiceAvailable = SpeechRecognizer.isRecognitionAvailable(appContext)
      )
    }
  }

  fun stopListening() {
    mainHandler.post {
      stopInternal()
      if (_state.value.phase == VoiceUiPhase.LISTENING || _state.value.phase == VoiceUiPhase.PROCESSING) {
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.IDLE,
          rmsLevel = 0f,
          statusMessage = "Listening cancelled."
        )
      }
    }
  }

  fun destroy() {
    mainHandler.post {
      stopInternal()
    }
  }

  private fun stopInternal() {
    cancelProcessingFailsafe()
    isListeningActive = false
    isHoldSession = false
    latestPartialText = ""
    currentCallback = null
    runCatching { recognizer?.cancel() }
    runCatching { recognizer?.destroy() }
    recognizer = null
  }

  private fun createListener(): RecognitionListener {
    return object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) {
        if (isListeningActive) {
          _state.value = _state.value.copy(phase = VoiceUiPhase.LISTENING)
        }
      }

      override fun onBeginningOfSpeech() = Unit

      override fun onRmsChanged(rmsdB: Float) {
        if (isListeningActive) {
          val norm = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
          _state.value = _state.value.copy(rmsLevel = norm)
        }
      }

      override fun onBufferReceived(buffer: ByteArray?) = Unit

      override fun onEndOfSpeech() {
        if (isListeningActive) {
          _state.value = _state.value.copy(
            phase = VoiceUiPhase.PROCESSING,
            rmsLevel = 0f,
            statusMessage = "Processing pronunciation..."
          )
        }
      }

      override fun onError(error: Int) {
        if (!isListeningActive) return
        val cb = currentCallback
        val partialFallback = latestPartialText.trim()
        stopInternal()

        if ((error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) &&
          partialFallback.isNotEmpty()
        ) {
          _state.value = _state.value.copy(
            phase = VoiceUiPhase.RECOGNIZED,
            spokenText = partialFallback,
            rmsLevel = 0f
          )
          cb?.invoke(listOf(partialFallback))
          return
        }

        val message = when (error) {
          SpeechRecognizer.ERROR_NO_MATCH -> "Could not understand speech. Speak clearly and try again."
          SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Hold the wand and speak a spell."
          SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error. Check device microphone."
          SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
          SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy. Try again in a moment."
          SpeechRecognizer.ERROR_NETWORK,
          SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Offline voice pack unavailable; check speech settings or device network."
          else -> "Voice recognition failed (code $error). Try again."
        }
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.REJECTED,
          rmsLevel = 0f,
          statusMessage = message
        )
        if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
          cb?.invoke(emptyList())
        }
      }

      override fun onResults(results: Bundle?) {
        if (!isListeningActive) return
        val cb = currentCallback
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val partialFallback = latestPartialText.trim()
        stopInternal()

        val finalMatches = if (matches.isNotEmpty()) {
          matches
        } else if (partialFallback.isNotEmpty()) {
          listOf(partialFallback)
        } else {
          emptyList()
        }

        val bestText = finalMatches.firstOrNull().orEmpty()
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.RECOGNIZED,
          spokenText = bestText,
          rmsLevel = 0f
        )
        cb?.invoke(finalMatches)
      }

      override fun onPartialResults(partialResults: Bundle?) {
        if (!isListeningActive) return
        val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
          ?.firstOrNull().orEmpty()
        if (partial.isNotBlank()) {
          latestPartialText = partial
          _state.value = _state.value.copy(partialText = partial)
        }
      }

      override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }
  }

  private companion object {
    private const val MIN_HOLD_DURATION_MS = 240L
    private const val POST_RELEASE_TIMEOUT_MS = 2400L
  }
}
