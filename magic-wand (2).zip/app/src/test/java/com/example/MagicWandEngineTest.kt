package com.example

import com.example.data.ArenaCatalog
import com.example.data.EnemyCatalog
import com.example.data.WandCatalog
import com.example.engine.CastCalculator
import com.example.engine.CombatEngine
import com.example.engine.EnemyDecisionEngine
import com.example.engine.MasteryCalculator
import com.example.engine.PatternValidator
import com.example.engine.PronunciationMatcher
import com.example.model.CastQualityTier
import com.example.model.ComboDefinition
import com.example.model.MasteryLevel
import com.example.model.PlayerState
import com.example.model.Spell
import com.example.model.SpellCategory
import com.example.model.SpellProgress
import com.example.model.StatusEffectType
import com.example.network.LanIpHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MagicWandEngineTest {

  private val protego = Spell(
    id = "protego",
    name = "Protego",
    category = SpellCategory.DEFENSIVE,
    description = "Barrier",
    difficulty = 2,
    requiredPractice = 5,
    cooldown = 1,
    combatAvailable = true,
    starterUnlocked = false,
    baseDamage = 0,
    baseShield = 24,
    baseHeal = 0,
    statusType = StatusEffectType.NONE,
    statusMagnitude = 0,
    statusDuration = 0,
    patternNodes = listOf(3, 1, 5, 7),
    patternHint = "",
    phoneticIpa = "/proʊˈteɪɡoʊ/",
    phoneticGuide = "pro-TEE-goh",
    voiceVariants = listOf("protego", "pro tego", "protecto", "protago"),
    manaCost = 16
  )

  private val glacius = Spell(
    id = "glacius",
    name = "Glacius",
    category = SpellCategory.CONTROL,
    description = "Frost",
    difficulty = 2,
    requiredPractice = 4,
    cooldown = 1,
    combatAvailable = true,
    starterUnlocked = false,
    baseDamage = 15,
    baseShield = 6,
    baseHeal = 0,
    statusType = StatusEffectType.WEAKEN,
    statusMagnitude = 25,
    statusDuration = 2,
    patternNodes = listOf(0, 4, 8, 5, 2),
    patternHint = "",
    phoneticIpa = "/ˈɡleɪʃəs/",
    phoneticGuide = "GLAY-shus",
    voiceVariants = listOf("glacius", "glacious", "glashus"),
    manaCost = 16
  )

  private val incendio = Spell(
    id = "incendio",
    name = "Incendio",
    category = SpellCategory.OFFENSIVE,
    description = "Fire",
    difficulty = 2,
    requiredPractice = 4,
    cooldown = 1,
    combatAvailable = true,
    starterUnlocked = false,
    baseDamage = 20,
    baseShield = 0,
    baseHeal = 0,
    statusType = StatusEffectType.BURN,
    statusMagnitude = 6,
    statusDuration = 2,
    patternNodes = listOf(6, 3, 1, 5, 8),
    patternHint = "",
    phoneticIpa = "/ɪnˈsɛndioʊ/",
    phoneticGuide = "in-SEN-dee-oh",
    voiceVariants = listOf("incendio", "in sendio", "incendo"),
    manaCost = 16
  )

  @Test
  fun pronunciationMatcher_acceptsValidPronunciations_andRejectsUnrelatedWords() {
    val exact = PronunciationMatcher.evaluate(protego, listOf("Protego"))
    assertTrue(exact.isMatch)
    assertEquals(100, exact.confidencePercent)

    val multiMatch = PronunciationMatcher.matchBestSpell(
      candidates = listOf(protego, glacius, incendio),
      hypotheses = listOf("in sendio"),
      wandAccuracyBonus = 5
    )
    assertTrue(multiMatch.isMatch)
    assertEquals("incendio", multiMatch.spell?.id)

    val noisy = PronunciationMatcher.matchBestSpell(
      candidates = listOf(protego, glacius, incendio),
      hypotheses = listOf("cast protego now")
    )
    assertTrue(noisy.isMatch)
    assertEquals("protego", noisy.spell?.id)

    for (junk in listOf("Hello", "Banana", "Something else", "attack", "shield", "")) {
      val rejected = PronunciationMatcher.matchBestSpell(
        candidates = listOf(protego, glacius, incendio),
        hypotheses = if (junk.isEmpty()) emptyList() else listOf(junk),
        wandAccuracyBonus = 8
      )
      assertFalse("Expected '$junk' to be rejected", rejected.isMatch)
    }
  }

  @Test
  fun wandCatalog_hasExactly16UniqueWands() {
    assertEquals(16, WandCatalog.wands.size)
    assertEquals(16, WandCatalog.wands.map { it.id }.distinct().size)
    assertEquals(16, WandCatalog.wands.map { it.name }.distinct().size)
    assertTrue(WandCatalog.wands.all { it.manaEfficiencyPercent > 0 && it.castingSpeed > 0 })
  }

  @Test
  fun castCalculator_scalesWithAccuracyMasteryAndWandModifiers() {
    val vineWand = WandCatalog.getById("wand_vine_kelpie") // 18% + 5% Mana Well
    val yewWand = WandCatalog.getById("wand_yew_dragon") // Shadow Pierce +6 Power

    val vineCost = CastCalculator.effectiveManaCost(incendio, vineWand)
    val yewCost = CastCalculator.effectiveManaCost(incendio, yewWand)
    assertTrue("Vine wand should have lower Mana cost ($vineCost < $yewCost)", vineCost < yewCost)

    val lowProgress = SpellProgress(spellId = incendio.id, successfulPractices = 1, masteryLevel = MasteryLevel.LEARNING)
    val masteredProgress = SpellProgress(
      spellId = incendio.id,
      successfulPractices = 15,
      totalAttempts = 15,
      totalAccuracySum = 1425,
      masteryLevel = MasteryLevel.MASTERED
    )

    val weakCast = CastCalculator.evaluateCast(incendio, voiceAccuracyPercent = 72, progress = lowProgress, wand = yewWand)
    val strongCast = CastCalculator.evaluateCast(incendio, voiceAccuracyPercent = 98, progress = masteredProgress, wand = yewWand)

    assertTrue(strongCast.powerMultiplier > weakCast.powerMultiplier)
    assertEquals(CastQualityTier.CRITICAL, strongCast.qualityTier)
  }

  @Test
  fun patternValidator_succeedsOnExactTrace_andFailsOnWrongPattern() {
    val exactStroke = protego.patternNodes.map { PatternValidator.nodeCenter(it) }
    val success = PatternValidator.validateTrace(
      expectedNodes = protego.patternNodes,
      hitNodes = protego.patternNodes,
      strokePoints = exactStroke
    )
    assertTrue(success.isSuccess)
    assertTrue(success.accuracyPercent >= 95)

    val failure = PatternValidator.validateTrace(
      expectedNodes = protego.patternNodes,
      hitNodes = listOf(3, 1, 4),
      strokePoints = exactStroke
    )
    assertFalse(failure.isSuccess)
    assertTrue(failure.accuracyPercent < 50)
  }

  @Test
  fun masteryCalculator_doesNotAdvanceOnFailure_andUnlocksAtRequiredCount() {
    var prog = SpellProgress(spellId = protego.id)
    prog = MasteryCalculator.recordPracticeAttempt(protego, prog, isSuccess = false, accuracyPercent = 20)
    assertEquals(0, prog.successfulPractices)
    assertFalse(prog.unlocked)
    assertEquals(MasteryLevel.LOCKED, prog.masteryLevel)

    repeat(4) {
      prog = MasteryCalculator.recordPracticeAttempt(protego, prog, isSuccess = true, accuracyPercent = 90)
    }
    assertEquals(4, prog.successfulPractices)
    assertFalse(prog.unlocked)
    assertEquals(MasteryLevel.LEARNING, prog.masteryLevel)

    prog = MasteryCalculator.recordPracticeAttempt(protego, prog, isSuccess = true, accuracyPercent = 90)
    assertTrue(prog.unlocked)
    assertEquals(MasteryLevel.LEARNED, prog.masteryLevel)

    repeat(4) {
      prog = MasteryCalculator.recordPracticeAttempt(protego, prog, isSuccess = true, accuracyPercent = 90)
    }
    assertEquals(MasteryLevel.SKILLED, prog.masteryLevel)

    repeat(4) {
      prog = MasteryCalculator.recordPracticeAttempt(protego, prog, isSuccess = true, accuracyPercent = 92)
    }
    assertEquals(MasteryLevel.MASTERED, prog.masteryLevel)
  }

  @Test
  fun combatEngine_deductsAndRegeneratesMana_andTriggersCombo() {
    val combo = ComboDefinition(
      id = "combo_thermal_shatter",
      name = "Thermal Shatter",
      firstSpellId = "glacius",
      secondSpellId = "incendio",
      bonusDamage = 18,
      bonusShield = 0,
      bonusHeal = 0,
      shatterEnemyShield = true,
      description = "Shatters shields!"
    )
    val actor = PlayerState(
      id = "p1",
      name = "Wizard",
      maxHp = 100,
      hp = 100,
      maxMana = 100,
      mana = 50,
      manaRegen = 18,
      lastSpellId = "glacius"
    )
    val target = PlayerState(id = "e1", name = "Foe", maxHp = 100, hp = 100, shield = 30)

    val outcome = CombatEngine.resolveSpellCast(
      actor = actor,
      target = target,
      spell = incendio,
      combos = listOf(combo),
      arena = ArenaCatalog.arenas.first(),
      damageMultiplier = 1.0f,
      manaCost = 15,
      castQuality = CastQualityTier.STANDARD
    )

    assertNotNull(outcome.comboTriggered)
    assertEquals(0, outcome.updatedTarget.shield)
    assertEquals(38, outcome.damageDealtToHp)
    assertEquals(62, outcome.updatedTarget.hp)
    assertEquals(35, outcome.updatedActor.mana)
    assertTrue(outcome.updatedTarget.statuses.any { it.type == StatusEffectType.BURN })

    val endTick = CombatEngine.resolveEndOfRound(outcome.updatedActor)
    assertEquals(53, endTick.updatedState.mana)
    assertEquals(18, endTick.manaRecovered)
  }

  @Test
  fun enemyDecisionEngine_defensiveShieldsWhenUnshielded_andRespectsMana() {
    val enemy = EnemyCatalog.enemies.first { it.id == "de_wardbreaker" }
    val spellsById = listOf(protego, glacius, incendio).associateBy { it.id }
    val enemyState = PlayerState(id = enemy.id, name = enemy.name, maxHp = enemy.maxHp, hp = enemy.maxHp, mana = 50, shield = 0)
    val playerState = PlayerState(id = "p1", name = "Wizard", maxHp = 100, hp = 100)

    val chosen = EnemyDecisionEngine.chooseSpell(enemy, enemyState, playerState, spellsById, roundNumber = 1)
    assertNotNull(chosen)
    assertEquals("protego", chosen?.id)
  }

  @Test
  fun lanIpHelper_validatesIpAndPortsStrictly() {
    assertTrue(LanIpHelper.isValidIpAddressInput("192.168.1.25"))
    assertFalse(LanIpHelper.isValidIpAddressInput("999.168.1.25"))
    assertFalse(LanIpHelper.isValidIpAddressInput("not.an.ip"))
    assertEquals(8080, LanIpHelper.parseValidPort("8080"))
    assertNull(LanIpHelper.parseValidPort("80"))
    assertNull(LanIpHelper.parseValidPort("70000"))
  }
}
