package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GameSaveRepository
import com.example.data.SpellCatalogRepository
import com.example.data.WandCatalog
import com.example.engine.CastCalculator
import com.example.engine.PronunciationMatcher
import com.example.model.CombatPhase
import com.example.model.LanMatchStatus
import com.example.model.MatchState
import com.example.model.NetworkMessage
import com.example.model.NetworkMessageType
import com.example.model.PlayerState
import com.example.model.SpellCategory
import com.example.network.LanDiscoveryManager
import com.example.network.LanMultiplayerManager
import com.example.network.LanRole
import com.example.network.NetworkMessageCodec
import com.example.ui.MainViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun appName_andCatalogAssets_loadProperly() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Magic Wand", appName)

    val repo = SpellCatalogRepository(context)
    val spells = repo.getAllSpells()
    val combos = repo.getAllCombos()
    assertTrue("Expected at least 55 spells, found ${spells.size}", spells.size >= 55)
    assertTrue(combos.size >= 10)
    assertEquals(SpellCategory.entries.toSet(), spells.map { it.category }.toSet())
    assertTrue(spells.all { it.patternNodes.size >= 3 && it.patternNodes.distinct().size == it.patternNodes.size })
    assertTrue(spells.all { it.phoneticGuide.isNotBlank() && it.voiceVariants.isNotEmpty() && it.manaCost >= 8 })
  }

  @Test
  fun voiceRecognition_matchesAll62SpellsCleanly_andContainsNoNonsenseVariants() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val spells = SpellCatalogRepository(context).getAllSpells()
    val combatSpells = spells.filter { it.combatAvailable }

    val bannedWords = setOf("potato", "stupidify", "rectum", "umbrella", "vulgar", "pesky")
    for (spell in spells) {
      for (variant in spell.voiceVariants) {
        val lower = variant.lowercase()
        assertFalse(
          "Banned variant '$variant' found in ${spell.id}",
          bannedWords.any { lower.contains(it) }
        )
      }
      // Practice evaluation matches canonical spell name
      assertTrue("Failed evaluate for ${spell.id}", PronunciationMatcher.evaluate(spell, listOf(spell.name)).isMatch)
    }

    // Multi-spell combat recognition must map every combat spell name back to itself
    for (spell in combatSpells) {
      val match = PronunciationMatcher.matchBestSpell(combatSpells, listOf(spell.name))
      assertTrue("Combat multi-match failed for ${spell.name}", match.isMatch)
      assertEquals("Expected ${spell.id} for '${spell.name}' but got ${match.spell?.id}", spell.id, match.spell?.id)
    }

    // Random unrelated speech rejected across full 57 combat spells
    for (junk in listOf("hello world", "banana split", "open door", "good morning", "test microphone")) {
      val junkResult = PronunciationMatcher.matchBestSpell(combatSpells, listOf(junk), wandAccuracyBonus = 8)
      assertFalse("Unrelated phrase '$junk' falsely matched ${junkResult.spell?.id}", junkResult.isMatch)
    }
  }

  @Test
  fun saveRepository_assignsRandomWandOnce_andRestoresSameWandAcrossRestarts() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val spells = SpellCatalogRepository(context).getAllSpells()
    val saveRepo = GameSaveRepository(context)

    val fresh = saveRepo.resetAll(spells)
    assertTrue("Expected assigned wand to be one of the 16 Wands", WandCatalog.hasWand(fresh.selectedWandId))
    assertTrue(fresh.spellProgressMap["lumos_spark"]?.unlocked == true)
    assertFalse(fresh.spellProgressMap["protego"]?.unlocked == true)

    val assignedWandId = fresh.selectedWandId

    // Reload multiple times: wand must NEVER reroll on restart
    val reload1 = saveRepo.load(spells)
    val reload2 = saveRepo.load(spells)
    assertEquals(assignedWandId, reload1.selectedWandId)
    assertEquals(assignedWandId, reload2.selectedWandId)

    val modified = fresh.copy(
      highestStageCleared = 2,
      voiceCastsSucceeded = 7,
      recentSpellId = "protego",
      settings = fresh.settings.copy(wizardName = "Alaric")
    )
    saveRepo.save(modified)

    val restored = saveRepo.load(spells)
    assertEquals(assignedWandId, restored.selectedWandId)
    assertEquals(2, restored.highestStageCleared)
    assertEquals(7, restored.voiceCastsSucceeded)
    assertEquals("protego", restored.recentSpellId)
    assertEquals("Alaric", restored.settings.wizardName)
  }

  @Test
  fun networkMessageCodec_roundTripsManaWandIdAndVoiceAccuracy_andRejectsMalformed() {
    val match = MatchState(
      matchId = "MW-4242",
      hostName = "Host",
      clientName = "Guest",
      status = LanMatchStatus.IN_PROGRESS,
      hostState = PlayerState(
        id = "host",
        name = "Host",
        maxHp = 125,
        hp = 100,
        maxMana = 120,
        mana = 82,
        wandId = "wand_vine_kelpie"
      ),
      clientState = PlayerState(
        id = "client",
        name = "Guest",
        maxHp = 120,
        hp = 95,
        maxMana = 105,
        mana = 74,
        wandId = "wand_yew_dragon"
      )
    )
    val syncMsg = NetworkMessage(
      type = NetworkMessageType.STATE_SYNC,
      senderId = "host",
      sequence = 7L,
      text = "Round 1",
      matchState = match
    )
    val decoded = NetworkMessageCodec.decode(NetworkMessageCodec.encode(syncMsg))
    assertNotNull(decoded)
    assertEquals(NetworkMessageType.STATE_SYNC, decoded?.type)
    assertEquals("wand_vine_kelpie", decoded?.matchState?.hostState?.wandId)
    assertEquals("wand_yew_dragon", decoded?.matchState?.clientState?.wandId)
    assertEquals(82, decoded?.matchState?.hostState?.mana)
    assertEquals(74, decoded?.matchState?.clientState?.mana)

    val castMsg = NetworkMessage(
      type = NetworkMessageType.CAST_SPELL,
      senderId = "client",
      sequence = 9L,
      spellId = "incendio",
      voiceAccuracy = 93
    )
    val decodedCast = NetworkMessageCodec.decode(NetworkMessageCodec.encode(castMsg))
    assertEquals("incendio", decodedCast?.spellId)
    assertEquals(93, decodedCast?.voiceAccuracy)

    assertNull(NetworkMessageCodec.decode("{invalid json"))
    assertNull(NetworkMessageCodec.decode(""))
  }

  @Test
  fun mainViewModel_soloCombatVoiceFlow_enforcesLockedSpellsAndMana() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val vm = MainViewModel(app)
    vm.resetAllProgress()
    vm.startDeathEaterStage(1)

    val initialState = vm.combatState.value
    assertNotNull(initialState)
    assertEquals(CombatPhase.PLAYER_TURN, initialState?.phase)
    val startMana = initialState!!.player.mana
    val enemyStartHp = initialState.opponent.hp

    // Unrelated phrase must not consume Mana or forfeit the turn
    vm.submitFallbackCombatIncantation("banana split", isLanMatch = false)
    assertEquals(CombatPhase.PLAYER_TURN, vm.combatState.value?.phase)
    assertEquals(startMana, vm.combatState.value?.player?.mana)

    // Locked spell must be rejected clearly without casting
    vm.submitFallbackCombatIncantation("Protego", isLanMatch = false)
    assertEquals(CombatPhase.PLAYER_TURN, vm.combatState.value?.phase)
    assertTrue(vm.combatVoiceFeedback.value.orEmpty().contains("not learned", ignoreCase = true))
    assertEquals(startMana, vm.combatState.value?.player?.mana)

    // Unlocked starter spell ("Lumos Spark") casts cleanly, spends Mana, damages foe
    val lumosSpell = vm.allSpells.first { it.id == "lumos_spark" }
    val wand = WandCatalog.getById(initialState.player.wandId)
    val expectedCost = CastCalculator.effectiveManaCost(lumosSpell, wand)

    vm.submitFallbackCombatIncantation("Lumos Spark", isLanMatch = false)
    val afterCast = vm.combatState.value!!
    assertEquals(startMana - expectedCost, afterCast.player.mana)
    assertTrue("Expected opponent HP to drop below $enemyStartHp", afterCast.opponent.hp < enemyStartHp)
    assertEquals(CombatPhase.ENEMY_TURN, afterCast.phase)

    vm.exitSoloCombat()
  }

  @Test
  fun lanMultiplayer_hostAndClientKeepIndependentWandsManaAndTurnSync() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val spells = SpellCatalogRepository(context).getAllSpells()
    val combos = SpellCatalogRepository(context).getAllCombos()
    val spellsMap = spells.associateBy { it.id }

    val hostDiscovery = LanDiscoveryManager(context)
    val clientDiscovery = LanDiscoveryManager(context)
    val hostManager = LanMultiplayerManager(hostDiscovery, { spellsMap }, { combos })
    val clientManager = LanMultiplayerManager(clientDiscovery, { spellsMap }, { combos })

    try {
      hostManager.startHost(
        hostWizardName = "HostWizard",
        wandId = "wand_vine_kelpie",
        preferredPort = 0
      )
      waitUntil(timeoutMs = 3000) { hostManager.uiState.value.role is LanRole.Host }
      val hostRole = hostManager.uiState.value.role as LanRole.Host

      clientManager.connectToHost(
        ipInput = "127.0.0.1",
        portInput = hostRole.port.toString(),
        wizardName = "ClientWizard",
        wandId = "wand_yew_dragon"
      )
      waitUntil(timeoutMs = 3000) {
        clientManager.uiState.value.matchState?.status == LanMatchStatus.LOBBY_READY_CHECK
      }

      val lobbyMatch = clientManager.uiState.value.matchState!!
      assertEquals("wand_vine_kelpie", lobbyMatch.hostState.wandId)
      assertEquals("wand_yew_dragon", lobbyMatch.clientState.wandId)
      assertTrue(lobbyMatch.hostState.maxMana > lobbyMatch.clientState.maxMana)

      hostManager.toggleHostReady()
      clientManager.sendClientReady()
      waitUntil(timeoutMs = 3000) {
        clientManager.uiState.value.matchState?.status == LanMatchStatus.IN_PROGRESS
      }

      val startMatch = clientManager.uiState.value.matchState!!
      val hostStartMana = startMatch.hostState.mana
      val clientStartHp = startMatch.clientState.hp

      hostManager.castSpell("lumos_spark", voiceAccuracy = 95)
      waitUntil(timeoutMs = 3000) {
        clientManager.uiState.value.matchState?.activeTurnPlayerId == "client"
      }

      val synced = clientManager.uiState.value.matchState!!
      assertTrue(synced.hostState.mana < hostStartMana)
      assertTrue(synced.clientState.hp < clientStartHp)
      assertEquals("client", synced.activeTurnPlayerId)
    } finally {
      clientManager.stopAll(reason = null)
      hostManager.stopAll(reason = null)
      clientDiscovery.release()
      hostDiscovery.release()
    }
  }

  private fun waitUntil(timeoutMs: Long, condition: () -> Boolean) {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
      if (condition()) return
      Thread.sleep(25)
    }
    assertTrue("Timed out after ${timeoutMs}ms waiting for condition", condition())
  }
}
