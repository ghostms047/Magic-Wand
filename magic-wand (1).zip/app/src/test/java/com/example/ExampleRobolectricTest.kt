package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.GameSaveRepository
import com.example.data.SpellCatalogRepository
import com.example.engine.PronunciationMatcher
import com.example.model.LanMatchStatus
import com.example.model.MatchState
import com.example.model.NetworkMessage
import com.example.model.NetworkMessageType
import com.example.model.PlayerState
import com.example.model.SpellCategory
import com.example.network.NetworkMessageCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun appName_andCatalogAssets_loadProperly() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Magic Wand", appName)

    val repo = SpellCatalogRepository(context)
    val spells = repo.getAllSpells()
    val combos = repo.getAllCombos()
    assertTrue("Expected at least 55 spells, found ${spells.size}", spells.size >= 55)
    assertTrue(combos.size >= 10)
    assertEquals(SpellCategory.entries.toSet(), spells.map { it.category }.toSet())
    assertTrue(spells.all { it.patternNodes.size >= 3 && it.patternNodes.distinct().size == it.patternNodes.size })
    assertTrue(spells.all { it.phoneticGuide.isNotBlank() && it.voiceVariants.isNotEmpty() })
    assertTrue(spells.all { PronunciationMatcher.evaluate(it, listOf(it.name)).isMatch })
  }

  @Test
  fun saveRepository_persistsAndRestoresProgress() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val spells = SpellCatalogRepository(context).getAllSpells()
    val saveRepo = GameSaveRepository(context)

    val fresh = saveRepo.resetAll(spells)
    assertTrue(fresh.spellProgressMap["lumos_spark"]?.unlocked == true)
    assertFalse(fresh.spellProgressMap["protego"]?.unlocked == true)

    val modified = fresh.copy(
      highestStageCleared = 2,
      voiceCastsSucceeded = 7,
      recentSpellId = "protego",
      settings = fresh.settings.copy(wizardName = "Alaric", voiceCastingInCombat = true)
    )
    saveRepo.save(modified)

    val restored = saveRepo.load(spells)
    assertEquals(2, restored.highestStageCleared)
    assertEquals(7, restored.voiceCastsSucceeded)
    assertEquals("protego", restored.recentSpellId)
    assertEquals("Alaric", restored.settings.wizardName)
    assertTrue(restored.settings.voiceCastingInCombat)
  }

  @Test
  fun networkMessageCodec_roundTripsValidPackets_andRejectsMalformed() {
    val match = MatchState(
      matchId = "MW-4242",
      hostName = "Host",
      clientName = "Guest",
      status = LanMatchStatus.IN_PROGRESS,
      hostState = PlayerState(id = "host", name = "Host", maxHp = 120, hp = 100),
      clientState = PlayerState(id = "client", name = "Guest", maxHp = 120, hp = 95)
    )
    val msg = NetworkMessage(
      type = NetworkMessageType.STATE_SYNC,
      senderId = "host",
      sequence = 7L,
      text = "Round 1",
      matchState = match
    )
    val encoded = NetworkMessageCodec.encode(msg)
    val decoded = NetworkMessageCodec.decode(encoded)
    assertNotNull(decoded)
    assertEquals(NetworkMessageType.STATE_SYNC, decoded?.type)
    assertEquals("MW-4242", decoded?.matchState?.matchId)
    assertEquals(95, decoded?.matchState?.clientState?.hp)

    assertNull(NetworkMessageCodec.decode("{invalid json"))
    assertNull(NetworkMessageCodec.decode(""))
  }
}
