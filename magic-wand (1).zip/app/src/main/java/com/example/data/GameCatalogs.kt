package com.example.data

import com.example.model.Achievement
import com.example.model.Arena
import com.example.model.Enemy
import com.example.model.EnemyBehavior
import com.example.model.MasteryLevel
import com.example.model.PlayerSaveData
import com.example.model.Wand
import com.example.model.WandPassiveType

object EnemyCatalog {
  val enemies: List<Enemy> = listOf(
    Enemy(
      id = "de_recruit",
      name = "Shadow Recruit",
      title = "Stage 1 — Initiate",
      stageNumber = 1,
      maxHp = 85,
      attack = 2,
      defense = 2,
      reactionDelayMs = 700L,
      availableSpellIds = listOf("lumos_spark", "flipendo", "incendio", "protego"),
      difficulty = 1,
      behavior = EnemyBehavior.FAST_ATTACKER,
      description = "A hasty masked novice who favors rapid spark and flame strikes."
    ),
    Enemy(
      id = "de_acolyte",
      name = "Vespera the Acolyte",
      title = "Stage 2 — Death Eater",
      stageNumber = 2,
      maxHp = 115,
      attack = 4,
      defense = 4,
      reactionDelayMs = 680L,
      availableSpellIds = listOf("incendio", "confringo", "stupefy", "episkey"),
      difficulty = 2,
      behavior = EnemyBehavior.AGGRESSIVE,
      description = "Relentless duelist wielding scorching fire and stunning hexes."
    ),
    Enemy(
      id = "de_wardbreaker",
      name = "Caelum Wardbreaker",
      title = "Stage 3 — Cultist Sentinel",
      stageNumber = 3,
      maxHp = 145,
      attack = 5,
      defense = 8,
      reactionDelayMs = 780L,
      availableSpellIds = listOf("protego", "aegis_maxima", "glacius", "vulnera_sanentur", "stupefy"),
      difficulty = 3,
      behavior = EnemyBehavior.DEFENSIVE,
      description = "Maintains thick arcane barriers while chilling opponents over long duels."
    ),
    Enemy(
      id = "de_inquisitor",
      name = "Mirrorshade Inquisitor",
      title = "Stage 4 — Elite Death Eater",
      stageNumber = 4,
      maxHp = 175,
      attack = 7,
      defense = 8,
      reactionDelayMs = 650L,
      availableSpellIds = listOf("expelliarmus", "silencio", "petrificus", "crucio_umbra", "salvio_hexia"),
      difficulty = 4,
      behavior = EnemyBehavior.COUNTER_FOCUSED,
      description = "Disrupts shielded wizards with silencing hexes and dark counter-curses."
    ),
    Enemy(
      id = "de_lord_malakor",
      name = "Lord Malakor",
      title = "Stage 5 — High Death Eater",
      stageNumber = 5,
      maxHp = 220,
      attack = 9,
      defense = 10,
      reactionDelayMs = 800L,
      availableSpellIds = listOf("protego_maxima", "crucio_umbra", "fiendfyre_coil", "oblivion_fracture", "chrono_echo", "arcane_nova"),
      difficulty = 5,
      behavior = EnemyBehavior.HEAVY_ATTACKER,
      description = "Supreme dark sorcerer who fortifies with temporal wards before unleashing forbidden power."
    )
  )

  fun getById(id: String): Enemy? = enemies.firstOrNull { it.id == id }
}

object ArenaCatalog {
  val arenas: List<Arena> = listOf(
    Arena(
      id = "arena_courtyard",
      name = "Whispering Courtyard",
      subtitle = "Balanced dueling grounds beneath ancient stone arches.",
      attackModifier = 0,
      shieldModifier = 0
    ),
    Arena(
      id = "arena_obsidian",
      name = "Obsidian Hall",
      subtitle = "Volcanic ley lines amplify all offensive spells (+3 Attack).",
      attackModifier = 3,
      shieldModifier = 0
    ),
    Arena(
      id = "arena_observatory",
      name = "Astral Observatory",
      subtitle = "Starlight wards reinforce protective barriers (+4 Shield).",
      attackModifier = 0,
      shieldModifier = 4
    ),
    Arena(
      id = "arena_crypt",
      name = "Forbidden Crypt",
      subtitle = "Volatile dark energy heightens strikes and wards (+4 Attack, +3 Shield).",
      attackModifier = 4,
      shieldModifier = 3
    )
  )
}

object WandCatalog {
  val wands: List<Wand> = listOf(
    Wand(
      id = "wand_oak_phoenix",
      name = "Oak & Phoenix Feather",
      wood = "English Oak",
      core = "Phoenix Feather",
      description = "Balanced academy wand prized by loyal duelists for crisp offensive focus.",
      passiveType = WandPassiveType.ATTACK_BONUS,
      passiveValue = 3,
      unlockRequirementLabel = "Unlocked at Start",
      requiredLearnedSpells = 0,
      requiredStagesCleared = 0
    ),
    Wand(
      id = "wand_willow_unicorn",
      name = "Willow & Unicorn Hair",
      wood = "Weeping Willow",
      core = "Unicorn Tail Hair",
      description = "Supple restorative wand attuned to protective charms and healing.",
      passiveType = WandPassiveType.HEAL_BONUS,
      passiveValue = 4,
      unlockRequirementLabel = "Unlocked at Start",
      requiredLearnedSpells = 0,
      requiredStagesCleared = 0
    ),
    Wand(
      id = "wand_cypress_griffin",
      name = "Cypress & Griffin Talon",
      wood = "Ancient Cypress",
      core = "Griffin Talon",
      description = "Steadies the caster's wrist during rune tracing for higher practice grace.",
      passiveType = WandPassiveType.PRACTICE_GRACE,
      passiveValue = 6,
      unlockRequirementLabel = "Learn 3 Spells",
      requiredLearnedSpells = 3,
      requiredStagesCleared = 0
    ),
    Wand(
      id = "wand_yew_dragon",
      name = "Yew & Dragon Heartstring",
      wood = "Carved Yew",
      core = "Dragon Heartstring",
      description = "Resilient duelist wand fortifying magical barriers against dark arts.",
      passiveType = WandPassiveType.SHIELD_BONUS,
      passiveValue = 5,
      unlockRequirementLabel = "Clear Death Eater Stage 2",
      requiredLearnedSpells = 0,
      requiredStagesCleared = 2
    ),
    Wand(
      id = "wand_elder_astral",
      name = "Elder & Astral Crystal",
      wood = "Silver Elder",
      core = "Astral Crystal",
      description = "Storied sanctum relic granting enduring vitality in prolonged duels.",
      passiveType = WandPassiveType.MAX_HP_BONUS,
      passiveValue = 15,
      unlockRequirementLabel = "Learn 7 Spells & Clear Stage 4",
      requiredLearnedSpells = 7,
      requiredStagesCleared = 4
    )
  )

  fun isUnlocked(wand: Wand, learnedCount: Int, stagesCleared: Int): Boolean {
    return learnedCount >= wand.requiredLearnedSpells && stagesCleared >= wand.requiredStagesCleared
  }

  fun getById(id: String): Wand = wands.firstOrNull { it.id == id } ?: wands.first()
}

object AchievementCatalog {
  fun buildAchievements(save: PlayerSaveData): List<Achievement> {
    val learnedCount = save.spellProgressMap.values.count { it.unlocked }
    val masteredCount = save.spellProgressMap.values.count { it.masteryLevel == MasteryLevel.MASTERED }

    fun item(id: String, title: String, desc: String, target: Int, current: Int): Achievement {
      val clamped = current.coerceAtMost(target)
      val unlocked = id in save.unlockedAchievementIds || current >= target
      return Achievement(
        id = id,
        title = title,
        description = desc,
        targetCount = target,
        currentCount = if (unlocked) target else clamped,
        unlocked = unlocked
      )
    }

    return listOf(
      item("learn_first_spell", "First Incantation", "Learn your first new spell through practice & voice.", 2, learnedCount),
      item("learn_five_spells", "Apprentice Archivist", "Unlock at least 5 spells in your Spell Library.", 5, learnedCount),
      item("master_spell", "True Mastery", "Reach Mastered rank on any spell.", 1, masteredCount),
      item("voice_caster", "Voice of Arcane", "Cast 5 spells cleanly using voice incantations.", 5, save.voiceCastsSucceeded),
      item("complete_first_battle", "Baptism of Sparks", "Complete your first duel in any combat mode.", 1, save.battlesCompleted),
      item("defeat_death_eater", "Order Defender", "Defeat a Death Eater stage enemy.", 1, save.deathEatersDefeated),
      item("clear_all_stages", "Champion of the Sanctum", "Clear all 5 Death Eater stages.", 5, save.highestStageCleared),
      item("win_free_battle", "Arena Sovereign", "Win a Free Battle match.", 1, save.freeBattlesWon),
      item("perform_combo", "Arcane Synergy", "Trigger a predefined Spell Combo in combat.", 1, save.combosPerformed),
      item("perfect_practice", "Flawless Form", "Complete a practice cast with 95%+ accuracy.", 1, save.perfectPractices)
    )
  }
}
