package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.SpellProgress
import com.example.ui.AppDestination
import com.example.ui.MainViewModel
import com.example.ui.screens.AchievementsScreen
import com.example.ui.screens.DeathEaterBattleScreen
import com.example.ui.screens.FreeBattleScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LocalMultiplayerScreen
import com.example.ui.screens.PracticeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SpellDetailScreen
import com.example.ui.screens.SpellLibraryScreen
import com.example.ui.screens.WandScreen
import com.example.ui.theme.MagicWandTheme

class MainActivity : ComponentActivity() {

  private var mainViewModelRef: MainViewModel? = null

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val vm: MainViewModel = viewModel()
      mainViewModelRef = vm
      MagicWandApp(vm)
    }
  }

  override fun onStop() {
    super.onStop()
    mainViewModelRef?.onAppBackgrounded()
  }
}

private data class NavTabItem(
  val destination: AppDestination,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector
)

private val primaryTabs = listOf(
  NavTabItem(AppDestination.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home),
  NavTabItem(AppDestination.SPELL_LIBRARY, "Library", Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
  NavTabItem(AppDestination.PRACTICE, "Practice", Icons.Filled.TouchApp, Icons.Outlined.TouchApp),
  NavTabItem(AppDestination.DEATH_EATER_BATTLE, "Battle", Icons.Filled.Shield, Icons.Outlined.Shield),
  NavTabItem(AppDestination.LOCAL_MULTIPLAYER, "LAN", Icons.Filled.Wifi, Icons.Outlined.Wifi)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MagicWandApp(vm: MainViewModel) {
  val backStack by vm.backStack.collectAsStateWithLifecycle()
  val saveData by vm.saveData.collectAsStateWithLifecycle()
  val libraryFilter by vm.libraryFilter.collectAsStateWithLifecycle()
  val detailSpellId by vm.detailSpellId.collectAsStateWithLifecycle()
  val practiceState by vm.practiceState.collectAsStateWithLifecycle()
  val combatState by vm.combatState.collectAsStateWithLifecycle()
  val preparedSpell by vm.preparedCombatSpell.collectAsStateWithLifecycle()
  val combatVoiceFeedback by vm.combatVoiceFeedback.collectAsStateWithLifecycle()
  val voiceState by vm.voiceState.collectAsStateWithLifecycle()
  val lanState by vm.lanUiState.collectAsStateWithLifecycle()
  val discoveredHosts by vm.discoveredHosts.collectAsStateWithLifecycle()

  val currentDest = backStack.lastOrNull() ?: AppDestination.HOME

  BackHandler(enabled = backStack.size > 1) {
    vm.navigateBack()
  }

  MagicWandTheme(themePreference = saveData.settings.themePreference) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
      val useNavigationRail = maxWidth >= 600.dp

      Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
          TopAppBar(
            title = {
              Text(
                text = currentDest.title,
                style = MaterialTheme.typography.headlineSmall
              )
            },
            navigationIcon = {
              if (currentDest != AppDestination.HOME) {
                IconButton(
                  onClick = { vm.navigateBack() },
                  modifier = Modifier.testTag("top_back_btn")
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Navigate back"
                  )
                }
              } else {
                IconButton(onClick = { vm.navigateTo(AppDestination.WAND) }) {
                  Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = "Wand Chamber",
                    tint = MaterialTheme.colorScheme.primary
                  )
                }
              }
            },
            colors = TopAppBarDefaults.topAppBarColors(
              containerColor = MaterialTheme.colorScheme.background,
              titleContentColor = MaterialTheme.colorScheme.onBackground
            )
          )
        },
        bottomBar = {
          if (!useNavigationRail) {
            NavigationBar {
              primaryTabs.forEach { tab ->
                val selected = currentDest == tab.destination
                NavigationBarItem(
                  selected = selected,
                  onClick = { vm.navigateTo(tab.destination) },
                  icon = {
                    Icon(
                      imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      contentDescription = tab.label
                    )
                  },
                  label = { Text(tab.label, maxLines = 1) },
                  modifier = Modifier.testTag("nav_${tab.destination.name.lowercase()}")
                )
              }
            }
          }
        }
      ) { innerPadding ->
        Row(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          if (useNavigationRail) {
            NavigationRail {
              primaryTabs.forEach { tab ->
                val selected = currentDest == tab.destination
                NavigationRailItem(
                  selected = selected,
                  onClick = { vm.navigateTo(tab.destination) },
                  icon = {
                    Icon(
                      imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                      contentDescription = tab.label
                    )
                  },
                  label = { Text(tab.label) }
                )
              }
            }
          }

          when (currentDest) {
            AppDestination.HOME -> HomeScreen(
              saveData = saveData,
              allSpells = vm.allSpells,
              onNavigate = { vm.navigateTo(it) },
              onOpenSpellDetail = { vm.openSpellDetail(it) }
            )

            AppDestination.SPELL_LIBRARY -> SpellLibraryScreen(
              spells = vm.allSpells,
              progressMap = saveData.spellProgressMap,
              selectedCategory = libraryFilter,
              onSelectCategory = { vm.setLibraryFilter(it) },
              onOpenSpellDetail = { vm.openSpellDetail(it) },
              onPracticeSpell = { vm.openPracticeForSpell(it) }
            )

            AppDestination.SPELL_DETAIL -> {
              val spell = vm.allSpells.firstOrNull { it.id == detailSpellId } ?: vm.allSpells.first()
              val progress = saveData.spellProgressMap[spell.id] ?: SpellProgress(spellId = spell.id)
              SpellDetailScreen(
                spell = spell,
                progress = progress,
                onStartPractice = { vm.openPracticeForSpell(spell.id) }
              )
            }

            AppDestination.PRACTICE -> PracticeScreen(
              spells = vm.allSpells,
              progressMap = saveData.spellProgressMap,
              practiceState = practiceState,
              voiceState = voiceState,
              showHints = saveData.settings.showPatternHints,
              hapticsEnabled = saveData.settings.hapticsEnabled,
              onSelectSpell = { vm.selectPracticeSpell(it) },
              onToggleInputMode = { vm.togglePracticeInputMode() },
              onTraceComplete = { nodes, pts -> vm.submitPracticeTrace(nodes, pts) },
              onTapSequenceComplete = { nodes -> vm.submitPracticeTapSequence(nodes) },
              onStartVoiceListening = { vm.startPracticeVoiceListening() },
              onStopVoiceListening = { vm.stopVoiceListening() },
              onFallbackPronunciation = { vm.submitFallbackPracticePronunciation(it) },
              onContinue = { vm.continuePracticeAfterAttempt() }
            )

            AppDestination.DEATH_EATER_BATTLE -> DeathEaterBattleScreen(
              highestStageCleared = saveData.highestStageCleared,
              combatState = combatState,
              combos = vm.allCombos,
              voiceCastingEnabled = saveData.settings.voiceCastingInCombat,
              preparedSpell = preparedSpell,
              voiceState = voiceState,
              voiceFeedback = combatVoiceFeedback,
              onStartStage = { vm.startDeathEaterStage(it) },
              onPrepareSpell = { vm.prepareCombatSpell(it) },
              onCancelPreparedSpell = { vm.cancelPreparedCombatSpell() },
              onStartVoiceCast = { vm.startCombatVoiceCast(isLanMatch = false) },
              onStopVoiceCast = { vm.stopVoiceListening() },
              onFallbackPronunciation = { vm.submitFallbackCombatPronunciation(it, isLanMatch = false) },
              onDirectCastSpell = { vm.castSoloSpell(it) },
              onExitCombat = { vm.exitSoloCombat() }
            )

            AppDestination.FREE_BATTLE -> FreeBattleScreen(
              allCombatSpells = vm.allSpells.filter { it.combatAvailable },
              unlockedCombatSpells = vm.getUnlockedCombatSpells(),
              combatState = combatState,
              combos = vm.allCombos,
              voiceCastingEnabled = saveData.settings.voiceCastingInCombat,
              preparedSpell = preparedSpell,
              voiceState = voiceState,
              voiceFeedback = combatVoiceFeedback,
              onStartFreeBattle = { enemy, arena, pHp, eHp, timer, diff, sandbox, loadout ->
                vm.startFreeBattle(enemy, arena, pHp, eHp, timer, diff, sandbox, loadout)
              },
              onPrepareSpell = { vm.prepareCombatSpell(it) },
              onCancelPreparedSpell = { vm.cancelPreparedCombatSpell() },
              onStartVoiceCast = { vm.startCombatVoiceCast(isLanMatch = false) },
              onStopVoiceCast = { vm.stopVoiceListening() },
              onFallbackPronunciation = { vm.submitFallbackCombatPronunciation(it, isLanMatch = false) },
              onDirectCastSpell = { vm.castSoloSpell(it) },
              onExitCombat = { vm.exitSoloCombat() }
            )

            AppDestination.LOCAL_MULTIPLAYER -> LocalMultiplayerScreen(
              lanState = lanState,
              discoveredHosts = discoveredHosts,
              unlockedCombatSpells = vm.getUnlockedCombatSpells(),
              combos = vm.allCombos,
              voiceCastingEnabled = saveData.settings.voiceCastingInCombat,
              preparedSpell = preparedSpell,
              voiceState = voiceState,
              voiceFeedback = combatVoiceFeedback,
              onStartHost = { vm.startLanHost(it) },
              onToggleHostReady = { vm.toggleLanHostReady() },
              onStartDiscovery = { vm.startLanDiscovery() },
              onStopDiscovery = { vm.stopLanDiscovery() },
              onConnectToHost = { ip, port -> vm.connectToLanHost(ip, port) },
              onSendClientReady = { vm.sendLanClientReady() },
              onPrepareSpell = { vm.prepareCombatSpell(it) },
              onCancelPreparedSpell = { vm.cancelPreparedCombatSpell() },
              onStartVoiceCast = { vm.startCombatVoiceCast(isLanMatch = true) },
              onStopVoiceCast = { vm.stopVoiceListening() },
              onFallbackPronunciation = { vm.submitFallbackCombatPronunciation(it, isLanMatch = true) },
              onDirectCastSpell = { vm.castLanSpell(it) },
              onDisconnect = { vm.disconnectLan() }
            )

            AppDestination.WAND -> WandScreen(
              saveData = saveData,
              onSelectWand = { vm.selectWand(it) }
            )

            AppDestination.ACHIEVEMENTS -> AchievementsScreen(
              achievements = vm.getAchievements()
            )

            AppDestination.SETTINGS -> SettingsScreen(
              settings = saveData.settings,
              onUpdateSettings = { vm.updateSettings(it) },
              onResetProgress = { vm.resetAllProgress() }
            )
          }
        }
      }
    }
  }
}
