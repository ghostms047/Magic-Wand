package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AchievementCatalog
import com.example.data.ArenaCatalog
import com.example.data.EnemyCatalog
import com.example.data.GameSaveRepository
import com.example.data.SpellCatalogRepository
import com.example.data.WandCatalog
import com.example.engine.CombatEngine
import com.example.engine.EnemyDecisionEngine
import com.example.engine.MasteryCalculator
import com.example.engine.PatternValidator
import com.example.engine.Point2D
import com.example.engine.PronunciationMatchResult
import com.example.engine.PronunciationMatcher
import com.example.engine.ValidationResult
import com.example.model.Achievement
import com.example.model.AppSettings
import com.example.model.Arena
import com.example.model.CombatLogEntry
import com.example.model.CombatMode
import com.example.model.CombatPhase
import com.example.model.CombatState
import com.example.model.DiscoveredHost
import com.example.model.Enemy
import com.example.model.PlayerSaveData
import com.example.model.PlayerState
import com.example.model.Spell
import com.example.model.SpellCategory
import com.example.model.SpellProgress
import com.example.model.ThemePreference
import com.example.model.Wand
import com.example.model.WandPassiveType
import com.example.network.LanDiscoveryManager
import com.example.network.LanMultiplayerManager
import com.example.network.LanUiState
import com.example.voice.VoiceSessionState
import com.example.voice.VoiceSpellRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class AppDestination(val title: String) {
  HOME("Magic Wand"),
  SPELL_LIBRARY("Spell Library"),
  SPELL_DETAIL("Spell Details"),
  PRACTICE("Practice Mode"),
  DEATH_EATER_BATTLE("Death Eater Battle"),
  FREE_BATTLE("Free Battle"),
  LOCAL_MULTIPLAYER("Local Multiplayer"),
  WAND("Wand Chamber"),
  ACHIEVEMENTS("Achievements"),
  SETTINGS("Settings")
}

enum class PracticeStep {
  PERFORM_PATTERN,
  SPEAK_INCANTATION,
  ATTEMPT_FAILED,
  ATTEMPT_SUCCEEDED
}

data class PracticeUiState(
  val selectedSpellId: String = "protego",
  val tapAccessibilityMode: Boolean = false,
  val step: PracticeStep = PracticeStep.PERFORM_PATTERN,
  val patternResult: ValidationResult? = null,
  val pronunciationResult: PronunciationMatchResult? = null,
  val combinedAccuracy: Int? = null,
  val newlyUnlockedSpellName: String? = null,
  val lastMasteryMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val spellRepo = SpellCatalogRepository(application)
  private val saveRepo = GameSaveRepository(application)
  private val discoveryManager = LanDiscoveryManager(application)
  private val voiceRecognizer = VoiceSpellRecognizer(application)

  val allSpells: List<Spell> = spellRepo.getAllSpells()
  val allCombos = spellRepo.getAllCombos()
  private val spellsById: Map<String, Spell> = allSpells.associateBy { it.id }

  private val lanManager = LanMultiplayerManager(
    discoveryManager = discoveryManager,
    spellsById = { spellsById },
    combos = { allCombos }
  )

  private val _backStack = MutableStateFlow(listOf(AppDestination.HOME))
  val backStack: StateFlow<List<AppDestination>> = _backStack.asStateFlow()

  private val _saveData = MutableStateFlow(saveRepo.load(allSpells))
  val saveData: StateFlow<PlayerSaveData> = _saveData.asStateFlow()

  private val _libraryFilter = MutableStateFlow<SpellCategory?>(null)
  val libraryFilter: StateFlow<SpellCategory?> = _libraryFilter.asStateFlow()

  private val _detailSpellId = MutableStateFlow(allSpells.firstOrNull { it.id == "protego" }?.id ?: allSpells.firstOrNull()?.id.orEmpty())
  val detailSpellId: StateFlow<String> = _detailSpellId.asStateFlow()

  private val _practiceState = MutableStateFlow(
    PracticeUiState(
      selectedSpellId = allSpells.firstOrNull { it.id == "protego" }?.id
        ?: allSpells.firstOrNull()?.id.orEmpty()
    )
  )
  val practiceState: StateFlow<PracticeUiState> = _practiceState.asStateFlow()

  private val _combatState = MutableStateFlow<CombatState?>(null)
  val combatState: StateFlow<CombatState?> = _combatState.asStateFlow()

  private val _preparedCombatSpell = MutableStateFlow<Spell?>(null)
  val preparedCombatSpell: StateFlow<Spell?> = _preparedCombatSpell.asStateFlow()

  private val _combatVoiceFeedback = MutableStateFlow<String?>(null)
  val combatVoiceFeedback: StateFlow<String?> = _combatVoiceFeedback.asStateFlow()

  val voiceState: StateFlow<VoiceSessionState> = voiceRecognizer.state
  val lanUiState: StateFlow<LanUiState> = lanManager.uiState
  val discoveredHosts: StateFlow<List<DiscoveredHost>> = discoveryManager.discoveredHosts

  private var enemyTurnJob: Job? = null
  private var roundTimerJob: Job? = null

  // ==================== NAVIGATION ====================

  fun navigateTo(destination: AppDestination) {
    voiceRecognizer.stopListening()
    _preparedCombatSpell.value = null
    _combatVoiceFeedback.value = null
    val current = _backStack.value
    if (current.lastOrNull() == destination) return
    val baseTabs = setOf(
      AppDestination.HOME,
      AppDestination.SPELL_LIBRARY,
      AppDestination.PRACTICE,
      AppDestination.DEATH_EATER_BATTLE,
      AppDestination.LOCAL_MULTIPLAYER
    )
    _backStack.value = if (destination == AppDestination.HOME) {
      listOf(AppDestination.HOME)
    } else if (destination in baseTabs && current.lastOrNull() in baseTabs) {
      listOf(AppDestination.HOME, destination)
    } else {
      (current.filterNot { it == destination } + destination)
    }
  }

  fun openSpellDetail(spellId: String) {
    _detailSpellId.value = spellId
    navigateTo(AppDestination.SPELL_DETAIL)
  }

  fun navigateBack(): Boolean {
    voiceRecognizer.stopListening()
    _preparedCombatSpell.value = null
    val current = _backStack.value
    if (current.size <= 1) return false
    if (current.last() == AppDestination.DEATH_EATER_BATTLE || current.last() == AppDestination.FREE_BATTLE) {
      val combat = _combatState.value
      if (combat != null && combat.phase != CombatPhase.VICTORY && combat.phase != CombatPhase.DEFEAT) {
        exitSoloCombat()
      }
    }
    _backStack.value = current.dropLast(1)
    return true
  }

  // ==================== SPELL LIBRARY & PRACTICE ====================

  fun setLibraryFilter(category: SpellCategory?) {
    _libraryFilter.value = category
  }

  fun openPracticeForSpell(spellId: String) {
    selectPracticeSpell(spellId)
    navigateTo(AppDestination.PRACTICE)
  }

  fun selectPracticeSpell(spellId: String) {
    voiceRecognizer.resetToIdle("Complete the rune pattern first, then pronounce the spell.")
    _practiceState.value = PracticeUiState(
      selectedSpellId = spellId,
      tapAccessibilityMode = _practiceState.value.tapAccessibilityMode,
      step = PracticeStep.PERFORM_PATTERN
    )
  }

  fun togglePracticeInputMode() {
    val cur = _practiceState.value
    if (cur.step != PracticeStep.PERFORM_PATTERN) return
    _practiceState.value = cur.copy(tapAccessibilityMode = !cur.tapAccessibilityMode)
  }

  fun submitPracticeTrace(hitNodes: List<Int>, strokePoints: List<Point2D>) {
    val state = _practiceState.value
    if (state.step != PracticeStep.PERFORM_PATTERN) return
    val spell = spellsById[state.selectedSpellId] ?: return
    val grace = activeWandPracticeGrace()
    val result = PatternValidator.validateTrace(
      expectedNodes = spell.patternNodes,
      hitNodes = hitNodes,
      strokePoints = strokePoints,
      practiceGraceBonus = grace
    )
    handlePatternValidated(spell, result)
  }

  fun submitPracticeTapSequence(tappedNodes: List<Int>) {
    val state = _practiceState.value
    if (state.step != PracticeStep.PERFORM_PATTERN) return
    val spell = spellsById[state.selectedSpellId] ?: return
    val grace = activeWandPracticeGrace()
    val result = PatternValidator.validateTapSequence(
      expectedNodes = spell.patternNodes,
      tappedNodes = tappedNodes,
      practiceGraceBonus = grace
    )
    handlePatternValidated(spell, result)
  }

  private fun handlePatternValidated(spell: Spell, result: ValidationResult) {
    if (!result.isSuccess) {
      // Pattern failed -> record failure (progress does NOT increase)
      recordPracticeOutcome(spell = spell, isSuccess = false, accuracyPercent = result.accuracyPercent)
      _practiceState.value = _practiceState.value.copy(
        step = PracticeStep.ATTEMPT_FAILED,
        patternResult = result,
        pronunciationResult = null,
        combinedAccuracy = result.accuracyPercent
      )
      return
    }

    // Pattern succeeded -> advance to Voice Pronunciation step!
    voiceRecognizer.resetToIdle("Pattern verified! Tap Mic and pronounce \"${spell.name}\".")
    _practiceState.value = _practiceState.value.copy(
      step = PracticeStep.SPEAK_INCANTATION,
      patternResult = result,
      pronunciationResult = null
    )
  }

  fun startPracticeVoiceListening() {
    val state = _practiceState.value
    if (state.step != PracticeStep.SPEAK_INCANTATION) return
    val spell = spellsById[state.selectedSpellId] ?: return

    voiceRecognizer.startListening(promptLabel = spell.name) { hypotheses ->
      evaluatePracticeVoiceHypotheses(spell, hypotheses)
    }
  }

  fun stopVoiceListening() {
    voiceRecognizer.stopListening()
  }

  fun submitFallbackPracticePronunciation(typedText: String) {
    val state = _practiceState.value
    if (state.step != PracticeStep.SPEAK_INCANTATION) return
    val spell = spellsById[state.selectedSpellId] ?: return
    evaluatePracticeVoiceHypotheses(spell, listOf(typedText))
  }

  private fun evaluatePracticeVoiceHypotheses(spell: Spell, hypotheses: List<String>) {
    val state = _practiceState.value
    if (state.step != PracticeStep.SPEAK_INCANTATION) return
    val patternAcc = state.patternResult?.accuracyPercent ?: 80

    val voiceResult = PronunciationMatcher.evaluate(spell, hypotheses)
    if (voiceResult.isMatch) {
      voiceRecognizer.markAccepted(voiceResult.recognizedText, voiceResult.feedback)
      val combined = ((patternAcc + voiceResult.confidencePercent) / 2).coerceIn(60, 100)
      val (unlockedNow, masteryMsg) = recordPracticeOutcome(
        spell = spell,
        isSuccess = true,
        accuracyPercent = combined,
        voiceSucceeded = true
      )
      _practiceState.value = state.copy(
        step = PracticeStep.ATTEMPT_SUCCEEDED,
        pronunciationResult = voiceResult,
        combinedAccuracy = combined,
        newlyUnlockedSpellName = if (unlockedNow) spell.name else null,
        lastMasteryMessage = masteryMsg
      )
    } else {
      voiceRecognizer.markRejected(voiceResult.recognizedText, voiceResult.feedback)
      recordPracticeOutcome(
        spell = spell,
        isSuccess = false,
        accuracyPercent = voiceResult.confidencePercent,
        voiceSucceeded = false
      )
      _practiceState.value = state.copy(
        step = PracticeStep.ATTEMPT_FAILED,
        pronunciationResult = voiceResult,
        combinedAccuracy = voiceResult.confidencePercent
      )
    }
  }

  private fun recordPracticeOutcome(
    spell: Spell,
    isSuccess: Boolean,
    accuracyPercent: Int,
    voiceSucceeded: Boolean = false
  ): Pair<Boolean, String?> {
    val currentSave = _saveData.value
    val prevProgress = currentSave.spellProgressMap[spell.id] ?: SpellProgress(spellId = spell.id)
    val updatedProgress = MasteryCalculator.recordPracticeAttempt(
      spell = spell,
      current = prevProgress,
      isSuccess = isSuccess,
      accuracyPercent = accuracyPercent
    )

    val unlockedNow = !prevProgress.unlocked && updatedProgress.unlocked
    val masteryUp = prevProgress.masteryLevel != updatedProgress.masteryLevel && updatedProgress.unlocked
    val newPerfectCount = if (isSuccess && accuracyPercent >= 95) {
      currentSave.perfectPractices + 1
    } else {
      currentSave.perfectPractices
    }
    val newVoiceCount = if (voiceSucceeded) currentSave.voiceCastsSucceeded + 1 else currentSave.voiceCastsSucceeded

    val updatedMap = currentSave.spellProgressMap.toMutableMap().apply {
      put(spell.id, updatedProgress)
    }
    val nextSave = updateAchievements(
      currentSave.copy(
        spellProgressMap = updatedMap,
        perfectPractices = newPerfectCount,
        voiceCastsSucceeded = newVoiceCount,
        recentSpellId = spell.id
      )
    )
    persistSave(nextSave)
    val masteryMsg = if (masteryUp) "Mastery advanced to ${updatedProgress.masteryLevel.displayName}!" else null
    return unlockedNow to masteryMsg
  }

  fun continuePracticeAfterAttempt() {
    val curId = _practiceState.value.selectedSpellId
    voiceRecognizer.resetToIdle("Trace the rune pattern, then speak the spell.")
    _practiceState.value = PracticeUiState(
      selectedSpellId = curId,
      tapAccessibilityMode = _practiceState.value.tapAccessibilityMode,
      step = PracticeStep.PERFORM_PATTERN
    )
  }

  // ==================== COMBAT VOICE CASTING ====================

  fun prepareCombatSpell(spell: Spell) {
    _preparedCombatSpell.value = spell
    _combatVoiceFeedback.value = "Say \"${spell.name}\" (${spell.phoneticGuide}) to cast!"
    voiceRecognizer.resetToIdle("Listening for ${spell.name}...")
  }

  fun cancelPreparedCombatSpell() {
    voiceRecognizer.stopListening()
    _preparedCombatSpell.value = null
    _combatVoiceFeedback.value = null
  }

  fun startCombatVoiceCast(isLanMatch: Boolean) {
    val spell = _preparedCombatSpell.value ?: return
    voiceRecognizer.startListening(promptLabel = spell.name) { hypotheses ->
      evaluateCombatVoiceHypotheses(spell, hypotheses, isLanMatch)
    }
  }

  fun submitFallbackCombatPronunciation(typedText: String, isLanMatch: Boolean) {
    val spell = _preparedCombatSpell.value ?: return
    evaluateCombatVoiceHypotheses(spell, listOf(typedText), isLanMatch)
  }

  private fun evaluateCombatVoiceHypotheses(
    spell: Spell,
    hypotheses: List<String>,
    isLanMatch: Boolean
  ) {
    val activePrepared = _preparedCombatSpell.value
    if (activePrepared == null || activePrepared.id != spell.id) return

    val result = PronunciationMatcher.evaluate(spell, hypotheses)
    if (result.isMatch) {
      voiceRecognizer.markAccepted(result.recognizedText, "✓ SPELL CAST: ${spell.name}")
      _combatVoiceFeedback.value = "✓ ${spell.name} cast!"
      _preparedCombatSpell.value = null

      val cur = _saveData.value
      persistSave(
        updateAchievements(
          cur.copy(
            voiceCastsSucceeded = cur.voiceCastsSucceeded + 1,
            recentSpellId = spell.id
          )
        )
      )

      if (isLanMatch) {
        castLanSpell(spell.id)
      } else {
        castSoloSpell(spell.id)
      }
    } else {
      voiceRecognizer.markRejected(result.recognizedText, "✕ Spell not recognized")
      _combatVoiceFeedback.value = "✕ ${result.feedback}"
    }
  }

  // ==================== SOLO COMBAT ENGINE ====================

  fun startDeathEaterStage(stageNumber: Int) {
    val enemy = EnemyCatalog.enemies.firstOrNull { it.stageNumber == stageNumber } ?: return
    val unlockedSpells = getUnlockedCombatSpells()
    if (unlockedSpells.isEmpty()) return

    val arena = ArenaCatalog.arenas[(stageNumber - 1).coerceIn(0, ArenaCatalog.arenas.lastIndex)]
    launchSoloBattle(
      mode = CombatMode.DEATH_EATER_STAGE,
      stageNumber = stageNumber,
      enemy = enemy,
      arena = arena,
      playerHp = 110,
      turnSecondsLimit = 0,
      difficultyMultiplier = 1.0f,
      availableSpells = unlockedSpells,
      sandboxUnlockAll = false
    )
  }

  fun startFreeBattle(
    enemy: Enemy,
    arena: Arena,
    playerMaxHp: Int,
    enemyMaxHp: Int,
    turnSecondsLimit: Int,
    difficultyMultiplier: Float,
    sandboxUnlockAll: Boolean,
    selectedSpellIds: Set<String>
  ) {
    val pool = if (sandboxUnlockAll) {
      allSpells.filter { it.combatAvailable }
    } else {
      getUnlockedCombatSpells()
    }
    val chosenSpells = pool.filter { it.id in selectedSpellIds }.ifEmpty { pool }
    if (chosenSpells.isEmpty()) return

    val customizedEnemy = enemy.copy(maxHp = enemyMaxHp)
    launchSoloBattle(
      mode = if (sandboxUnlockAll) CombatMode.SANDBOX_BATTLE else CombatMode.FREE_BATTLE,
      stageNumber = enemy.stageNumber,
      enemy = customizedEnemy,
      arena = arena,
      playerHp = playerMaxHp,
      turnSecondsLimit = turnSecondsLimit,
      difficultyMultiplier = difficultyMultiplier,
      availableSpells = chosenSpells,
      sandboxUnlockAll = sandboxUnlockAll
    )
  }

  private fun launchSoloBattle(
    mode: CombatMode,
    stageNumber: Int,
    enemy: Enemy,
    arena: Arena,
    playerHp: Int,
    turnSecondsLimit: Int,
    difficultyMultiplier: Float,
    availableSpells: List<Spell>,
    sandboxUnlockAll: Boolean
  ) {
    cancelCombatTimers()
    _preparedCombatSpell.value = null
    _combatVoiceFeedback.value = null
    val wand = WandCatalog.getById(_saveData.value.selectedWandId)
    val hpBonus = if (wand.passiveType == WandPassiveType.MAX_HP_BONUS) wand.passiveValue else 0
    val atkBonus = if (wand.passiveType == WandPassiveType.ATTACK_BONUS) wand.passiveValue else 0
    val shdBonus = if (wand.passiveType == WandPassiveType.SHIELD_BONUS) wand.passiveValue else 0
    val healBonus = if (wand.passiveType == WandPassiveType.HEAL_BONUS) wand.passiveValue else 0
    val finalPlayerMaxHp = playerHp + hpBonus

    val playerState = PlayerState(
      id = "player",
      name = _saveData.value.settings.wizardName.ifBlank { "Wizard" },
      maxHp = finalPlayerMaxHp,
      hp = finalPlayerMaxHp,
      attackBonus = atkBonus,
      defense = 2,
      shieldBonus = shdBonus,
      healBonus = healBonus
    )
    val enemyState = PlayerState(
      id = enemy.id,
      name = enemy.name,
      maxHp = enemy.maxHp,
      hp = enemy.maxHp,
      attackBonus = enemy.attack,
      defense = enemy.defense
    )

    _combatState.value = CombatState(
      mode = mode,
      phase = CombatPhase.PLAYER_TURN,
      stageNumber = stageNumber,
      arena = arena,
      roundNumber = 1,
      maxRounds = 20,
      turnSecondsLimit = turnSecondsLimit,
      remainingTurnSeconds = turnSecondsLimit,
      difficultyMultiplier = difficultyMultiplier,
      sandboxUnlockAll = sandboxUnlockAll,
      enemy = enemy,
      player = playerState,
      opponent = enemyState,
      availableSpells = availableSpells,
      logs = listOf(
        CombatLogEntry(1, "Duel began in ${arena.name} vs ${enemy.name} (${enemy.behavior.displayName}).")
      ),
      lastEventSummary = "Your turn! Prepare a spell and pronounce it."
    )
    startTurnCountdownIfEnabled()
  }

  fun castSoloSpell(spellId: String) {
    val state = _combatState.value ?: return
    if (state.phase != CombatPhase.PLAYER_TURN) return
    val spell = state.availableSpells.firstOrNull { it.id == spellId } ?: return
    if ((state.player.cooldowns[spell.id] ?: 0) > 0 && !state.player.isStunned) return

    roundTimerJob?.cancel()
    _preparedCombatSpell.value = null

    val outcome = CombatEngine.resolveSpellCast(
      actor = state.player,
      target = state.opponent,
      spell = spell,
      combos = allCombos,
      arena = state.arena,
      damageMultiplier = 1.0f
    )

    val curSave = _saveData.value
    val nextSave = updateAchievements(
      curSave.copy(
        combosPerformed = if (outcome.comboTriggered != null) curSave.combosPerformed + 1 else curSave.combosPerformed,
        recentSpellId = spell.id
      )
    )
    persistSave(nextSave)

    val newLogs = (state.logs + CombatLogEntry(
      round = state.roundNumber,
      message = outcome.summaryLine,
      isCombo = outcome.comboTriggered != null
    )).takeLast(24)

    val comboBanner = outcome.comboTriggered?.let { "COMBO! ${it.name} — ${it.description}" }

    if (outcome.updatedTarget.hp <= 0) {
      finishSoloBattle(
        state.copy(
          phase = CombatPhase.VICTORY,
          player = outcome.updatedActor,
          opponent = outcome.updatedTarget,
          logs = newLogs + CombatLogEntry(state.roundNumber, "${state.opponent.name} defeated!", isHighlight = true),
          activeComboBanner = comboBanner,
          lastEventSummary = "${outcome.summaryLine} Victory!"
        ),
        playerWon = true
      )
      return
    }
    if (outcome.updatedActor.hp <= 0) {
      finishSoloBattle(
        state.copy(
          phase = CombatPhase.DEFEAT,
          player = outcome.updatedActor,
          opponent = outcome.updatedTarget,
          logs = newLogs + CombatLogEntry(state.roundNumber, "You fell in battle!", isHighlight = true),
          activeComboBanner = comboBanner,
          lastEventSummary = "Defeated by ${state.opponent.name}."
        ),
        playerWon = false
      )
      return
    }

    val enemyTurnState = state.copy(
      phase = CombatPhase.ENEMY_TURN,
      player = outcome.updatedActor,
      opponent = outcome.updatedTarget,
      logs = newLogs,
      activeComboBanner = comboBanner,
      lastEventSummary = "${state.opponent.name} is preparing a counter-spell..."
    )
    _combatState.value = enemyTurnState
    scheduleEnemyTurn(enemyTurnState)
  }

  private fun scheduleEnemyTurn(currentState: CombatState) {
    enemyTurnJob?.cancel()
    val enemy = currentState.enemy ?: return
    enemyTurnJob = viewModelScope.launch {
      delay(enemy.reactionDelayMs.coerceIn(350L, 1000L))
      val active = _combatState.value ?: return@launch
      if (active.phase != CombatPhase.ENEMY_TURN) return@launch

      val chosenSpell = EnemyDecisionEngine.chooseSpell(
        enemy = enemy,
        enemyState = active.opponent,
        playerState = active.player,
        allSpellsById = spellsById,
        roundNumber = active.roundNumber
      ) ?: return@launch

      val outcome = CombatEngine.resolveSpellCast(
        actor = active.opponent,
        target = active.player,
        spell = chosenSpell,
        combos = allCombos,
        arena = active.arena,
        damageMultiplier = active.difficultyMultiplier
      )

      var updatedPlayer = outcome.updatedTarget
      var updatedEnemy = outcome.updatedActor
      val nextLogs = (active.logs + CombatLogEntry(
        round = active.roundNumber,
        message = outcome.summaryLine,
        isCombo = outcome.comboTriggered != null
      )).toMutableList()

      if (updatedPlayer.hp <= 0) {
        finishSoloBattle(
          active.copy(
            phase = CombatPhase.DEFEAT,
            player = updatedPlayer,
            opponent = updatedEnemy,
            logs = (nextLogs + CombatLogEntry(active.roundNumber, "You were defeated!", isHighlight = true)).takeLast(24),
            lastEventSummary = outcome.summaryLine
          ),
          playerWon = false
        )
        return@launch
      }
      if (updatedEnemy.hp <= 0) {
        finishSoloBattle(
          active.copy(
            phase = CombatPhase.VICTORY,
            player = updatedPlayer,
            opponent = updatedEnemy,
            logs = (nextLogs + CombatLogEntry(active.roundNumber, "${enemy.name} defeated!", isHighlight = true)).takeLast(24),
            lastEventSummary = outcome.summaryLine
          ),
          playerWon = true
        )
        return@launch
      }

      val playerTick = CombatEngine.resolveEndOfRound(updatedPlayer)
      val enemyTick = CombatEngine.resolveEndOfRound(updatedEnemy)
      updatedPlayer = playerTick.updatedState
      updatedEnemy = enemyTick.updatedState
      (playerTick.notes + enemyTick.notes).forEach { note ->
        nextLogs.add(CombatLogEntry(active.roundNumber, note))
      }

      if (updatedPlayer.hp <= 0 || updatedEnemy.hp <= 0) {
        val playerWon = updatedEnemy.hp <= 0 && updatedPlayer.hp > 0
        finishSoloBattle(
          active.copy(
            phase = if (playerWon) CombatPhase.VICTORY else CombatPhase.DEFEAT,
            player = updatedPlayer,
            opponent = updatedEnemy,
            logs = nextLogs.takeLast(24),
            lastEventSummary = if (playerWon) "${enemy.name} succumbed to effects!" else "Fell to lingering hexes."
          ),
          playerWon = playerWon
        )
        return@launch
      }

      val nextRound = active.roundNumber + 1
      if (nextRound > active.maxRounds) {
        val playerPct = updatedPlayer.hp.toFloat() / updatedPlayer.maxHp.coerceAtLeast(1)
        val enemyPct = updatedEnemy.hp.toFloat() / updatedEnemy.maxHp.coerceAtLeast(1)
        val playerWon = playerPct >= enemyPct
        finishSoloBattle(
          active.copy(
            phase = if (playerWon) CombatPhase.VICTORY else CombatPhase.DEFEAT,
            player = updatedPlayer,
            opponent = updatedEnemy,
            logs = (nextLogs + CombatLogEntry(active.roundNumber, "Round limit reached!", isHighlight = true)).takeLast(24),
            lastEventSummary = if (playerWon) "Victory by vitality!" else "Defeat by vitality!"
          ),
          playerWon = playerWon
        )
        return@launch
      }

      val nextState = active.copy(
        phase = CombatPhase.PLAYER_TURN,
        roundNumber = nextRound,
        remainingTurnSeconds = active.turnSecondsLimit,
        player = updatedPlayer,
        opponent = updatedEnemy,
        logs = nextLogs.takeLast(24),
        lastEventSummary = "${outcome.summaryLine} — Round $nextRound: Your turn!"
      )
      _combatState.value = nextState
      startTurnCountdownIfEnabled()
    }
  }

  private fun startTurnCountdownIfEnabled() {
    roundTimerJob?.cancel()
    val initial = _combatState.value ?: return
    if (initial.turnSecondsLimit <= 0 || initial.phase != CombatPhase.PLAYER_TURN) return

    roundTimerJob = viewModelScope.launch {
      while (isActive) {
        delay(1000L)
        val cur = _combatState.value ?: break
        if (cur.phase != CombatPhase.PLAYER_TURN) break
        val rem = cur.remainingTurnSeconds - 1
        if (rem <= 0) {
          _preparedCombatSpell.value = null
          voiceRecognizer.stopListening()
          val skipped = cur.copy(
            phase = CombatPhase.ENEMY_TURN,
            remainingTurnSeconds = 0,
            logs = (cur.logs + CombatLogEntry(cur.roundNumber, "Turn timer expired! Action forfeited.")).takeLast(24),
            lastEventSummary = "Turn time ran out! ${cur.opponent.name} moves."
          )
          _combatState.value = skipped
          scheduleEnemyTurn(skipped)
          break
        } else {
          _combatState.value = cur.copy(remainingTurnSeconds = rem)
        }
      }
    }
  }

  private fun finishSoloBattle(finalState: CombatState, playerWon: Boolean) {
    cancelCombatTimers()
    _preparedCombatSpell.value = null
    voiceRecognizer.stopListening()
    _combatState.value = finalState

    val cur = _saveData.value
    var updated = cur.copy(battlesCompleted = cur.battlesCompleted + 1)
    if (playerWon) {
      when (finalState.mode) {
        CombatMode.DEATH_EATER_STAGE -> {
          updated = updated.copy(
            deathEatersDefeated = updated.deathEatersDefeated + 1,
            highestStageCleared = maxOf(updated.highestStageCleared, finalState.stageNumber)
          )
        }
        CombatMode.FREE_BATTLE, CombatMode.SANDBOX_BATTLE -> {
          updated = updated.copy(freeBattlesWon = updated.freeBattlesWon + 1)
        }
      }
    }
    persistSave(updateAchievements(updated))
  }

  fun exitSoloCombat() {
    cancelCombatTimers()
    _preparedCombatSpell.value = null
    _combatVoiceFeedback.value = null
    voiceRecognizer.stopListening()
    _combatState.value = null
  }

  private fun cancelCombatTimers() {
    enemyTurnJob?.cancel()
    enemyTurnJob = null
    roundTimerJob?.cancel()
    roundTimerJob = null
  }

  // ==================== WAND, ACHIEVEMENTS, SETTINGS ====================

  fun selectWand(wand: Wand) {
    val save = _saveData.value
    val learnedCount = save.spellProgressMap.values.count { it.unlocked }
    if (!WandCatalog.isUnlocked(wand, learnedCount, save.highestStageCleared)) return
    persistSave(save.copy(selectedWandId = wand.id))
  }

  fun getAchievements(): List<Achievement> = AchievementCatalog.buildAchievements(_saveData.value)

  fun updateSettings(transform: (AppSettings) -> AppSettings) {
    val cur = _saveData.value
    persistSave(cur.copy(settings = transform(cur.settings)))
  }

  fun resetAllProgress() {
    cancelCombatTimers()
    _preparedCombatSpell.value = null
    voiceRecognizer.stopListening()
    _combatState.value = null
    val fresh = saveRepo.resetAll(allSpells)
    _saveData.value = fresh
    _practiceState.value = PracticeUiState(
      selectedSpellId = allSpells.firstOrNull { it.id == "protego" }?.id
        ?: allSpells.firstOrNull()?.id.orEmpty()
    )
  }

  // ==================== LAN MULTIPLAYER ====================

  fun startLanHost(port: Int = 8080) {
    val wand = WandCatalog.getById(_saveData.value.selectedWandId)
    val bonusHp = if (wand.passiveType == WandPassiveType.MAX_HP_BONUS) wand.passiveValue else 0
    lanManager.startHost(
      hostWizardName = _saveData.value.settings.wizardName,
      preferredPort = port,
      maxHp = 120 + bonusHp
    )
  }

  fun toggleLanHostReady() {
    lanManager.toggleHostReady()
  }

  fun startLanDiscovery() {
    discoveryManager.startScanning()
  }

  fun stopLanDiscovery() {
    discoveryManager.stopScanning()
  }

  fun connectToLanHost(ip: String, port: String) {
    lanManager.connectToHost(
      ipInput = ip,
      portInput = port,
      wizardName = _saveData.value.settings.wizardName
    )
  }

  fun sendLanClientReady() {
    lanManager.sendClientReady()
  }

  fun castLanSpell(spellId: String) {
    _preparedCombatSpell.value = null
    lanManager.castSpell(spellId)
  }

  fun disconnectLan() {
    _preparedCombatSpell.value = null
    voiceRecognizer.stopListening()
    lanManager.stopAll("Disconnected from local duel.")
  }

  fun onAppBackgrounded() {
    discoveryManager.stopScanning()
    voiceRecognizer.stopListening()
  }

  // ==================== HELPERS ====================

  fun getUnlockedCombatSpells(): List<Spell> {
    val progress = _saveData.value.spellProgressMap
    return allSpells.filter { it.combatAvailable && (progress[it.id]?.unlocked == true) }
  }

  private fun activeWandPracticeGrace(): Int {
    val wand = WandCatalog.getById(_saveData.value.selectedWandId)
    return if (wand.passiveType == WandPassiveType.PRACTICE_GRACE) wand.passiveValue else 0
  }

  private fun updateAchievements(save: PlayerSaveData): PlayerSaveData {
    val built = AchievementCatalog.buildAchievements(save)
    val newlyUnlocked = built.filter { it.unlocked }.map { it.id }.toSet()
    return save.copy(unlockedAchievementIds = save.unlockedAchievementIds + newlyUnlocked)
  }

  private fun persistSave(next: PlayerSaveData) {
    _saveData.value = next
    viewModelScope.launch(Dispatchers.IO) {
      saveRepo.save(next)
    }
  }

  override fun onCleared() {
    super.onCleared()
    cancelCombatTimers()
    voiceRecognizer.destroy()
    lanManager.stopAll(reason = null)
    discoveryManager.release()
  }
}
