package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.Spell
import com.example.voice.VoiceSessionState
import com.example.voice.VoiceUiPhase

@Composable
fun PhoneticPronunciationCard(
  spell: Spell,
  modifier: Modifier = Modifier
) {
  Surface(
    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.55f)),
    shape = RoundedCornerShape(14.dp),
    modifier = modifier.fillMaxWidth()
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
      Icon(
        imageVector = Icons.Filled.RecordVoiceOver,
        contentDescription = "Pronunciation guide",
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(22.dp)
      )
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = spell.phoneticGuide,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSecondaryContainer,
          fontWeight = FontWeight.Bold
        )
        if (spell.phoneticIpa.isNotBlank()) {
          Text(
            text = spell.phoneticIpa,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}

@Composable
fun VoiceControlPanel(
  spell: Spell,
  voiceState: VoiceSessionState,
  onStartListening: () -> Unit,
  onStopListening: () -> Unit,
  onFallbackSubmit: ((String) -> Unit)? = null,
  onCancel: (() -> Unit)? = null,
  feedbackOverride: String? = null,
  compact: Boolean = false,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var hasMicPermission by remember {
    mutableStateOf(
      ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    )
  }
  var permissionDeniedOnce by remember { mutableStateOf(false) }
  var fallbackText by remember(spell.id) { mutableStateOf("") }

  val permissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { granted ->
    hasMicPermission = granted
    if (granted) {
      permissionDeniedOnce = false
      onStartListening()
    } else {
      permissionDeniedOnce = true
    }
  }

  val isListening = voiceState.phase == VoiceUiPhase.LISTENING
  val isProcessing = voiceState.phase == VoiceUiPhase.PROCESSING

  val pulseScale = if (isListening) {
    val transition = rememberInfiniteTransition(label = "micPulse")
    val anim by transition.animateFloat(
      initialValue = 1.0f,
      targetValue = 1.14f,
      animationSpec = infiniteRepeatable(
        animation = tween(650),
        repeatMode = RepeatMode.Reverse
      ),
      label = "pulseScale"
    )
    anim
  } else {
    1.0f
  }

  val (phaseIcon, phaseLabel, containerColor) = when (voiceState.phase) {
    VoiceUiPhase.LISTENING -> Triple(Icons.Filled.GraphicEq, "LISTENING...", MaterialTheme.colorScheme.primaryContainer)
    VoiceUiPhase.PROCESSING -> Triple(Icons.Filled.GraphicEq, "PROCESSING...", MaterialTheme.colorScheme.secondaryContainer)
    VoiceUiPhase.RECOGNIZED, VoiceUiPhase.SUCCESS -> Triple(Icons.Filled.CheckCircle, "RECOGNIZED", MaterialTheme.colorScheme.tertiaryContainer)
    VoiceUiPhase.REJECTED -> Triple(Icons.Filled.Cancel, "REJECTED", MaterialTheme.colorScheme.errorContainer)
    VoiceUiPhase.UNAVAILABLE -> Triple(Icons.Filled.MicOff, "SPEECH UNAVAILABLE", MaterialTheme.colorScheme.surfaceVariant)
    VoiceUiPhase.IDLE -> Triple(Icons.Filled.Mic, "READY TO SPEAK", MaterialTheme.colorScheme.surface)
  }

  Card(
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = BorderStroke(
      1.5.dp,
      when (voiceState.phase) {
        VoiceUiPhase.LISTENING -> MaterialTheme.colorScheme.primary
        VoiceUiPhase.SUCCESS, VoiceUiPhase.RECOGNIZED -> MaterialTheme.colorScheme.tertiary
        VoiceUiPhase.REJECTED -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.outline
      }
    ),
    modifier = modifier
      .fillMaxWidth()
      .testTag("voice_control_panel")
  ) {
    Column(
      modifier = Modifier.padding(if (compact) 12.dp else 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Icon(imageVector = phaseIcon, contentDescription = phaseLabel, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = phaseLabel,
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = "Say: ${spell.name} (${spell.phoneticGuide})",
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
        if (onCancel != null) {
          IconButton(
            onClick = onCancel,
            modifier = Modifier.minimumInteractiveComponentSize()
          ) {
            Icon(Icons.Filled.Close, contentDescription = "Cancel spell preparation")
          }
        }
      }

      if (voiceState.partialText.isNotBlank() && isListening) {
        Text(
          text = "Hearing: \"${voiceState.partialText}\"",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary
        )
      }

      val statusMsg = feedbackOverride ?: voiceState.statusMessage
      if (statusMsg.isNotBlank()) {
        Text(
          text = statusMsg,
          style = MaterialTheme.typography.bodySmall
        )
      }

      if (!hasMicPermission) {
        Button(
          onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
          modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("grant_mic_btn")
        ) {
          Icon(Icons.Filled.Mic, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text(if (permissionDeniedOnce) "Allow Microphone Permission" else "Enable Microphone to Speak Spell")
        }
      } else if (voiceState.isSpeechServiceAvailable) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
          modifier = Modifier.fillMaxWidth()
        ) {
          Surface(
            onClick = {
              if (isListening || isProcessing) onStopListening() else onStartListening()
            },
            shape = CircleShape,
            color = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            modifier = Modifier
              .size(if (compact) 56.dp else 68.dp)
              .scale(pulseScale)
              .minimumInteractiveComponentSize()
              .testTag("voice_mic_btn")
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = if (isListening) Icons.Filled.GraphicEq else Icons.Filled.Mic,
                contentDescription = if (isListening) "Stop listening" else "Speak spell",
                tint = if (isListening) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(28.dp)
              )
            }
          }
          Spacer(modifier = Modifier.width(12.dp))
          OutlinedButton(
            onClick = { if (isListening) onStopListening() else onStartListening() },
            modifier = Modifier.minimumInteractiveComponentSize()
          ) {
            Text(if (isListening) "Stop Listening" else "Speak \"${spell.name}\"")
          }
        }
      }

      // Deterministic phonetic fallback ONLY when on-device SpeechRecognizer service is missing
      if (!voiceState.isSpeechServiceAvailable && onFallbackSubmit != null) {
        Text(
          text = "On-device speech service is unavailable on this device. Enter exact phonetic spell name below:",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = fallbackText,
            onValueChange = { fallbackText = it },
            label = { Text("Spell Incantation") },
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          Button(
            onClick = { onFallbackSubmit(fallbackText) },
            modifier = Modifier.minimumInteractiveComponentSize()
          ) {
            Text("Verify")
          }
        }
      }
    }
  }
}
