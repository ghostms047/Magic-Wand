package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.model.ThemePreference

private val DarkColorScheme = darkColorScheme(
  primary = SanctumGold,
  onPrimary = Color(0xFF1F1606),
  primaryContainer = SanctumGoldDeep,
  onPrimaryContainer = SanctumIvory,
  secondary = SanctumBronze,
  onSecondary = Color(0xFF1F150B),
  secondaryContainer = Color(0xFF3A2B1D),
  onSecondaryContainer = SanctumIvory,
  tertiary = SanctumEmerald,
  onTertiary = Color(0xFF0A2014),
  tertiaryContainer = Color(0xFF1D402D),
  onTertiaryContainer = Color(0xFFD7F4E2),
  error = SanctumCrimson,
  onError = Color(0xFF280909),
  errorContainer = Color(0xFF522022),
  onErrorContainer = Color(0xFFFFDAD6),
  background = SanctumBg,
  onBackground = SanctumIvory,
  surface = SanctumSurface,
  onSurface = SanctumIvory,
  surfaceVariant = SanctumSurfaceHigh,
  onSurfaceVariant = SanctumMuted,
  outline = SanctumOutline
)

private val LightColorScheme = lightColorScheme(
  primary = ParchmentIndigo,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFDAD3F5),
  onPrimaryContainer = Color(0xFF1C1342),
  secondary = ParchmentGold,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFF3E2BE),
  onSecondaryContainer = Color(0xFF2B1C03),
  tertiary = ParchmentEmerald,
  onTertiary = Color.White,
  tertiaryContainer = Color(0xFFCDEBD8),
  onTertiaryContainer = Color(0xFF0B2B1A),
  error = ParchmentCrimson,
  onError = Color.White,
  errorContainer = Color(0xFFF9D7D7),
  onErrorContainer = Color(0xFF3E0A0A),
  background = ParchmentBg,
  onBackground = ParchmentInk,
  surface = ParchmentSurface,
  onSurface = ParchmentInk,
  surfaceVariant = ParchmentSurfaceHigh,
  onSurfaceVariant = ParchmentMuted,
  outline = ParchmentOutline
)

private val MagicWandShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(16.dp),
  large = RoundedCornerShape(22.dp)
)

@Composable
fun MagicWandTheme(
  themePreference: ThemePreference = ThemePreference.DARK,
  content: @Composable () -> Unit
) {
  val useDark = when (themePreference) {
    ThemePreference.DARK -> true
    ThemePreference.LIGHT -> false
    ThemePreference.SYSTEM -> isSystemInDarkTheme()
  }
  val colorScheme = if (useDark) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    shapes = MagicWandShapes,
    content = content
  )
}
