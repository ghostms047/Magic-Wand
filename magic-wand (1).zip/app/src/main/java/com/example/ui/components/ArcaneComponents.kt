package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.engine.PatternValidator
import com.example.engine.Point2D
import com.example.model.ComboDefinition
import com.example.model.MasteryLevel
import com.example.model.PlayerState
import com.example.model.Spell
import com.example.model.SpellCategory
import kotlin.math.hypot

@Composable
fun MasteryBadge(mastery: MasteryLevel, modifier: Modifier = Modifier) {
  val (bg, fg) = when (mastery) {
    MasteryLevel.LOCKED -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    MasteryLevel.LEARNING -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    MasteryLevel.LEARNED -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
    MasteryLevel.SKILLED -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    MasteryLevel.MASTERED -> MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.onPrimary
  }
  Surface(
    color = bg,
    shape = RoundedCornerShape(8.dp),
    modifier = modifier
  ) {
    Text(
      text = mastery.displayName.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = fg,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}

@Composable
fun CategoryBadge(category: SpellCategory, modifier: Modifier = Modifier) {
  val (bg, fg) = when (category) {
    SpellCategory.OFFENSIVE -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
    SpellCategory.DEFENSIVE -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
    SpellCategory.SUPPORT -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
    SpellCategory.CONTROL -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
    SpellCategory.FORBIDDEN -> MaterialTheme.colorScheme.error to MaterialTheme.colorScheme.onError
    SpellCategory.SPECIAL -> MaterialTheme.colorScheme.primary to MaterialTheme.colorScheme.onPrimary
  }
  Surface(
    color = bg,
    shape = RoundedCornerShape(8.dp),
    modifier = modifier
  ) {
    Text(
      text = category.displayName,
      style = MaterialTheme.typography.labelSmall,
      color = fg,
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
    )
  }
}

@Composable
fun RunePatternMiniPreview(
  patternNodes: List<Int>,
  modifier: Modifier = Modifier
) {
  val lineColor = MaterialTheme.colorScheme.primary
  val dotColor = MaterialTheme.colorScheme.outline
  val activeDotColor = MaterialTheme.colorScheme.primary

  Canvas(
    modifier = modifier
      .size(56.dp)
      .clip(RoundedCornerShape(10.dp))
      .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
      .padding(4.dp)
  ) {
    for (idx in 0..8) {
      val c = PatternValidator.nodeCenter(idx)
      val pos = Offset(c.x * size.width, c.y * size.height)
      val isInPattern = idx in patternNodes
      drawCircle(
        color = if (isInPattern) activeDotColor else dotColor.copy(alpha = 0.5f),
        radius = if (isInPattern) 3.5.dp.toPx() else 2.dp.toPx(),
        center = pos
      )
    }
    if (patternNodes.size >= 2) {
      val path = Path()
      patternNodes.forEachIndexed { i, nodeIdx ->
        val c = PatternValidator.nodeCenter(nodeIdx)
        val pos = Offset(c.x * size.width, c.y * size.height)
        if (i == 0) path.moveTo(pos.x, pos.y) else path.lineTo(pos.x, pos.y)
      }
      drawPath(
        path = path,
        color = lineColor,
        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
      )
    }
  }
}

@Composable
fun RunePracticeBoard(
  spellId: String,
  expectedNodes: List<Int>,
  showHints: Boolean,
  tapAccessibilityMode: Boolean,
  locked: Boolean,
  hapticsEnabled: Boolean,
  onTraceComplete: (List<Int>, List<Point2D>) -> Unit,
  onTapSequenceComplete: (List<Int>) -> Unit,
  modifier: Modifier = Modifier
) {
  val haptic = LocalHapticFeedback.current
  val hitNodes = remember(spellId, tapAccessibilityMode) { mutableStateListOf<Int>() }
  val strokePoints = remember(spellId, tapAccessibilityMode) { mutableStateListOf<Point2D>() }
  var currentDragOffset by remember(spellId, tapAccessibilityMode) { mutableStateOf<Point2D?>(null) }
  var boardLockedLocal by remember(spellId, locked, tapAccessibilityMode) { mutableStateOf(locked) }

  androidx.compose.runtime.LaunchedEffect(locked, spellId, tapAccessibilityMode) {
    if (!locked) {
      hitNodes.clear()
      strokePoints.clear()
      currentDragOffset = null
      boardLockedLocal = false
    }
  }

  val primaryColor = MaterialTheme.colorScheme.primary
  val secondaryColor = MaterialTheme.colorScheme.secondary
  val outlineColor = MaterialTheme.colorScheme.outline
  val surfaceColor = MaterialTheme.colorScheme.surfaceVariant
  val onSurfaceColor = MaterialTheme.colorScheme.onSurface

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxWidth()
  ) {
    BoxWithConstraints(
      modifier = Modifier
        .widthIn(max = 340.dp)
        .fillMaxWidth()
        .aspectRatio(1f)
        .clip(RoundedCornerShape(20.dp))
        .background(surfaceColor.copy(alpha = 0.55f))
        .border(1.5.dp, outlineColor.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
        .testTag("rune_practice_board")
    ) {
      val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
      val heightPx = constraints.maxHeight.toFloat().coerceAtLeast(1f)
      val hitRadiusNorm = 0.115f

      Canvas(
        modifier = Modifier
          .fillMaxSize()
          .then(
            if (!tapAccessibilityMode) {
              Modifier.pointerInput(spellId, locked) {
                if (locked) return@pointerInput
                detectDragGestures(
                  onDragStart = { startOffset ->
                    if (locked || boardLockedLocal) return@detectDragGestures
                    hitNodes.clear()
                    strokePoints.clear()
                    val norm = Point2D(
                      (startOffset.x / widthPx).coerceIn(0f, 1f),
                      (startOffset.y / heightPx).coerceIn(0f, 1f)
                    )
                    currentDragOffset = norm
                    strokePoints.add(norm)
                    detectNodeHit(norm, hitRadiusNorm)?.let { idx ->
                      hitNodes.add(idx)
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                  },
                  onDrag = { change, _ ->
                    change.consume()
                    if (locked || boardLockedLocal) return@detectDragGestures
                    val norm = Point2D(
                      (change.position.x / widthPx).coerceIn(0f, 1f),
                      (change.position.y / heightPx).coerceIn(0f, 1f)
                    )
                    currentDragOffset = norm
                    val last = strokePoints.lastOrNull()
                    if (last == null || hypot(norm.x - last.x, norm.y - last.y) >= 0.015f) {
                      strokePoints.add(norm)
                    }
                    detectNodeHit(norm, hitRadiusNorm)?.let { idx ->
                      if (hitNodes.lastOrNull() != idx && idx !in hitNodes) {
                        hitNodes.add(idx)
                        if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      }
                    }
                  },
                  onDragEnd = {
                    if (locked || boardLockedLocal) return@detectDragGestures
                    boardLockedLocal = true
                    currentDragOffset = null
                    onTraceComplete(hitNodes.toList(), strokePoints.toList())
                  },
                  onDragCancel = {
                    currentDragOffset = null
                    hitNodes.clear()
                    strokePoints.clear()
                  }
                )
              }
            } else {
              Modifier
            }
          )
      ) {
        // 1. Optional ghost guide lines for learning
        if (showHints && expectedNodes.size >= 2) {
          val guidePath = Path()
          expectedNodes.forEachIndexed { idx, nodeIdx ->
            val c = PatternValidator.nodeCenter(nodeIdx)
            val p = Offset(c.x * size.width, c.y * size.height)
            if (idx == 0) guidePath.moveTo(p.x, p.y) else guidePath.lineTo(p.x, p.y)
          }
          drawPath(
            path = guidePath,
            color = secondaryColor.copy(alpha = 0.28f),
            style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
          )
        }

        // 2. Active user stroke
        if (strokePoints.size >= 2) {
          val strokePath = Path()
          strokePoints.forEachIndexed { idx, pt ->
            val off = Offset(pt.x * size.width, pt.y * size.height)
            if (idx == 0) strokePath.moveTo(off.x, off.y) else strokePath.lineTo(off.x, off.y)
          }
          currentDragOffset?.let { cur ->
            strokePath.lineTo(cur.x * size.width, cur.y * size.height)
          }
          drawPath(
            path = strokePath,
            color = primaryColor,
            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
          )
        } else if (tapAccessibilityMode && hitNodes.size >= 2) {
          val tapPath = Path()
          hitNodes.forEachIndexed { idx, nodeIdx ->
            val c = PatternValidator.nodeCenter(nodeIdx)
            val p = Offset(c.x * size.width, c.y * size.height)
            if (idx == 0) tapPath.moveTo(p.x, p.y) else tapPath.lineTo(p.x, p.y)
          }
          drawPath(
            path = tapPath,
            color = primaryColor,
            style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
          )
        }

        // 3. Draw 9 Rune Nodes
        for (idx in 0..8) {
          val c = PatternValidator.nodeCenter(idx)
          val center = Offset(c.x * size.width, c.y * size.height)
          val isHit = idx in hitNodes
          val isStartHint = showHints && expectedNodes.firstOrNull() == idx
          val isExpected = showHints && idx in expectedNodes

          drawCircle(
            color = when {
              isHit -> primaryColor.copy(alpha = 0.26f)
              isStartHint -> secondaryColor.copy(alpha = 0.24f)
              else -> Color.Transparent
            },
            radius = 22.dp.toPx(),
            center = center
          )
          drawCircle(
            color = when {
              isHit -> primaryColor
              isExpected -> secondaryColor
              else -> outlineColor.copy(alpha = 0.7f)
            },
            radius = if (isHit) 11.dp.toPx() else 8.dp.toPx(),
            center = center
          )
        }
      }

      // 4. Accessible tap overlay buttons when in Tap-Runes mode (or hint step labels)
      for (idx in 0..8) {
        val row = idx / 3
        val col = idx % 3
        val stepIndex = expectedNodes.indexOf(idx)
        val label = when {
          idx in hitNodes -> (hitNodes.indexOf(idx) + 1).toString()
          showHints && stepIndex >= 0 -> (stepIndex + 1).toString()
          else -> null
        }

        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .fillMaxSize(0.333f)
            .align(
              when (row) {
                0 -> when (col) {
                  0 -> Alignment.TopStart
                  1 -> Alignment.TopCenter
                  else -> Alignment.TopEnd
                }
                1 -> when (col) {
                  0 -> Alignment.CenterStart
                  1 -> Alignment.Center
                  else -> Alignment.CenterEnd
                }
                else -> when (col) {
                  0 -> Alignment.BottomStart
                  1 -> Alignment.BottomCenter
                  else -> Alignment.BottomEnd
                }
              }
            )
            .then(
              if (tapAccessibilityMode && !locked && !boardLockedLocal) {
                Modifier
                  .minimumInteractiveComponentSize()
                  .clickable {
                    if (idx !in hitNodes) {
                      hitNodes.add(idx)
                      if (hapticsEnabled) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                      if (hitNodes.size >= expectedNodes.size) {
                        boardLockedLocal = true
                        onTapSequenceComplete(hitNodes.toList())
                      }
                    }
                  }
              } else {
                Modifier
              }
            )
        ) {
          if (label != null) {
            Surface(
              color = if (idx in hitNodes) primaryColor else surfaceColor.copy(alpha = 0.9f),
              shape = CircleShape,
              modifier = Modifier
                .padding(bottom = 36.dp, start = 36.dp)
                .size(20.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelSmall,
                  color = if (idx in hitNodes) MaterialTheme.colorScheme.onPrimary else onSurfaceColor,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }
  }
}

private fun detectNodeHit(normPoint: Point2D, hitRadius: Float): Int? {
  for (idx in 0..8) {
    val c = PatternValidator.nodeCenter(idx)
    if (hypot(normPoint.x - c.x, normPoint.y - c.y) <= hitRadius) {
      return idx
    }
  }
  return null
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CombatantHudCard(
  combatant: PlayerState,
  isActiveTurn: Boolean,
  isOpponent: Boolean,
  modifier: Modifier = Modifier
) {
  val borderColor = if (isActiveTurn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
  val hpFraction = (combatant.hp.toFloat() / combatant.maxHp.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
  val hpColor = when {
    hpFraction > 0.5f -> MaterialTheme.colorScheme.tertiary
    hpFraction > 0.25f -> MaterialTheme.colorScheme.secondary
    else -> MaterialTheme.colorScheme.error
  }

  Card(
    colors = CardDefaults.cardColors(
      containerColor = if (isOpponent) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    border = BorderStroke(if (isActiveTurn) 2.dp else 1.dp, borderColor),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
          Text(
            text = combatant.name,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          if (isActiveTurn) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              color = MaterialTheme.colorScheme.primaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "TURN",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          if (combatant.shield > 0) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.Shield,
                contentDescription = "Shield",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = "${combatant.shield}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.Favorite,
              contentDescription = "HP",
              tint = hpColor,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
              text = "${combatant.hp}/${combatant.maxHp}",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      LinearProgressIndicator(
        progress = { hpFraction },
        color = hpColor,
        trackColor = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier
          .fillMaxWidth()
          .height(8.dp)
          .clip(RoundedCornerShape(4.dp))
      )

      if (combatant.statuses.isNotEmpty()) {
        Spacer(modifier = Modifier.height(6.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          combatant.statuses.forEach { st ->
            Surface(
              color = MaterialTheme.colorScheme.secondaryContainer,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "${st.type.displayName} (${st.remainingTurns}t)",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun CombatSpellCard(
  spell: Spell,
  cooldownRemaining: Int,
  comboMatch: ComboDefinition?,
  enabled: Boolean,
  onCast: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isReady = enabled && cooldownRemaining <= 0
  val border = when {
    !isReady -> BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
    comboMatch != null -> BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
  }

  Card(
    onClick = onCast,
    enabled = isReady,
    border = border,
    colors = CardDefaults.cardColors(
      containerColor = if (comboMatch != null && isReady) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    modifier = modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
      .testTag("cast_spell_${spell.id}")
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = spell.name,
          style = MaterialTheme.typography.titleSmall,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f)
        )
        if (cooldownRemaining > 0) {
          Surface(
            color = MaterialTheme.colorScheme.errorContainer,
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = "CD $cooldownRemaining",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        } else if (comboMatch != null) {
          Surface(
            color = MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(6.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Icon(
                imageVector = Icons.Filled.AutoAwesome,
                contentDescription = "Combo",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(12.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = "COMBO",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimary
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (spell.baseDamage > 0) {
          StatPill(Icons.Filled.Whatshot, "${spell.baseDamage} Dmg", MaterialTheme.colorScheme.error)
        }
        if (spell.baseShield > 0) {
          StatPill(Icons.Filled.Shield, "${spell.baseShield} Ward", MaterialTheme.colorScheme.primary)
        }
        if (spell.baseHeal > 0) {
          StatPill(Icons.Filled.Favorite, "${spell.baseHeal} Heal", MaterialTheme.colorScheme.tertiary)
        }
        if (spell.cooldown > 0 && cooldownRemaining == 0) {
          StatPill(Icons.Filled.Bolt, "${spell.cooldown}t CD", MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
      if (comboMatch != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Chains into ${comboMatch.name}",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
private fun StatPill(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  tint: Color
) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(13.dp))
    Spacer(modifier = Modifier.width(3.dp))
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = tint)
  }
}

@Composable
fun ComboBannerCard(bannerText: String?, modifier: Modifier = Modifier) {
  AnimatedVisibility(
    visible = !bannerText.isNullOrBlank(),
    enter = fadeIn(),
    exit = fadeOut(),
    modifier = modifier
  ) {
    Surface(
      color = MaterialTheme.colorScheme.primaryContainer,
      border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
      ) {
        Icon(
          imageVector = Icons.Filled.AutoAwesome,
          contentDescription = "Combo triggered",
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = bannerText.orEmpty(),
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
      }
    }
  }
}

@Composable
fun LockedBadgeRow(requirementText: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Icon(
      imageVector = Icons.Filled.Lock,
      contentDescription = "Locked",
      tint = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.size(15.dp)
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(
      text = requirementText,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )
  }
}
