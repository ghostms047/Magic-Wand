package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.WandCatalog
import com.example.model.Achievement
import com.example.model.AppSettings
import com.example.model.PlayerSaveData
import com.example.model.ThemePreference
import com.example.model.Wand
import com.example.ui.components.LockedBadgeRow

@Composable
fun WandScreen(
  saveData: PlayerSaveData,
  onSelectWand: (Wand) -> Unit,
  modifier: Modifier = Modifier
) {
  val learnedCount = saveData.spellProgressMap.values.count { it.unlocked }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Wand Chamber", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "Select your arcane focus. Wands offer gentle progression perks without breaking duel balance.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    items(WandCatalog.wands, key = { it.id }) { wand ->
      val isUnlocked = WandCatalog.isUnlocked(wand, learnedCount, saveData.highestStageCleared)
      val isSelected = saveData.selectedWandId == wand.id

      Card(
        colors = CardDefaults.cardColors(
          containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
          if (isSelected) 2.dp else 1.dp,
          if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)
        ),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
          .testTag("wand_card_${wand.id}")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
              Icon(
                imageVector = Icons.Filled.AutoFixHigh,
                contentDescription = null,
                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(text = wand.name, style = MaterialTheme.typography.titleLarge)
                Text(
                  text = "${wand.wood} • ${wand.core}",
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
            if (isSelected) {
              Surface(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = "EQUIPPED",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onPrimary,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(text = wand.description, style = MaterialTheme.typography.bodyMedium)
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Passive Perk: +${wand.passiveValue} ${wand.passiveType.label}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
          )

          Spacer(modifier = Modifier.height(10.dp))
          if (isUnlocked) {
            Button(
              onClick = { onSelectWand(wand) },
              enabled = !isSelected,
              modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
            ) {
              Text(if (isSelected) "Equipped" else "Equip Wand")
            }
          } else {
            LockedBadgeRow(requirementText = "Requires: ${wand.unlockRequirementLabel}")
          }
        }
      }
    }
  }
}

@Composable
fun AchievementsScreen(
  achievements: List<Achievement>,
  modifier: Modifier = Modifier
) {
  val unlockedCount = achievements.count { it.unlocked }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Achievements", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "$unlockedCount / ${achievements.size} Unlocked",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }

    items(achievements, key = { it.id }) { item ->
      val ratio = (item.currentCount.toFloat() / item.targetCount.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
      Card(
        colors = CardDefaults.cardColors(
          containerColor = if (item.unlocked) MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
          1.dp,
          if (item.unlocked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
        ),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (item.unlocked) Icons.Filled.CheckCircle else Icons.Filled.EmojiEvents,
              contentDescription = null,
              tint = if (item.unlocked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(text = item.title, style = MaterialTheme.typography.titleMedium)
              Text(
                text = item.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Text(
              text = "${item.currentCount}/${item.targetCount}",
              style = MaterialTheme.typography.labelSmall,
              color = if (item.unlocked) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { ratio },
            modifier = Modifier
              .fillMaxWidth()
              .height(6.dp)
              .clip(RoundedCornerShape(3.dp))
          )
        }
      }
    }
  }
}

@Composable
fun SettingsScreen(
  settings: AppSettings,
  onUpdateSettings: ((AppSettings) -> AppSettings) -> Unit,
  onResetProgress: () -> Unit,
  modifier: Modifier = Modifier
) {
  var nameDraft by remember(settings.wizardName) { mutableStateOf(settings.wizardName) }
  var showResetConfirm by remember { mutableStateOf(false) }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Sanctum Settings", style = MaterialTheme.typography.headlineSmall)
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "Wizard Identity", style = MaterialTheme.typography.titleMedium)
          OutlinedTextField(
            value = nameDraft,
            onValueChange = { if (it.length <= 24) nameDraft = it },
            label = { Text("Wizard Name (used in Duels & LAN)") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("settings_name_input")
          )
          Button(
            onClick = {
              val cleaned = nameDraft.trim().ifBlank { "Apprentice" }
              nameDraft = cleaned
              onUpdateSettings { it.copy(wizardName = cleaned) }
            },
            modifier = Modifier.minimumInteractiveComponentSize()
          ) {
            Text("Save Wizard Name")
          }
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "Visual Theme", style = MaterialTheme.typography.titleMedium)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemePreference.entries.forEach { pref ->
              FilterChip(
                selected = settings.themePreference == pref,
                onClick = { onUpdateSettings { it.copy(themePreference = pref) } },
                label = { Text(pref.displayName) }
              )
            }
          }

          SettingsToggleRow(
            title = "Voice Casting in Combat",
            subtitle = "Require speaking prepared spells via microphone to cast in battles",
            checked = settings.voiceCastingInCombat,
            onCheckedChange = { checked -> onUpdateSettings { it.copy(voiceCastingInCombat = checked) } }
          )
          SettingsToggleRow(
            title = "Practice Pattern Guides",
            subtitle = "Show numbered rune order hints on the practice board",
            checked = settings.showPatternHints,
            onCheckedChange = { checked -> onUpdateSettings { it.copy(showPatternHints = checked) } }
          )
          SettingsToggleRow(
            title = "Haptic Wand Feedback",
            subtitle = "Vibrate gently when tracing across runes",
            checked = settings.hapticsEnabled,
            onCheckedChange = { checked -> onUpdateSettings { it.copy(hapticsEnabled = checked) } }
          )
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(text = "Reset Local Save Data", style = MaterialTheme.typography.titleMedium)
          Text(
            text = "Clears learned spells, practice accuracy, Death Eater stages, wands, and achievements.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          OutlinedButton(
            onClick = { showResetConfirm = true },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("settings_reset_btn")
          ) {
            Text("Reset Progress")
          }
        }
      }
    }
  }

  if (showResetConfirm) {
    AlertDialog(
      onDismissRequest = { showResetConfirm = false },
      title = { Text("Reset All Progress?") },
      text = { Text("This will erase your local spell mastery, cleared Death Eater stages, and achievements.") },
      confirmButton = {
        Button(
          onClick = {
            showResetConfirm = false
            onResetProgress()
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("Confirm Reset")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetConfirm = false }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
private fun SettingsToggleRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Row(
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(text = title, style = MaterialTheme.typography.titleSmall)
      Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Switch(checked = checked, onCheckedChange = onCheckedChange)
  }
}
