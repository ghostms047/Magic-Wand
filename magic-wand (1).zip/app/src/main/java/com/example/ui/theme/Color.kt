package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Enchanted Midnight Sanctum (Dark Theme)
val SanctumBg = Color(0xFF12101E)
val SanctumSurface = Color(0xFF1B182B)
val SanctumSurfaceHigh = Color(0xFF25213B)
val SanctumGold = Color(0xFFD8AE5E)
val SanctumGoldDeep = Color(0xFF8C692B)
val SanctumBronze = Color(0xFFC48B5A)
val SanctumEmerald = Color(0xFF5FA67F)
val SanctumCrimson = Color(0xFFD46363)
val SanctumAzure = Color(0xFF6B97D1)
val SanctumIvory = Color(0xFFF3EDE2)
val SanctumMuted = Color(0xFFB5AEC2)
val SanctumOutline = Color(0xFF3E3859)

// Illuminated Vellum Parchment (Light Theme)
val ParchmentBg = Color(0xFFF7F2E7)
val ParchmentSurface = Color(0xFFEDE4D2)
val ParchmentSurfaceHigh = Color(0xFFE2D6BF)
val ParchmentIndigo = Color(0xFF3E3272)
val ParchmentGold = Color(0xFF91651C)
val ParchmentEmerald = Color(0xFF2D6B48)
val ParchmentCrimson = Color(0xFFA83A3A)
val ParchmentInk = Color(0xFF1E1929)
val ParchmentMuted = Color(0xFF5A5268)
val ParchmentOutline = Color(0xFFC7B99D)
