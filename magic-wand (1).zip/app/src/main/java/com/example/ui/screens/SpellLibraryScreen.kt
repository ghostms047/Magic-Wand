package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.MasteryCalculator
import com.example.model.MasteryLevel
import com.example.model.Spell
import com.example.model.SpellCategory
import com.example.model.SpellProgress
import com.example.ui.components.CategoryBadge
import com.example.ui.components.MasteryBadge
import com.example.ui.components.RunePatternMiniPreview

@Composable
fun SpellLibraryScreen(
  spells: List<Spell>,
  progressMap: Map<String, SpellProgress>,
  selectedCategory: SpellCategory?,
  onSelectCategory: (SpellCategory?) -> Unit,
  onOpenSpellDetail: (String) -> Unit,
  onPracticeSpell: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }

  val filtered = remember(spells, selectedCategory, searchQuery) {
    spells.filter { sp ->
      val catMatch = selectedCategory == null || sp.category == selectedCategory
      val q = searchQuery.trim().lowercase()
      val textMatch = q.isEmpty() || sp.name.lowercase().contains(q) || sp.category.displayName.lowercase().contains(q)
      catMatch && textMatch
    }
  }
  val learnedCount = progressMap.values.count { it.unlocked }

  Column(
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    Column(
      modifier = Modifier
        .widthIn(max = 640.dp)
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
      Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(text = "Arcane Grimoire", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "$learnedCount / ${spells.size} Learned",
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.primary
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search spells") },
        placeholder = { Text("Search ${spells.size} spells...") },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("library_search_input")
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState())
      ) {
        FilterChip(
          selected = selectedCategory == null,
          onClick = { onSelectCategory(null) },
          label = { Text("ALL") },
          modifier = Modifier.testTag("filter_all")
        )
        SpellCategory.entries.forEach { cat ->
          FilterChip(
            selected = selectedCategory == cat,
            onClick = { onSelectCategory(cat) },
            label = { Text(cat.displayName.uppercase()) },
            modifier = Modifier.testTag("filter_${cat.name.lowercase()}")
          )
        }
      }
    }

    LazyColumn(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = Modifier.fillMaxSize()
    ) {
      items(filtered, key = { it.id }) { spell ->
        val progress = progressMap[spell.id] ?: SpellProgress(spellId = spell.id)
        SpellLibraryCard(
          spell = spell,
          progress = progress,
          onOpenDetail = { onOpenSpellDetail(spell.id) },
          onPractice = { onPracticeSpell(spell.id) },
          modifier = Modifier.widthIn(max = 640.dp)
        )
      }
    }
  }
}

@Composable
private fun SpellLibraryCard(
  spell: Spell,
  progress: SpellProgress,
  onOpenDetail: () -> Unit,
  onPractice: () -> Unit,
  modifier: Modifier = Modifier
) {
  val target = MasteryCalculator.nextMilestoneTarget(spell, progress).coerceAtLeast(1)
  val ratio = (progress.successfulPractices.toFloat() / target.toFloat()).coerceIn(0f, 1f)
  val isCompletelyUnknown = progress.masteryLevel == MasteryLevel.LOCKED && progress.totalAttempts == 0

  val statusLine = when (progress.masteryLevel) {
    MasteryLevel.LOCKED -> "0 / ${spell.requiredPractice} practices to learn"
    MasteryLevel.LEARNING -> "${progress.successfulPractices} / ${spell.requiredPractice} practices to learn"
    MasteryLevel.LEARNED -> "${progress.successfulPractices} / $target to Skilled (75%+ acc)"
    MasteryLevel.SKILLED -> "${progress.successfulPractices} / $target to Mastered (85%+ acc)"
    MasteryLevel.MASTERED -> "Mastered (${progress.successfulPractices} casts)"
  }

  Card(
    onClick = onOpenDetail,
    colors = CardDefaults.cardColors(
      containerColor = if (isCompletelyUnknown) {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.48f)
      } else {
        MaterialTheme.colorScheme.surface
      }
    ),
    border = BorderStroke(
      1.dp,
      if (progress.unlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
      else MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
    ),
    modifier = modifier
      .fillMaxWidth()
      .testTag("library_spell_${spell.id}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            if (isCompletelyUnknown) {
              Icon(
                imageVector = Icons.Filled.Lock,
                contentDescription = "Locked spell",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
            }
            Text(text = spell.name, style = MaterialTheme.typography.titleLarge)
          }
          Spacer(modifier = Modifier.height(4.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CategoryBadge(spell.category)
            MasteryBadge(progress.masteryLevel)
          }
        }
        Spacer(modifier = Modifier.width(10.dp))
        if (!isCompletelyUnknown) {
          RunePatternMiniPreview(patternNodes = spell.patternNodes)
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = if (isCompletelyUnknown) {
          "Unlearned spell (${spell.phoneticGuide}). Practice its rune and spoken form to reveal its full power."
        } else {
          spell.description
        },
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))
      LinearProgressIndicator(
        progress = { ratio },
        modifier = Modifier
          .fillMaxWidth()
          .height(7.dp)
          .clip(RoundedCornerShape(4.dp))
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = statusLine, style = MaterialTheme.typography.bodySmall)
          Text(
            text = if (isCompletelyUnknown) "Difficulty ${spell.difficulty}/5" else "Accuracy: ${progress.averageAccuracy}% (Best ${progress.bestAccuracy}%)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          OutlinedButton(
            onClick = onOpenDetail,
            modifier = Modifier.minimumInteractiveComponentSize()
          ) {
            Text("Details")
          }
          Button(
            onClick = onPractice,
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("practice_btn_${spell.id}")
          ) {
            Text(if (progress.unlocked) "Train" else "Practice")
          }
        }
      }
    }
  }
}
