package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.MasteryCalculator
import com.example.model.MasteryLevel
import com.example.model.Spell
import com.example.model.SpellProgress
import com.example.model.StatusEffectType
import com.example.ui.components.CategoryBadge
import com.example.ui.components.MasteryBadge
import com.example.ui.components.PhoneticPronunciationCard
import com.example.ui.components.RunePatternMiniPreview

@Composable
fun SpellDetailScreen(
  spell: Spell,
  progress: SpellProgress,
  onStartPractice: () -> Unit,
  modifier: Modifier = Modifier
) {
  val target = MasteryCalculator.nextMilestoneTarget(spell, progress).coerceAtLeast(1)
  val ratio = if (!progress.unlocked) {
    (progress.successfulPractices.toFloat() / spell.requiredPractice.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)
  } else {
    (progress.successfulPractices.toFloat() / target.toFloat()).coerceIn(0f, 1f)
  }
  val isCompletelyUnknown = progress.masteryLevel == MasteryLevel.LOCKED && progress.totalAttempts == 0

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = spell.name, style = MaterialTheme.typography.headlineMedium)
              Spacer(modifier = Modifier.height(6.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryBadge(spell.category)
                MasteryBadge(progress.masteryLevel)
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            RunePatternMiniPreview(patternNodes = spell.patternNodes)
          }

          PhoneticPronunciationCard(spell = spell)

          Text(
            text = if (isCompletelyUnknown) {
              "An unlearned arcane incantation. Complete its rune pattern and speak its pronunciation in Practice Mode to unveil its full combat properties."
            } else {
              spell.description
            },
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
          )

          Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Difficulty: ${spell.difficulty}/5", style = MaterialTheme.typography.labelMedium)
            Text(
              text = if (spell.combatAvailable) "Combat Ready" else "Utility Spell",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary
            )
            if (spell.cooldown > 0) {
              Text("Cooldown: ${spell.cooldown}t", style = MaterialTheme.typography.labelMedium)
            }
          }

          if (!isCompletelyUnknown && spell.combatAvailable) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              if (spell.baseDamage > 0) {
                Text("Damage: ${spell.baseDamage}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
              }
              if (spell.baseShield > 0) {
                Text("Shield: ${spell.baseShield}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
              }
              if (spell.baseHeal > 0) {
                Text("Heal: ${spell.baseHeal}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
              }
              if (spell.statusType != StatusEffectType.NONE) {
                Text("Effect: ${spell.statusType.displayName} (${spell.statusDuration}t)", style = MaterialTheme.typography.labelSmall)
              }
            }
          }
        }
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(text = "Mastery & Accuracy", style = MaterialTheme.typography.titleLarge)
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = if (!progress.unlocked) {
                "Progress: ${progress.successfulPractices} / ${spell.requiredPractice}"
              } else {
                "Mastery Progress: ${progress.successfulPractices} / $target"
              },
              style = MaterialTheme.typography.titleMedium
            )
            Text(
              text = "Accuracy: ${progress.averageAccuracy}%",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.primary
            )
          }
          LinearProgressIndicator(
            progress = { ratio },
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp)
              .clip(RoundedCornerShape(5.dp))
          )
          Text(
            text = "Best Accuracy: ${progress.bestAccuracy}% • Total Attempts: ${progress.totalAttempts}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(6.dp))
          Button(
            onClick = onStartPractice,
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("detail_practice_btn")
          ) {
            Icon(Icons.Filled.TouchApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("PRACTICE (PATTERN + VOICE)")
          }
          OutlinedButton(
            onClick = onStartPractice,
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("detail_voice_practice_btn")
          ) {
            Icon(Icons.Filled.Mic, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("VOICE PRACTICE DRILL")
          }
        }
      }
    }
  }
}
