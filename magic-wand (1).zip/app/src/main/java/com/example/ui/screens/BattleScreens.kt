package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.ArenaCatalog
import com.example.data.EnemyCatalog
import com.example.model.Arena
import com.example.model.CombatMode
import com.example.model.CombatPhase
import com.example.model.CombatState
import com.example.model.ComboDefinition
import com.example.model.Enemy
import com.example.model.Spell
import com.example.ui.components.CombatSpellCard
import com.example.ui.components.CombatantHudCard
import com.example.ui.components.ComboBannerCard
import com.example.ui.components.LockedBadgeRow
import com.example.ui.components.VoiceControlPanel
import com.example.voice.VoiceSessionState
import kotlin.math.roundToInt

@Composable
fun DeathEaterBattleScreen(
  highestStageCleared: Int,
  combatState: CombatState?,
  combos: List<ComboDefinition>,
  voiceCastingEnabled: Boolean,
  preparedSpell: Spell?,
  voiceState: VoiceSessionState,
  voiceFeedback: String?,
  onStartStage: (Int) -> Unit,
  onPrepareSpell: (Spell) -> Unit,
  onCancelPreparedSpell: () -> Unit,
  onStartVoiceCast: () -> Unit,
  onStopVoiceCast: () -> Unit,
  onFallbackPronunciation: (String) -> Unit,
  onDirectCastSpell: (String) -> Unit,
  onExitCombat: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (combatState != null && combatState.mode == CombatMode.DEATH_EATER_STAGE) {
    CombatArenaView(
      combatState = combatState,
      combos = combos,
      voiceCastingEnabled = voiceCastingEnabled,
      preparedSpell = preparedSpell,
      voiceState = voiceState,
      voiceFeedback = voiceFeedback,
      onPrepareSpell = onPrepareSpell,
      onCancelPreparedSpell = onCancelPreparedSpell,
      onStartVoiceCast = onStartVoiceCast,
      onStopVoiceCast = onStopVoiceCast,
      onFallbackPronunciation = onFallbackPronunciation,
      onDirectCastSpell = onDirectCastSpell,
      onPlayAgain = { onStartStage(combatState.stageNumber) },
      onExit = onExitCombat,
      modifier = modifier
    )
    return
  }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Death Eater Campaign", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "Face deterministic Death Eater foes across 5 escalating stages. Pronounce prepared spells to cast!",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    items(EnemyCatalog.enemies, key = { it.id }) { enemy ->
      val isUnlocked = enemy.stageNumber <= highestStageCleared + 1
      val isCleared = enemy.stageNumber <= highestStageCleared
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
          1.dp,
          if (isCleared) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.7f)
          else if (isUnlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
          else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
          .testTag("stage_card_${enemy.stageNumber}")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = enemy.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
              Text(text = enemy.name, style = MaterialTheme.typography.titleLarge)
            }
            if (isCleared) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Filled.CheckCircle,
                  contentDescription = "Cleared",
                  tint = MaterialTheme.colorScheme.tertiary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("Cleared", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.tertiary)
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
          Text(text = enemy.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("HP ${enemy.maxHp}", style = MaterialTheme.typography.labelSmall)
            Text("ATK +${enemy.attack}", style = MaterialTheme.typography.labelSmall)
            Text("DEF ${enemy.defense}", style = MaterialTheme.typography.labelSmall)
            Text(enemy.behavior.displayName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
          }
          Spacer(modifier = Modifier.height(10.dp))
          if (isUnlocked) {
            Button(
              onClick = { onStartStage(enemy.stageNumber) },
              modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("start_stage_${enemy.stageNumber}")
            ) {
              Text(if (isCleared) "Replay Stage ${enemy.stageNumber}" else "Challenge Stage ${enemy.stageNumber}")
            }
          } else {
            LockedBadgeRow(requirementText = "Clear Stage ${enemy.stageNumber - 1} to unlock")
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FreeBattleScreen(
  allCombatSpells: List<Spell>,
  unlockedCombatSpells: List<Spell>,
  combatState: CombatState?,
  combos: List<ComboDefinition>,
  voiceCastingEnabled: Boolean,
  preparedSpell: Spell?,
  voiceState: VoiceSessionState,
  voiceFeedback: String?,
  onStartFreeBattle: (
    enemy: Enemy,
    arena: Arena,
    playerHp: Int,
    enemyHp: Int,
    turnSeconds: Int,
    difficultyMultiplier: Float,
    sandboxUnlockAll: Boolean,
    selectedSpellIds: Set<String>
  ) -> Unit,
  onPrepareSpell: (Spell) -> Unit,
  onCancelPreparedSpell: () -> Unit,
  onStartVoiceCast: () -> Unit,
  onStopVoiceCast: () -> Unit,
  onFallbackPronunciation: (String) -> Unit,
  onDirectCastSpell: (String) -> Unit,
  onExitCombat: () -> Unit,
  modifier: Modifier = Modifier
) {
  if (combatState != null && (combatState.mode == CombatMode.FREE_BATTLE || combatState.mode == CombatMode.SANDBOX_BATTLE)) {
    CombatArenaView(
      combatState = combatState,
      combos = combos,
      voiceCastingEnabled = voiceCastingEnabled,
      preparedSpell = preparedSpell,
      voiceState = voiceState,
      voiceFeedback = voiceFeedback,
      onPrepareSpell = onPrepareSpell,
      onCancelPreparedSpell = onCancelPreparedSpell,
      onStartVoiceCast = onStartVoiceCast,
      onStopVoiceCast = onStopVoiceCast,
      onFallbackPronunciation = onFallbackPronunciation,
      onDirectCastSpell = onDirectCastSpell,
      onPlayAgain = onExitCombat,
      onExit = onExitCombat,
      modifier = modifier
    )
    return
  }

  var selectedEnemy by remember { mutableStateOf(EnemyCatalog.enemies.first()) }
  var selectedArena by remember { mutableStateOf(ArenaCatalog.arenas.first()) }
  var playerHpFloat by remember { mutableFloatStateOf(120f) }
  var enemyHpFloat by remember { mutableFloatStateOf(110f) }
  var turnSeconds by remember { mutableIntStateOf(0) }
  var difficultyMultiplier by remember { mutableFloatStateOf(1.0f) }
  var sandboxMode by remember { mutableStateOf(false) }

  val availablePool = if (sandboxMode) allCombatSpells else unlockedCombatSpells
  var selectedSpellIds by remember(sandboxMode, unlockedCombatSpells) {
    mutableStateOf(availablePool.take(10).map { it.id }.toSet())
  }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Free Battle & Sandbox", style = MaterialTheme.typography.headlineSmall)
        Text(
          text = "Customize enemy, arena, HP, round timer, and difficulty. Enable Sandbox to temporarily use all combat spells.",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = "Test / Sandbox Mode", style = MaterialTheme.typography.titleMedium)
              Text(
                text = "Temporarily use all spells in this battle (does not permanently unlock them).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Switch(
              checked = sandboxMode,
              onCheckedChange = { sandboxMode = it },
              modifier = Modifier.testTag("free_battle_sandbox_switch")
            )
          }

          Text(text = "Opponent", style = MaterialTheme.typography.titleSmall)
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
          ) {
            EnemyCatalog.enemies.forEach { enemy ->
              FilterChip(
                selected = selectedEnemy.id == enemy.id,
                onClick = {
                  selectedEnemy = enemy
                  enemyHpFloat = enemy.maxHp.toFloat()
                },
                label = { Text(enemy.name) }
              )
            }
          }

          Text(text = "Arena", style = MaterialTheme.typography.titleSmall)
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
          ) {
            ArenaCatalog.arenas.forEach { arena ->
              FilterChip(
                selected = selectedArena.id == arena.id,
                onClick = { selectedArena = arena },
                label = { Text(arena.name) }
              )
            }
          }
          Text(
            text = selectedArena.subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Text("Your HP: ${playerHpFloat.roundToInt()}", style = MaterialTheme.typography.labelLarge)
          Slider(
            value = playerHpFloat,
            onValueChange = { playerHpFloat = it },
            valueRange = 80f..220f,
            steps = 13
          )

          Text("Enemy HP: ${enemyHpFloat.roundToInt()}", style = MaterialTheme.typography.labelLarge)
          Slider(
            value = enemyHpFloat,
            onValueChange = { enemyHpFloat = it },
            valueRange = 60f..260f,
            steps = 19
          )

          Text("Turn Timer", style = MaterialTheme.typography.titleSmall)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "No Limit", 15 to "15s", 30 to "30s", 45 to "45s").forEach { (sec, label) ->
              FilterChip(
                selected = turnSeconds == sec,
                onClick = { turnSeconds = sec },
                label = { Text(label) }
              )
            }
          }

          Text("Enemy Power Scaling", style = MaterialTheme.typography.titleSmall)
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.75f to "Apprentice", 1.0f to "Standard", 1.25f to "Hard", 1.5f to "Master").forEach { (mult, label) ->
              FilterChip(
                selected = difficultyMultiplier == mult,
                onClick = { difficultyMultiplier = mult },
                label = { Text(label) }
              )
            }
          }

          Text(
            text = "Loadout Spells (${selectedSpellIds.size}/${availablePool.size})",
            style = MaterialTheme.typography.titleSmall
          )
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            availablePool.forEach { sp ->
              val checked = sp.id in selectedSpellIds
              FilterChip(
                selected = checked,
                onClick = {
                  selectedSpellIds = if (checked && selectedSpellIds.size > 1) {
                    selectedSpellIds - sp.id
                  } else {
                    selectedSpellIds + sp.id
                  }
                },
                label = { Text(sp.name) }
              )
            }
          }

          Button(
            onClick = {
              onStartFreeBattle(
                selectedEnemy,
                selectedArena,
                playerHpFloat.roundToInt(),
                enemyHpFloat.roundToInt(),
                turnSeconds,
                difficultyMultiplier,
                sandboxMode,
                selectedSpellIds
              )
            },
            modifier = Modifier
              .fillMaxWidth()
              .minimumInteractiveComponentSize()
              .testTag("start_free_battle_btn")
          ) {
            Text(if (sandboxMode) "Start Sandbox Duel" else "Start Free Battle")
          }
        }
      }
    }
  }
}

@Composable
fun CombatArenaView(
  combatState: CombatState,
  combos: List<ComboDefinition>,
  voiceCastingEnabled: Boolean,
  preparedSpell: Spell?,
  voiceState: VoiceSessionState,
  voiceFeedback: String?,
  onPrepareSpell: (Spell) -> Unit,
  onCancelPreparedSpell: () -> Unit,
  onStartVoiceCast: () -> Unit,
  onStopVoiceCast: () -> Unit,
  onFallbackPronunciation: (String) -> Unit,
  onDirectCastSpell: (String) -> Unit,
  onPlayAgain: () -> Unit,
  onExit: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isEnded = combatState.phase == CombatPhase.VICTORY || combatState.phase == CombatPhase.DEFEAT
  val isPlayerTurn = combatState.phase == CombatPhase.PLAYER_TURN

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    item {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = combatState.arena.name,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
          )
          Text(
            text = "Round ${combatState.roundNumber}/${combatState.maxRounds} • ${
              if (combatState.sandboxUnlockAll) "SANDBOX" else combatState.phase.name.replace('_', ' ')
            }",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
        if (combatState.turnSecondsLimit > 0 && isPlayerTurn) {
          Surface(
            color = if (combatState.remainingTurnSeconds <= 5) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(8.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Icon(Icons.Filled.Timer, contentDescription = "Turn timer", modifier = Modifier.height(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("${combatState.remainingTurnSeconds}s", style = MaterialTheme.typography.labelSmall)
            }
          }
        }
        Spacer(modifier = Modifier.width(8.dp))
        OutlinedButton(
          onClick = onExit,
          modifier = Modifier.minimumInteractiveComponentSize()
        ) {
          Text("Retreat")
        }
      }
    }

    item {
      CombatantHudCard(
        combatant = combatState.opponent,
        isActiveTurn = combatState.phase == CombatPhase.ENEMY_TURN,
        isOpponent = true,
        modifier = Modifier.widthIn(max = 640.dp)
      )
    }

    item {
      ComboBannerCard(
        bannerText = combatState.activeComboBanner,
        modifier = Modifier.widthIn(max = 640.dp)
      )
    }

    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
          Text(
            text = combatState.lastEventSummary,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
          )
          combatState.logs.takeLast(3).reversed().forEach { log ->
            Text(
              text = "R${log.round}: ${log.message}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    item {
      CombatantHudCard(
        combatant = combatState.player,
        isActiveTurn = isPlayerTurn,
        isOpponent = false,
        modifier = Modifier.widthIn(max = 640.dp)
      )
    }

    if (voiceFeedback != null && preparedSpell == null && !isEnded) {
      item {
        Surface(
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
        ) {
          Text(
            text = voiceFeedback,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
          )
        }
      }
    }

    if (isEnded) {
      item {
        val won = combatState.phase == CombatPhase.VICTORY
        Card(
          colors = CardDefaults.cardColors(
            containerColor = if (won) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer
          ),
          border = BorderStroke(1.5.dp, if (won) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error),
          modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .testTag("combat_result_card")
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
              text = if (won) "VICTORY!" else "DEFEAT",
              style = MaterialTheme.typography.headlineMedium
            )
            Text(
              text = if (won) {
                "You prevailed over ${combatState.opponent.name} in ${combatState.roundNumber} rounds."
              } else {
                "${combatState.opponent.name} overpowered you. Practice stronger spells or adjust your ward strategy!"
              },
              style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
              Button(
                onClick = onPlayAgain,
                modifier = Modifier
                  .weight(1f)
                  .minimumInteractiveComponentSize()
              ) {
                Text(if (combatState.mode == CombatMode.DEATH_EATER_STAGE) "Rematch" else "New Setup")
              }
              OutlinedButton(
                onClick = onExit,
                modifier = Modifier
                  .weight(1f)
                  .minimumInteractiveComponentSize()
              ) {
                Text("Exit Arena")
              }
            }
          }
        }
      }
    } else if (voiceCastingEnabled && preparedSpell != null && isPlayerTurn) {
      item {
        VoiceControlPanel(
          spell = preparedSpell,
          voiceState = voiceState,
          onStartListening = onStartVoiceCast,
          onStopListening = onStopVoiceCast,
          onFallbackSubmit = onFallbackPronunciation,
          onCancel = onCancelPreparedSpell,
          feedbackOverride = voiceFeedback,
          compact = true,
          modifier = Modifier.widthIn(max = 640.dp)
        )
      }
    } else {
      item {
        Text(
          text = when {
            !isPlayerTurn -> "${combatState.opponent.name} is acting..."
            voiceCastingEnabled -> "Tap a spell to prepare, then speak it to cast"
            else -> "Select an incantation to cast"
          },
          style = MaterialTheme.typography.titleMedium,
          modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
        )
      }

      items(combatState.availableSpells, key = { it.id }) { spell ->
        val cd = combatState.player.cooldowns[spell.id] ?: 0
        val comboMatch = combos.firstOrNull {
          it.firstSpellId == combatState.player.lastSpellId && it.secondSpellId == spell.id
        }
        CombatSpellCard(
          spell = spell,
          cooldownRemaining = cd,
          comboMatch = comboMatch,
          enabled = isPlayerTurn,
          onCast = {
            if (voiceCastingEnabled) {
              onPrepareSpell(spell)
            } else {
              onDirectCastSpell(spell.id)
            }
          },
          modifier = Modifier.widthIn(max = 640.dp)
        )
      }
    }
  }
}
