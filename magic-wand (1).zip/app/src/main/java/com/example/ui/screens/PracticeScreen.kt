package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.MasteryCalculator
import com.example.engine.Point2D
import com.example.model.Spell
import com.example.model.SpellProgress
import com.example.ui.PracticeStep
import com.example.ui.PracticeUiState
import com.example.ui.components.CategoryBadge
import com.example.ui.components.MasteryBadge
import com.example.ui.components.PhoneticPronunciationCard
import com.example.ui.components.RunePracticeBoard
import com.example.ui.components.VoiceControlPanel
import com.example.voice.VoiceSessionState

@Composable
fun PracticeScreen(
  spells: List<Spell>,
  progressMap: Map<String, SpellProgress>,
  practiceState: PracticeUiState,
  voiceState: VoiceSessionState,
  showHints: Boolean,
  hapticsEnabled: Boolean,
  onSelectSpell: (String) -> Unit,
  onToggleInputMode: () -> Unit,
  onTraceComplete: (List<Int>, List<Point2D>) -> Unit,
  onTapSequenceComplete: (List<Int>) -> Unit,
  onStartVoiceListening: () -> Unit,
  onStopVoiceListening: () -> Unit,
  onFallbackPronunciation: (String) -> Unit,
  onContinue: () -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedSpell = spells.firstOrNull { it.id == practiceState.selectedSpellId } ?: spells.firstOrNull()
  if (selectedSpell == null) return
  val progress = progressMap[selectedSpell.id] ?: SpellProgress(spellId = selectedSpell.id)
  val target = MasteryCalculator.nextMilestoneTarget(selectedSpell, progress).coerceAtLeast(1)
  val ratio = (progress.successfulPractices.toFloat() / selectedSpell.requiredPractice.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    modifier = modifier.fillMaxSize()
  ) {
    // Spell Picker Strip
    item {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Text(text = "Select Spell to Practice", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
        ) {
          spells.forEach { spell ->
            val spProg = progressMap[spell.id]
            FilterChip(
              selected = spell.id == selectedSpell.id,
              onClick = { onSelectSpell(spell.id) },
              label = {
                Text(
                  if (spProg?.unlocked == true) spell.name
                  else "${spell.name} (${spProg?.successfulPractices ?: 0}/${spell.requiredPractice})"
                )
              },
              modifier = Modifier.testTag("practice_select_${spell.id}")
            )
          }
        }
      }
    }

    // Spell Header + Phonetic Guide + Progress
    item {
      Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f)),
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(text = selectedSpell.name, style = MaterialTheme.typography.headlineSmall)
              Spacer(modifier = Modifier.height(4.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                CategoryBadge(selectedSpell.category)
                MasteryBadge(progress.masteryLevel)
              }
            }
            Text(
              text = "Difficulty ${selectedSpell.difficulty}/5",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary
            )
          }

          PhoneticPronunciationCard(spell = selectedSpell)

          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = if (!progress.unlocked) {
                "Learn Progress: ${progress.successfulPractices} / ${selectedSpell.requiredPractice}"
              } else {
                "Mastery Progress: ${progress.successfulPractices} / $target"
              },
              style = MaterialTheme.typography.titleSmall
            )
            Text(
              text = "Accuracy: ${progress.averageAccuracy}%",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
          LinearProgressIndicator(
            progress = {
              if (!progress.unlocked) ratio
              else (progress.successfulPractices.toFloat() / target).coerceIn(0f, 1f)
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp))
          )

          // Two-step pipeline indicator
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            StepBadge(
              label = "1. Wand Sigil",
              active = practiceState.step == PracticeStep.PERFORM_PATTERN,
              completed = practiceState.step == PracticeStep.SPEAK_INCANTATION || practiceState.step == PracticeStep.ATTEMPT_SUCCEEDED,
              modifier = Modifier.weight(1f)
            )
            StepBadge(
              label = "2. Speak Spell",
              active = practiceState.step == PracticeStep.SPEAK_INCANTATION,
              completed = practiceState.step == PracticeStep.ATTEMPT_SUCCEEDED,
              modifier = Modifier.weight(1f)
            )
          }
        }
      }
    }

    // Step 1: Pattern / Gesture Input
    if (practiceState.step == PracticeStep.PERFORM_PATTERN) {
      item {
        Column(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
        ) {
          Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = if (practiceState.tapAccessibilityMode) {
                "Tap runes 1..${selectedSpell.patternNodes.size} in order"
              } else {
                "Draw continuous wand stroke"
              },
              style = MaterialTheme.typography.bodyMedium
            )
            OutlinedButton(
              onClick = onToggleInputMode,
              modifier = Modifier.minimumInteractiveComponentSize()
            ) {
              Text(if (practiceState.tapAccessibilityMode) "Switch to Draw" else "Tap Mode")
            }
          }
          if (showHints && selectedSpell.patternHint.isNotBlank()) {
            Text(
              text = "Wand Guide: ${selectedSpell.patternHint}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      item {
        RunePracticeBoard(
          spellId = selectedSpell.id,
          expectedNodes = selectedSpell.patternNodes,
          showHints = showHints,
          tapAccessibilityMode = practiceState.tapAccessibilityMode,
          locked = false,
          hapticsEnabled = hapticsEnabled,
          onTraceComplete = onTraceComplete,
          onTapSequenceComplete = onTapSequenceComplete
        )
      }
    }

    // Step 2: Voice Recognition Input
    if (practiceState.step == PracticeStep.SPEAK_INCANTATION) {
      item {
        VoiceControlPanel(
          spell = selectedSpell,
          voiceState = voiceState,
          onStartListening = onStartVoiceListening,
          onStopListening = onStopVoiceListening,
          onFallbackSubmit = onFallbackPronunciation,
          modifier = Modifier.widthIn(max = 640.dp)
        )
      }
    }

    // Step 3: Result Card (Success or Failure) — Locked until Continue
    if (practiceState.step == PracticeStep.ATTEMPT_FAILED || practiceState.step == PracticeStep.ATTEMPT_SUCCEEDED) {
      val succeeded = practiceState.step == PracticeStep.ATTEMPT_SUCCEEDED
      val patternRes = practiceState.patternResult
      val voiceRes = practiceState.pronunciationResult
      val feedbackText = when {
        succeeded -> voiceRes?.feedback ?: "Incantation mastered!"
        voiceRes != null -> voiceRes.feedback
        patternRes != null -> patternRes.feedback
        else -> "Attempt failed."
      }

      item {
        Card(
          colors = CardDefaults.cardColors(
            containerColor = if (succeeded) {
              MaterialTheme.colorScheme.tertiaryContainer
            } else {
              MaterialTheme.colorScheme.errorContainer
            }
          ),
          border = BorderStroke(
            1.5.dp,
            if (succeeded) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
          ),
          modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
            .testTag("practice_result_card")
        ) {
          Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (succeeded) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                contentDescription = if (succeeded) "Success" else "Failure",
                tint = if (succeeded) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (succeeded) "✓ ${selectedSpell.name.uppercase()} SUCCEEDED" else "✕ ATTEMPT FAILED",
                style = MaterialTheme.typography.titleLarge,
                color = if (succeeded) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer
              )
            }

            Text(
              text = "Accuracy: ${practiceState.combinedAccuracy ?: 0}%  •  Progress: ${progress.successfulPractices} / ${selectedSpell.requiredPractice}",
              style = MaterialTheme.typography.labelLarge
            )
            if (voiceRes != null && voiceRes.recognizedText.isNotBlank()) {
              Text(
                text = "Spoken: \"${voiceRes.recognizedText}\" (${voiceRes.confidencePercent}% voice match)",
                style = MaterialTheme.typography.bodySmall
              )
            }
            Text(text = feedbackText, style = MaterialTheme.typography.bodyMedium)

            practiceState.newlyUnlockedSpellName?.let { unlockedName ->
              Text(
                text = "SPELL LEARNED! $unlockedName is now unlocked!",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary
              )
            }
            practiceState.lastMasteryMessage?.let { msg ->
              Text(
                text = msg,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
              )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Button(
              onClick = onContinue,
              modifier = Modifier
                .fillMaxWidth()
                .minimumInteractiveComponentSize()
                .testTag("practice_continue_btn")
            ) {
              Text("Continue")
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StepBadge(
  label: String,
  active: Boolean,
  completed: Boolean,
  modifier: Modifier = Modifier
) {
  val bg = when {
    completed -> MaterialTheme.colorScheme.tertiaryContainer
    active -> MaterialTheme.colorScheme.primaryContainer
    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
  }
  val fg = when {
    completed -> MaterialTheme.colorScheme.onTertiaryContainer
    active -> MaterialTheme.colorScheme.onPrimaryContainer
    else -> MaterialTheme.colorScheme.onSurfaceVariant
  }
  Surface(
    color = bg,
    shape = RoundedCornerShape(10.dp),
    modifier = modifier
  ) {
    Text(
      text = if (completed) "✓ $label" else label,
      style = MaterialTheme.typography.labelMedium,
      color = fg,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
    )
  }
}
