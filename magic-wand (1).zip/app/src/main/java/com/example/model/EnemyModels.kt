package com.example.model

enum class EnemyBehavior(val displayName: String, val summary: String) {
  FAST_ATTACKER("Fast Attacker", "Strikes swiftly with low-cooldown hexes."),
  AGGRESSIVE("Aggressive", "Relentlessly prioritizes high damage and burn."),
  DEFENSIVE("Defensive", "Raises wards early and mends when injured."),
  COUNTER_FOCUSED("Counter-Focused", "Disrupts wards and exploits your active buffs."),
  HEAVY_ATTACKER("Heavy Attacker", "Fortifies briefly, then unleashes devastating curses.")
}

data class Enemy(
  val id: String,
  val name: String,
  val title: String,
  val stageNumber: Int,
  val maxHp: Int,
  val attack: Int,
  val defense: Int,
  val reactionDelayMs: Long,
  val availableSpellIds: List<String>,
  val difficulty: Int,
  val behavior: EnemyBehavior,
  val description: String
)
