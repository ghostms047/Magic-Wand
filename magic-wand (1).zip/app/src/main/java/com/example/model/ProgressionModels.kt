package com.example.model

data class Achievement(
  val id: String,
  val title: String,
  val description: String,
  val targetCount: Int,
  val currentCount: Int = 0,
  val unlocked: Boolean = false
)

enum class ThemePreference(val displayName: String) {
  DARK("Midnight Sanctum"),
  LIGHT("Illuminated Parchment"),
  SYSTEM("Follow System")
}

data class AppSettings(
  val wizardName: String = "Apprentice",
  val hapticsEnabled: Boolean = true,
  val soundChimeEnabled: Boolean = true,
  val showPatternHints: Boolean = true,
  val voiceCastingInCombat: Boolean = true,
  val themePreference: ThemePreference = ThemePreference.DARK
)

data class PlayerSaveData(
  val spellProgressMap: Map<String, SpellProgress> = emptyMap(),
  val highestStageCleared: Int = 0,
  val battlesCompleted: Int = 0,
  val deathEatersDefeated: Int = 0,
  val freeBattlesWon: Int = 0,
  val combosPerformed: Int = 0,
  val perfectPractices: Int = 0,
  val voiceCastsSucceeded: Int = 0,
  val recentSpellId: String? = "lumos_spark",
  val selectedWandId: String = "wand_oak_phoenix",
  val unlockedAchievementIds: Set<String> = emptySet(),
  val settings: AppSettings = AppSettings()
)
