package com.example.model

data class ComboDefinition(
  val id: String,
  val name: String,
  val firstSpellId: String,
  val secondSpellId: String,
  val bonusDamage: Int,
  val bonusShield: Int,
  val bonusHeal: Int,
  val shatterEnemyShield: Boolean,
  val description: String
)
