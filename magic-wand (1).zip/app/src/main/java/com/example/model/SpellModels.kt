package com.example.model

enum class SpellCategory(val displayName: String) {
  OFFENSIVE("Offensive"),
  DEFENSIVE("Defensive"),
  SUPPORT("Support"),
  CONTROL("Control"),
  FORBIDDEN("Forbidden"),
  SPECIAL("Special")
}

enum class MasteryLevel(val displayName: String, val rankIndex: Int) {
  LOCKED("Locked", 0),
  LEARNING("Learning", 1),
  LEARNED("Learned", 2),
  SKILLED("Skilled", 3),
  MASTERED("Mastered", 4)
}

enum class StatusEffectType(val displayName: String) {
  NONE("None"),
  BURN("Burn"),
  STUN("Stun"),
  WEAKEN("Weaken"),
  REGEN("Regen"),
  WARD_REFLECT("Reflect")
}

data class Spell(
  val id: String,
  val name: String,
  val category: SpellCategory,
  val description: String,
  val difficulty: Int,
  val requiredPractice: Int,
  val cooldown: Int,
  val combatAvailable: Boolean,
  val starterUnlocked: Boolean,
  val baseDamage: Int,
  val baseShield: Int,
  val baseHeal: Int,
  val statusType: StatusEffectType,
  val statusMagnitude: Int,
  val statusDuration: Int,
  val patternNodes: List<Int>,
  val patternHint: String,
  val phoneticIpa: String,
  val phoneticGuide: String,
  val voiceVariants: List<String>
)

data class SpellProgress(
  val spellId: String,
  val successfulPractices: Int = 0,
  val totalAttempts: Int = 0,
  val totalAccuracySum: Int = 0,
  val bestAccuracy: Int = 0,
  val unlocked: Boolean = false,
  val masteryLevel: MasteryLevel = MasteryLevel.LOCKED
) {
  val averageAccuracy: Int
    get() = if (totalAttempts == 0) 0 else (totalAccuracySum / totalAttempts)
}
