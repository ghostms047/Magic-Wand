package com.example.model

enum class WandPassiveType(val label: String) {
  ATTACK_BONUS("Attack Power"),
  SHIELD_BONUS("Ward Strength"),
  HEAL_BONUS("Healing Potency"),
  PRACTICE_GRACE("Practice Grace"),
  MAX_HP_BONUS("Vitality")
}

data class Wand(
  val id: String,
  val name: String,
  val wood: String,
  val core: String,
  val description: String,
  val passiveType: WandPassiveType,
  val passiveValue: Int,
  val unlockRequirementLabel: String,
  val requiredLearnedSpells: Int = 0,
  val requiredStagesCleared: Int = 0
)
