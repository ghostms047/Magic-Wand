package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class VoiceUiPhase {
  IDLE,
  LISTENING,
  PROCESSING,
  RECOGNIZED,
  REJECTED,
  SUCCESS,
  UNAVAILABLE
}

data class VoiceSessionState(
  val phase: VoiceUiPhase = VoiceUiPhase.IDLE,
  val partialText: String = "",
  val spokenText: String = "",
  val rmsLevel: Float = 0f,
  val statusMessage: String = "Tap the microphone and speak the spell.",
  val isSpeechServiceAvailable: Boolean = true
)

/**
 * Lifecycle-safe wrapper around Android's native SpeechRecognizer.
 * Operates strictly on the Main Looper as required by Android SpeechRecognizer.
 */
class VoiceSpellRecognizer(context: Context) {

  private val appContext = context.applicationContext
  private val mainHandler = Handler(Looper.getMainLooper())
  private var recognizer: SpeechRecognizer? = null
  private var isListeningActive = false
  private var currentCallback: ((List<String>) -> Unit)? = null

  private val _state = MutableStateFlow(
    VoiceSessionState(
      isSpeechServiceAvailable = SpeechRecognizer.isRecognitionAvailable(appContext)
    )
  )
  val state: StateFlow<VoiceSessionState> = _state.asStateFlow()

  fun checkAvailability(): Boolean {
    val available = SpeechRecognizer.isRecognitionAvailable(appContext)
    if (!available) {
      _state.value = _state.value.copy(
        phase = VoiceUiPhase.UNAVAILABLE,
        isSpeechServiceAvailable = false,
        statusMessage = "On-device Speech Recognition service is unavailable on this device."
      )
    }
    return available
  }

  fun startListening(promptLabel: String, onHypotheses: (List<String>) -> Unit) {
    mainHandler.post {
      if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.UNAVAILABLE,
          isSpeechServiceAvailable = false,
          statusMessage = "Speech recognition service unavailable on this device."
        )
        return@post
      }

      stopInternal()
      currentCallback = onHypotheses

      try {
        val sr = SpeechRecognizer.createSpeechRecognizer(appContext)
        recognizer = sr
        sr.setRecognitionListener(createListener())

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
          putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
          putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
          putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
          putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }

        isListeningActive = true
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.LISTENING,
          statusMessage = "Listening for $promptLabel...",
          isSpeechServiceAvailable = true
        )
        sr.startListening(intent)
      } catch (e: Exception) {
        isListeningActive = false
        _state.value = VoiceSessionState(
          phase = VoiceUiPhase.UNAVAILABLE,
          isSpeechServiceAvailable = false,
          statusMessage = "Could not start microphone recognition: ${e.message ?: "Unavailable"}"
        )
      }
    }
  }

  fun markAccepted(spokenText: String, feedback: String) {
    _state.value = _state.value.copy(
      phase = VoiceUiPhase.SUCCESS,
      spokenText = spokenText,
      rmsLevel = 0f,
      statusMessage = feedback
    )
  }

  fun markRejected(spokenText: String, feedback: String) {
    _state.value = _state.value.copy(
      phase = VoiceUiPhase.REJECTED,
      spokenText = spokenText,
      rmsLevel = 0f,
      statusMessage = feedback
    )
  }

  fun resetToIdle(message: String = "Tap the microphone and speak the spell.") {
    mainHandler.post {
      stopInternal()
      _state.value = VoiceSessionState(
        phase = VoiceUiPhase.IDLE,
        statusMessage = message,
        isSpeechServiceAvailable = SpeechRecognizer.isRecognitionAvailable(appContext)
      )
    }
  }

  fun stopListening() {
    mainHandler.post {
      stopInternal()
      if (_state.value.phase == VoiceUiPhase.LISTENING || _state.value.phase == VoiceUiPhase.PROCESSING) {
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.IDLE,
          rmsLevel = 0f,
          statusMessage = "Listening cancelled."
        )
      }
    }
  }

  fun destroy() {
    mainHandler.post {
      stopInternal()
    }
  }

  private fun stopInternal() {
    isListeningActive = false
    currentCallback = null
    runCatching { recognizer?.cancel() }
    runCatching { recognizer?.destroy() }
    recognizer = null
  }

  private fun createListener(): RecognitionListener {
    return object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) {
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.LISTENING
        )
      }

      override fun onBeginningOfSpeech() = Unit

      override fun onRmsChanged(rmsdB: Float) {
        if (isListeningActive) {
          val norm = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
          _state.value = _state.value.copy(rmsLevel = norm)
        }
      }

      override fun onBufferReceived(buffer: ByteArray?) = Unit

      override fun onEndOfSpeech() {
        if (isListeningActive) {
          _state.value = _state.value.copy(
            phase = VoiceUiPhase.PROCESSING,
            rmsLevel = 0f,
            statusMessage = "Processing pronunciation..."
          )
        }
      }

      override fun onError(error: Int) {
        if (!isListeningActive) return
        isListeningActive = false
        val cb = currentCallback
        currentCallback = null
        runCatching { recognizer?.destroy() }
        recognizer = null

        val message = when (error) {
          SpeechRecognizer.ERROR_NO_MATCH -> "Could not understand speech. Speak clearly and try again."
          SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech heard. Tap the mic and pronounce the spell."
          SpeechRecognizer.ERROR_AUDIO -> "Microphone audio error. Check device microphone."
          SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
          SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer busy. Try again in a moment."
          SpeechRecognizer.ERROR_NETWORK,
          SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Offline voice pack unavailable; check speech settings or device network."
          else -> "Voice recognition failed (code $error). Try again."
        }
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.REJECTED,
          rmsLevel = 0f,
          statusMessage = message
        )
        if (error == SpeechRecognizer.ERROR_NO_MATCH) {
          cb?.invoke(emptyList())
        }
      }

      override fun onResults(results: Bundle?) {
        if (!isListeningActive) return
        isListeningActive = false
        val cb = currentCallback
        currentCallback = null
        runCatching { recognizer?.destroy() }
        recognizer = null

        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
        val bestText = matches.firstOrNull().orEmpty()
        _state.value = _state.value.copy(
          phase = VoiceUiPhase.RECOGNIZED,
          spokenText = bestText,
          rmsLevel = 0f
        )
        cb?.invoke(matches)
      }

      override fun onPartialResults(partialResults: Bundle?) {
        if (!isListeningActive) return
        val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
          ?.firstOrNull().orEmpty()
        if (partial.isNotBlank()) {
          _state.value = _state.value.copy(partialText = partial)
        }
      }

      override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }
  }
}
