package com.example.network

import com.example.data.ArenaCatalog
import com.example.engine.CombatEngine
import com.example.model.ComboDefinition
import com.example.model.LanMatchStatus
import com.example.model.MatchState
import com.example.model.NetworkMessage
import com.example.model.NetworkMessageType
import com.example.model.PlayerState
import com.example.model.Spell
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicLong

sealed class LanRole {
  data object None : LanRole()
  data class Host(
    val ipAddress: String,
    val port: Int,
    val gameId: String
  ) : LanRole()

  data class Client(
    val hostIp: String,
    val port: Int,
    val connected: Boolean
  ) : LanRole()
}

data class LanUiState(
  val role: LanRole = LanRole.None,
  val statusBanner: String = "Offline — Choose Create Game or Join Game on the same Wi-Fi.",
  val errorBanner: String? = null,
  val matchState: MatchState? = null,
  val isConnecting: Boolean = false
)

/**
 * Host-authoritative LAN multiplayer engine over TCP sockets.
 * Clients send intents (PLAYER_JOIN, PLAYER_READY, CAST_SPELL).
 * Host validates turns, cooldowns, spell IDs, and computes all combat outcomes deterministically.
 */
class LanMultiplayerManager(
  private val discoveryManager: LanDiscoveryManager,
  private val spellsById: () -> Map<String, Spell>,
  private val combos: () -> List<ComboDefinition>
) {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val stateMutex = Mutex()
  private val sequenceGen = AtomicLong(1L)

  private val _uiState = MutableStateFlow(LanUiState())
  val uiState: StateFlow<LanUiState> = _uiState.asStateFlow()

  private var serverSocket: ServerSocket? = null
  private var acceptJob: Job? = null
  private var clientSocket: Socket? = null
  private var clientReaderJob: Job? = null
  private var clientWriter: BufferedWriter? = null
  private var lastClientSequence: Long = -1L

  fun startHost(hostWizardName: String, preferredPort: Int = 8080, maxHp: Int = 120) {
    stopAll(reason = null)
    scope.launch {
      try {
        val boundServer = runCatching {
          ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(preferredPort))
          }
        }.getOrElse {
          ServerSocket().apply {
            reuseAddress = true
            bind(InetSocketAddress(0))
          }
        }
        serverSocket = boundServer
        val actualPort = boundServer.localPort
        val localIp = LanIpHelper.getLocalIpv4Address()
        val gameId = "MW-${(1000..9999).random()}"

        val initialMatch = MatchState(
          matchId = gameId,
          hostName = hostWizardName.ifBlank { "Host Wizard" },
          clientName = "Waiting...",
          maxHp = maxHp,
          hostState = PlayerState(id = "host", name = hostWizardName.ifBlank { "Host Wizard" }, maxHp = maxHp, hp = maxHp),
          clientState = PlayerState(id = "client", name = "Challenger", maxHp = maxHp, hp = maxHp),
          status = LanMatchStatus.WAITING_FOR_PLAYER,
          lastEventText = "Room $gameId open on $localIp:$actualPort"
        )

        stateMutex.withLock {
          lastClientSequence = -1L
          _uiState.value = LanUiState(
            role = LanRole.Host(ipAddress = localIp, port = actualPort, gameId = gameId),
            statusBanner = "Hosting on $localIp:$actualPort (Room $gameId)",
            errorBanner = null,
            matchState = initialMatch
          )
        }

        discoveryManager.startHostingBeacon(gameId = gameId, hostName = initialMatch.hostName, tcpPort = actualPort)

        acceptJob = scope.launch {
          while (isActive && serverSocket?.isClosed == false) {
            val incoming = try {
              boundServer.accept()
            } catch (_: Exception) {
              break
            }
            handleIncomingClientSocket(incoming)
          }
        }
      } catch (e: Exception) {
        _uiState.value = LanUiState(
          role = LanRole.None,
          statusBanner = "Unable to start local server.",
          errorBanner = "Could not start LAN host: ${e.message ?: "Port unavailable"}"
        )
      }
    }
  }

  private suspend fun handleIncomingClientSocket(socket: Socket) {
    val alreadyHasClient = stateMutex.withLock { clientSocket != null && clientSocket?.isClosed == false }
    if (alreadyHasClient) {
      // Reject duplicate client cleanly
      runCatching {
        val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
        val errMsg = NetworkMessage(
          type = NetworkMessageType.ERROR,
          senderId = "host",
          sequence = sequenceGen.getAndIncrement(),
          text = "Match room is already full."
        )
        writer.write(NetworkMessageCodec.encode(errMsg))
        writer.newLine()
        writer.flush()
        socket.close()
      }
      return
    }

    socket.tcpNoDelay = true
    val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))

    stateMutex.withLock {
      clientSocket = socket
      clientWriter = writer
      lastClientSequence = -1L
    }

    clientReaderJob = scope.launch {
      try {
        while (isActive && !socket.isClosed) {
          val line = reader.readLine() ?: break
          val msg = NetworkMessageCodec.decode(line)
          if (msg == null) {
            sendToClient(
              NetworkMessage(
                type = NetworkMessageType.ERROR,
                senderId = "host",
                sequence = sequenceGen.getAndIncrement(),
                text = "Invalid packet format rejected by host."
              )
            )
            continue
          }
          processHostIncomingMessage(msg)
        }
      } catch (_: Exception) {
        // Socket closed or dropped
      } finally {
        handleClientDisconnectedOnHost()
      }
    }
  }

  private suspend fun processHostIncomingMessage(msg: NetworkMessage) {
    stateMutex.withLock {
      val currentMatch = _uiState.value.matchState ?: return
      if (msg.sequence > 0 && msg.sequence <= lastClientSequence && msg.type == NetworkMessageType.CAST_SPELL) {
        return
      }
      if (msg.sequence > lastClientSequence) {
        lastClientSequence = msg.sequence
      }

      when (msg.type) {
        NetworkMessageType.PLAYER_JOIN -> {
          val cName = msg.playerName?.ifBlank { "Challenger" } ?: "Challenger"
          val updated = currentMatch.copy(
            clientName = cName,
            clientState = currentMatch.clientState.copy(name = cName),
            status = LanMatchStatus.LOBBY_READY_CHECK,
            lastEventText = "$cName joined the duel room!"
          )
          updateHostMatchAndSync(updated, statusText = "$cName connected! Tap Ready to duel.")
          discoveryManager.stopHostingBeacon()
        }

        NetworkMessageType.PLAYER_READY -> {
          if (currentMatch.status != LanMatchStatus.LOBBY_READY_CHECK) return
          val updated = currentMatch.copy(
            clientReady = true,
            lastEventText = "${currentMatch.clientName} is ready!"
          )
          val started = maybeStartMatchIfBothReady(updated)
          updateHostMatchAndSync(started, statusText = started.lastEventText)
        }

        NetworkMessageType.CAST_SPELL -> {
          val spellId = msg.spellId
          if (spellId == null) {
            sendErrorToClient("Missing spell ID.")
            return
          }
          executeAuthoritativeCastLocked(actorId = "client", spellId = spellId)
        }

        NetworkMessageType.PING -> {
          sendToClient(
            NetworkMessage(
              type = NetworkMessageType.PONG,
              senderId = "host",
              sequence = sequenceGen.getAndIncrement()
            )
          )
        }

        NetworkMessageType.PLAYER_DISCONNECT -> {
          handleClientDisconnectedLocked()
        }

        else -> Unit
      }
    }
  }

  private suspend fun handleClientDisconnectedOnHost() {
    stateMutex.withLock {
      handleClientDisconnectedLocked()
    }
  }

  private fun handleClientDisconnectedLocked() {
    runCatching { clientSocket?.close() }
    clientSocket = null
    clientWriter = null
    val role = _uiState.value.role
    val current = _uiState.value.matchState
    if (role is LanRole.Host && current != null) {
      val reset = current.copy(
        clientName = "Waiting...",
        hostReady = false,
        clientReady = false,
        status = LanMatchStatus.WAITING_FOR_PLAYER,
        lastEventText = "Challenger disconnected. Waiting for reconnection..."
      )
      _uiState.value = _uiState.value.copy(
        matchState = reset,
        statusBanner = "Challenger disconnected. Room ${role.gameId} open on ${role.ipAddress}:${role.port}",
        errorBanner = "Opponent disconnected from LAN duel."
      )
      discoveryManager.startHostingBeacon(role.gameId, reset.hostName, role.port)
    }
  }

  fun toggleHostReady() {
    scope.launch {
      stateMutex.withLock {
        val current = _uiState.value.matchState ?: return@withLock
        if (_uiState.value.role !is LanRole.Host) return@withLock
        if (current.status != LanMatchStatus.LOBBY_READY_CHECK && current.status != LanMatchStatus.FINISHED) return@withLock

        val base = if (current.status == LanMatchStatus.FINISHED) {
          current.copy(
            roundNumber = 1,
            hostReady = true,
            clientReady = false,
            activeTurnPlayerId = "host",
            hostState = PlayerState(id = "host", name = current.hostName, maxHp = current.maxHp, hp = current.maxHp),
            clientState = PlayerState(id = "client", name = current.clientName, maxHp = current.maxHp, hp = current.maxHp),
            status = LanMatchStatus.LOBBY_READY_CHECK,
            winnerId = null,
            comboBanner = null,
            lastEventText = "${current.hostName} wants a rematch!"
          )
        } else {
          current.copy(
            hostReady = !current.hostReady,
            lastEventText = if (!current.hostReady) "${current.hostName} is ready!" else "${current.hostName} unready."
          )
        }
        val started = maybeStartMatchIfBothReady(base)
        updateHostMatchAndSync(started, statusText = started.lastEventText)
      }
    }
  }

  private fun maybeStartMatchIfBothReady(match: MatchState): MatchState {
    return if (match.hostReady && match.clientReady && match.status == LanMatchStatus.LOBBY_READY_CHECK) {
      match.copy(
        status = LanMatchStatus.IN_PROGRESS,
        roundNumber = 1,
        activeTurnPlayerId = "host",
        lastEventText = "Duel Started! Round 1 — ${match.hostName}'s turn."
      )
    } else {
      match
    }
  }

  fun castSpell(spellId: String) {
    scope.launch {
      when (_uiState.value.role) {
        is LanRole.Host -> {
          stateMutex.withLock {
            executeAuthoritativeCastLocked(actorId = "host", spellId = spellId)
          }
        }
        is LanRole.Client -> {
          sendToHost(
            NetworkMessage(
              type = NetworkMessageType.CAST_SPELL,
              senderId = "client",
              sequence = sequenceGen.getAndIncrement(),
              spellId = spellId
            )
          )
        }
        LanRole.None -> Unit
      }
    }
  }

  private fun executeAuthoritativeCastLocked(actorId: String, spellId: String) {
    val match = _uiState.value.matchState ?: return
    if (match.status != LanMatchStatus.IN_PROGRESS) {
      if (actorId == "client") sendErrorToClient("Match is not active.")
      return
    }
    if (match.activeTurnPlayerId != actorId) {
      if (actorId == "client") sendErrorToClient("Wait for your turn.")
      return
    }

    val spell = spellsById()[spellId]
    if (spell == null || !spell.combatAvailable) {
      if (actorId == "client") sendErrorToClient("Invalid or non-combat spell.")
      return
    }

    val actorState = if (actorId == "host") match.hostState else match.clientState
    val targetState = if (actorId == "host") match.clientState else match.hostState

    if ((actorState.cooldowns[spell.id] ?: 0) > 0 && !actorState.isStunned) {
      if (actorId == "client") sendErrorToClient("${spell.name} is on cooldown.")
      return
    }

    val outcome = CombatEngine.resolveSpellCast(
      actor = actorState,
      target = targetState,
      spell = spell,
      combos = combos(),
      arena = ArenaCatalog.arenas.first()
    )

    var newHost = if (actorId == "host") outcome.updatedActor else outcome.updatedTarget
    var newClient = if (actorId == "host") outcome.updatedTarget else outcome.updatedActor
    var nextRound = match.roundNumber
    var summary = outcome.summaryLine
    var nextTurnPlayer = if (actorId == "host") "client" else "host"

    // Check immediate knockout
    if (newHost.hp <= 0 || newClient.hp <= 0) {
      val winnerId = when {
        newClient.hp <= 0 && newHost.hp > 0 -> "host"
        newHost.hp <= 0 && newClient.hp > 0 -> "client"
        else -> actorId
      }
      val winnerName = if (winnerId == "host") newHost.name else newClient.name
      val finished = match.copy(
        hostState = newHost,
        clientState = newClient,
        status = LanMatchStatus.FINISHED,
        winnerId = winnerId,
        comboBanner = outcome.comboTriggered?.let { "COMBO! ${it.name}" },
        lastEventText = "$summary — $winnerName wins the duel!"
      )
      updateHostMatchAndSync(finished, statusText = finished.lastEventText)
      return
    }

    // End of round after client (player 2) takes their turn
    if (actorId == "client") {
      val hostTick = CombatEngine.resolveEndOfRound(newHost)
      val clientTick = CombatEngine.resolveEndOfRound(newClient)
      newHost = hostTick.updatedState
      newClient = clientTick.updatedState
      val tickNotes = (hostTick.notes + clientTick.notes).joinToString(" • ")
      if (tickNotes.isNotBlank()) {
        summary = "$summary | $tickNotes"
      }
      if (newHost.hp <= 0 || newClient.hp <= 0) {
        val winnerId = if (newHost.hp >= newClient.hp) "host" else "client"
        val winnerName = if (winnerId == "host") newHost.name else newClient.name
        val finished = match.copy(
          hostState = newHost,
          clientState = newClient,
          status = LanMatchStatus.FINISHED,
          winnerId = winnerId,
          comboBanner = outcome.comboTriggered?.let { "COMBO! ${it.name}" },
          lastEventText = "$summary — $winnerName wins!"
        )
        updateHostMatchAndSync(finished, statusText = finished.lastEventText)
        return
      }
      nextRound += 1
      nextTurnPlayer = "host"
    }

    val updated = match.copy(
      roundNumber = nextRound,
      activeTurnPlayerId = nextTurnPlayer,
      hostState = newHost,
      clientState = newClient,
      comboBanner = outcome.comboTriggered?.let { "COMBO! ${it.name}: ${it.description}" },
      lastEventText = summary
    )
    updateHostMatchAndSync(updated, statusText = summary)
  }

  private fun updateHostMatchAndSync(match: MatchState, statusText: String) {
    _uiState.value = _uiState.value.copy(
      matchState = match,
      statusBanner = statusText,
      errorBanner = null
    )
    val syncType = when (match.status) {
      LanMatchStatus.FINISHED -> NetworkMessageType.MATCH_END
      else -> NetworkMessageType.STATE_SYNC
    }
    sendToClient(
      NetworkMessage(
        type = syncType,
        senderId = "host",
        sequence = sequenceGen.getAndIncrement(),
        text = statusText,
        matchState = match
      )
    )
  }

  private fun sendErrorToClient(errorText: String) {
    sendToClient(
      NetworkMessage(
        type = NetworkMessageType.ERROR,
        senderId = "host",
        sequence = sequenceGen.getAndIncrement(),
        text = errorText
      )
    )
  }

  private fun sendToClient(msg: NetworkMessage) {
    val writer = clientWriter ?: return
    scope.launch {
      runCatching {
        writer.write(NetworkMessageCodec.encode(msg))
        writer.newLine()
        writer.flush()
      }.onFailure {
        handleClientDisconnectedOnHost()
      }
    }
  }

  // ===================== CLIENT FLOW =====================

  fun connectToHost(ipInput: String, portInput: String, wizardName: String) {
    val ip = ipInput.trim()
    val port = LanIpHelper.parseValidPort(portInput)
    if (!LanIpHelper.isValidIpAddressInput(ip)) {
      _uiState.value = _uiState.value.copy(
        errorBanner = "Invalid IP address. Example: 192.168.1.25"
      )
      return
    }
    if (port == null) {
      _uiState.value = _uiState.value.copy(
        errorBanner = "Invalid port. Enter a port between 1024 and 65535."
      )
      return
    }

    stopAll(reason = null)
    _uiState.value = LanUiState(
      role = LanRole.Client(hostIp = ip, port = port, connected = false),
      statusBanner = "Connecting to $ip:$port...",
      errorBanner = null,
      isConnecting = true
    )

    scope.launch {
      var socket: Socket? = null
      try {
        socket = Socket().apply {
          tcpNoDelay = true
          connect(InetSocketAddress(ip, port), 5000)
          soTimeout = 0
        }
        val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
        val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))

        stateMutex.withLock {
          clientSocket = socket
          clientWriter = writer
        }

        _uiState.value = LanUiState(
          role = LanRole.Client(hostIp = ip, port = port, connected = true),
          statusBanner = "Connected to $ip:$port! Joining duel...",
          errorBanner = null,
          isConnecting = false
        )

        sendToHost(
          NetworkMessage(
            type = NetworkMessageType.PLAYER_JOIN,
            senderId = "client",
            sequence = sequenceGen.getAndIncrement(),
            playerName = wizardName.ifBlank { "Challenger" }
          )
        )

        clientReaderJob = scope.launch {
          try {
            while (isActive && !socket.isClosed) {
              val line = reader.readLine() ?: break
              val msg = NetworkMessageCodec.decode(line) ?: continue
              handleClientIncomingMessage(msg)
            }
          } catch (_: Exception) {
            // Disconnected
          } finally {
            if (_uiState.value.role is LanRole.Client) {
              _uiState.value = _uiState.value.copy(
                role = LanRole.None,
                isConnecting = false,
                statusBanner = "Disconnected from host.",
                errorBanner = "Connection to host was lost."
              )
            }
          }
        }
      } catch (_: SocketTimeoutException) {
        runCatching { socket?.close() }
        _uiState.value = LanUiState(
          role = LanRole.None,
          statusBanner = "Connection timed out.",
          errorBanner = "Host did not respond at $ip:$port. Check Wi-Fi and port."
        )
      } catch (e: Exception) {
        runCatching { socket?.close() }
        _uiState.value = LanUiState(
          role = LanRole.None,
          statusBanner = "Host unavailable.",
          errorBanner = "Could not reach $ip:$port (${e.message ?: "Host unavailable"})."
        )
      }
    }
  }

  fun sendClientReady() {
    if (_uiState.value.role !is LanRole.Client) return
    sendToHost(
      NetworkMessage(
        type = NetworkMessageType.PLAYER_READY,
        senderId = "client",
        sequence = sequenceGen.getAndIncrement()
      )
    )
  }

  private fun handleClientIncomingMessage(msg: NetworkMessage) {
    when (msg.type) {
      NetworkMessageType.STATE_SYNC,
      NetworkMessageType.MATCH_END,
      NetworkMessageType.ROUND_START,
      NetworkMessageType.ROUND_END -> {
        val state = msg.matchState ?: return
        _uiState.value = _uiState.value.copy(
          matchState = state,
          statusBanner = msg.text ?: state.lastEventText,
          errorBanner = null,
          isConnecting = false
        )
      }
      NetworkMessageType.ERROR -> {
        _uiState.value = _uiState.value.copy(
          errorBanner = msg.text ?: "Host rejected action.",
          isConnecting = false
        )
      }
      NetworkMessageType.PLAYER_DISCONNECT -> {
        _uiState.value = _uiState.value.copy(
          role = LanRole.None,
          errorBanner = msg.text ?: "Host ended the match.",
          isConnecting = false
        )
      }
      else -> Unit
    }
  }

  private fun sendToHost(msg: NetworkMessage) {
    val writer = clientWriter ?: return
    scope.launch {
      runCatching {
        writer.write(NetworkMessageCodec.encode(msg))
        writer.newLine()
        writer.flush()
      }.onFailure {
        _uiState.value = _uiState.value.copy(
          errorBanner = "Failed to send move to host."
        )
      }
    }
  }

  fun stopAll(reason: String? = "Disconnected from LAN session.") {
    val wasClient = _uiState.value.role is LanRole.Client
    if (wasClient) {
      runCatching {
        val w = clientWriter
        if (w != null) {
          w.write(
            NetworkMessageCodec.encode(
              NetworkMessage(
                type = NetworkMessageType.PLAYER_DISCONNECT,
                senderId = "client",
                sequence = sequenceGen.getAndIncrement()
              )
            )
          )
          w.newLine()
          w.flush()
        }
      }
    }
    discoveryManager.stopHostingBeacon()
    discoveryManager.stopScanning()
    acceptJob?.cancel()
    acceptJob = null
    clientReaderJob?.cancel()
    clientReaderJob = null
    runCatching { clientSocket?.close() }
    clientSocket = null
    clientWriter = null
    runCatching { serverSocket?.close() }
    serverSocket = null

    if (reason != null) {
      _uiState.value = LanUiState(
        role = LanRole.None,
        statusBanner = reason,
        errorBanner = null,
        matchState = null,
        isConnecting = false
      )
    }
  }
}
