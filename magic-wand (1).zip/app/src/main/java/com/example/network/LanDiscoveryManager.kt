package com.example.network

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.example.model.DiscoveredHost
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

class LanDiscoveryManager(context: Context) {

  companion object {
    private const val SERVICE_TYPE = "_magicwand._tcp."
    private const val UDP_DISCOVERY_PORT = 45678
    private const val BEACON_MAGIC = "MAGIC_WAND_LAN_V1"
  }

  private val appContext = context.applicationContext
  private val nsdManager: NsdManager? =
    appContext.getSystemService(Context.NSD_SERVICE) as? NsdManager
  private val wifiManager: WifiManager? =
    appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var broadcastJob: Job? = null
  private var listenJob: Job? = null
  private var registrationListener: NsdManager.RegistrationListener? = null
  private var discoveryListener: NsdManager.DiscoveryListener? = null
  private var multicastLock: WifiManager.MulticastLock? = null

  private val _discoveredHosts = MutableStateFlow<List<DiscoveredHost>>(emptyList())
  val discoveredHosts: StateFlow<List<DiscoveredHost>> = _discoveredHosts.asStateFlow()

  fun startHostingBeacon(gameId: String, hostName: String, tcpPort: Int) {
    stopHostingBeacon()

    // 1. NSD Registration (best-effort)
    runCatching {
      val info = NsdServiceInfo().apply {
        serviceName = "MagicWand-$gameId"
        serviceType = SERVICE_TYPE
        port = tcpPort
        setAttribute("gameId", gameId)
        setAttribute("hostName", hostName)
      }
      val listener = object : NsdManager.RegistrationListener {
        override fun onServiceRegistered(serviceInfo: NsdServiceInfo) = Unit
        override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
        override fun onServiceUnregistered(serviceInfo: NsdServiceInfo) = Unit
        override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
      }
      registrationListener = listener
      nsdManager?.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    // 2. Lightweight UDP Broadcast Beacon (every 1.5s while lobby awaits challenger)
    broadcastJob = scope.launch {
      var socket: DatagramSocket? = null
      try {
        socket = DatagramSocket().apply { broadcast = true }
        val payload = JSONObject().apply {
          put("magic", BEACON_MAGIC)
          put("gameId", gameId)
          put("hostName", hostName)
          put("port", tcpPort)
        }.toString().toByteArray(Charsets.UTF_8)
        val broadcastAddr = InetAddress.getByName("255.255.255.255")

        while (isActive) {
          runCatching {
            val packet = DatagramPacket(payload, payload.size, broadcastAddr, UDP_DISCOVERY_PORT)
            socket.send(packet)
          }
          delay(1500L)
        }
      } catch (_: Exception) {
        // Safe fallback: manual IP:Port entry remains available
      } finally {
        runCatching { socket?.close() }
      }
    }
  }

  fun stopHostingBeacon() {
    broadcastJob?.cancel()
    broadcastJob = null
    registrationListener?.let { listener ->
      runCatching { nsdManager?.unregisterService(listener) }
    }
    registrationListener = null
  }

  fun startScanning() {
    stopScanning()
    _discoveredHosts.value = emptyList()
    acquireMulticastLock()

    // 1. NSD Discovery
    runCatching {
      val listener = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(regType: String) = Unit
        override fun onServiceFound(service: NsdServiceInfo) {
          if (service.serviceType.contains("_magicwand")) {
            resolveNsdService(service)
          }
        }
        override fun onServiceLost(service: NsdServiceInfo) = Unit
        override fun onDiscoveryStopped(serviceType: String) = Unit
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
      }
      discoveryListener = listener
      nsdManager?.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener)
    }

    // 2. UDP Beacon Listener
    listenJob = scope.launch {
      var socket: DatagramSocket? = null
      try {
        socket = DatagramSocket(UDP_DISCOVERY_PORT).apply {
          reuseAddress = true
          soTimeout = 1200
        }
        val buf = ByteArray(1024)
        while (isActive) {
          try {
            val packet = DatagramPacket(buf, buf.size)
            socket.receive(packet)
            val msg = String(packet.data, 0, packet.length, Charsets.UTF_8)
            val obj = JSONObject(msg)
            if (obj.optString("magic") == BEACON_MAGIC) {
              val ip = packet.address.hostAddress ?: continue
              val port = obj.optInt("port", 8080)
              val gameId = obj.optString("gameId", "ROOM")
              val hostName = obj.optString("hostName", "Wizard Host")
              upsertHost(DiscoveredHost(gameId = gameId, hostName = hostName, ipAddress = ip, port = port))
            }
          } catch (_: SocketTimeoutException) {
            pruneStaleHosts()
          } catch (_: Exception) {
            // Ignore malformed UDP datagrams
          }
        }
      } catch (_: Exception) {
        // Port busy or multicast blocked; NSD or manual IP:Port still works
      } finally {
        runCatching { socket?.close() }
      }
    }
  }

  @Suppress("DEPRECATION")
  private fun resolveNsdService(service: NsdServiceInfo) {
    runCatching {
      nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) = Unit
        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
          val hostAddr = serviceInfo.host?.hostAddress ?: return
          val port = serviceInfo.port
          if (port <= 0) return
          val gameId = serviceInfo.attributes["gameId"]?.toString(Charsets.UTF_8) ?: serviceInfo.serviceName
          val hostName = serviceInfo.attributes["hostName"]?.toString(Charsets.UTF_8) ?: "Magic Wand Host"
          upsertHost(DiscoveredHost(gameId = gameId, hostName = hostName, ipAddress = hostAddr, port = port))
        }
      })
    }
  }

  private fun upsertHost(host: DiscoveredHost) {
    val now = System.currentTimeMillis()
    val updated = _discoveredHosts.value
      .filterNot { it.ipAddress == host.ipAddress && it.port == host.port }
      .filter { now - it.lastSeenMs < 7000L } + host.copy(lastSeenMs = now)
    _discoveredHosts.value = updated.sortedBy { it.hostName }
  }

  private fun pruneStaleHosts() {
    val now = System.currentTimeMillis()
    val filtered = _discoveredHosts.value.filter { now - it.lastSeenMs < 7000L }
    if (filtered.size != _discoveredHosts.value.size) {
      _discoveredHosts.value = filtered
    }
  }

  fun stopScanning() {
    listenJob?.cancel()
    listenJob = null
    discoveryListener?.let { listener ->
      runCatching { nsdManager?.stopServiceDiscovery(listener) }
    }
    discoveryListener = null
    releaseMulticastLock()
  }

  private fun acquireMulticastLock() {
    runCatching {
      if (multicastLock == null) {
        multicastLock = wifiManager?.createMulticastLock("MagicWandLanLock")?.apply {
          setReferenceCounted(false)
        }
      }
      if (multicastLock?.isHeld == false) {
        multicastLock?.acquire()
      }
    }
  }

  private fun releaseMulticastLock() {
    runCatching {
      if (multicastLock?.isHeld == true) {
        multicastLock?.release()
      }
    }
  }

  fun release() {
    stopHostingBeacon()
    stopScanning()
  }
}
