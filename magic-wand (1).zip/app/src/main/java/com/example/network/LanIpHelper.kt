package com.example.network

import java.net.Inet4Address
import java.net.NetworkInterface

object LanIpHelper {

  fun getLocalIpv4Address(): String {
    val candidates = mutableListOf<Pair<Int, String>>()
    runCatching {
      val interfaces = NetworkInterface.getNetworkInterfaces() ?: return@runCatching
      for (iface in interfaces) {
        if (!iface.isUp || iface.isLoopback) continue
        val priority = when {
          iface.name.startsWith("wlan", ignoreCase = true) -> 0
          iface.name.startsWith("ap", ignoreCase = true) -> 1
          iface.name.startsWith("eth", ignoreCase = true) -> 2
          else -> 3
        }
        for (addr in iface.inetAddresses) {
          if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
            addr.hostAddress?.let { candidates.add(priority to it) }
          }
        }
      }
    }
    return candidates.minByOrNull { it.first }?.second ?: "127.0.0.1"
  }

  fun isValidIpAddressInput(raw: String): Boolean {
    val trimmed = raw.trim()
    if (trimmed.isEmpty()) return false
    if (trimmed.equals("localhost", ignoreCase = true)) return true
    val parts = trimmed.split('.')
    if (parts.size != 4) return false
    return parts.all { part ->
      val num = part.toIntOrNull() ?: return@all false
      num in 0..255
    }
  }

  fun parseValidPort(raw: String): Int? {
    val port = raw.trim().toIntOrNull() ?: return null
    return if (port in 1024..65535) port else null
  }
}
