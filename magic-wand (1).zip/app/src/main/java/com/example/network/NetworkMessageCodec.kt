package com.example.network

import com.example.model.ActiveStatus
import com.example.model.LanMatchStatus
import com.example.model.MatchState
import com.example.model.NetworkMessage
import com.example.model.NetworkMessageType
import com.example.model.PlayerState
import com.example.model.StatusEffectType
import org.json.JSONArray
import org.json.JSONObject

object NetworkMessageCodec {

  private const val MAX_PACKET_LENGTH = 32_768

  fun encode(message: NetworkMessage): String {
    val obj = JSONObject()
    obj.put("type", message.type.name)
    obj.put("senderId", message.senderId)
    obj.put("sequence", message.sequence)
    message.spellId?.let { obj.put("spellId", it) }
    message.playerName?.let { obj.put("playerName", it) }
    message.text?.let { obj.put("text", it) }
    obj.put("damageAmount", message.damageAmount)
    obj.put("shieldAmount", message.shieldAmount)
    message.matchState?.let { obj.put("matchState", encodeMatchState(it)) }
    return obj.toString()
  }

  fun decode(rawLine: String): NetworkMessage? {
    if (rawLine.isBlank() || rawLine.length > MAX_PACKET_LENGTH) return null
    return runCatching {
      val obj = JSONObject(rawLine)
      val type = NetworkMessageType.valueOf(obj.getString("type"))
      val senderId = obj.optString("senderId", "").take(64)
      if (senderId.isBlank()) return null
      val matchStateObj = obj.optJSONObject("matchState")
      NetworkMessage(
        type = type,
        senderId = senderId,
        sequence = obj.optLong("sequence", 0L),
        spellId = obj.optString("spellId", "").ifBlank { null },
        playerName = obj.optString("playerName", "").ifBlank { null }?.take(32),
        text = obj.optString("text", "").ifBlank { null }?.take(240),
        damageAmount = obj.optInt("damageAmount", 0),
        shieldAmount = obj.optInt("shieldAmount", 0),
        matchState = matchStateObj?.let { decodeMatchState(it) }
      )
    }.getOrNull()
  }

  private fun encodeMatchState(state: MatchState): JSONObject {
    val obj = JSONObject()
    obj.put("matchId", state.matchId)
    obj.put("hostId", state.hostId)
    obj.put("clientId", state.clientId)
    obj.put("hostName", state.hostName)
    obj.put("clientName", state.clientName)
    obj.put("hostReady", state.hostReady)
    obj.put("clientReady", state.clientReady)
    obj.put("roundNumber", state.roundNumber)
    obj.put("maxHp", state.maxHp)
    obj.put("activeTurnPlayerId", state.activeTurnPlayerId)
    obj.put("hostState", encodePlayerState(state.hostState))
    obj.put("clientState", encodePlayerState(state.clientState))
    obj.put("status", state.status.name)
    obj.put("lastEventText", state.lastEventText)
    state.comboBanner?.let { obj.put("comboBanner", it) }
    state.winnerId?.let { obj.put("winnerId", it) }
    return obj
  }

  private fun decodeMatchState(obj: JSONObject): MatchState {
    val hostState = decodePlayerState(obj.getJSONObject("hostState"))
    val clientState = decodePlayerState(obj.getJSONObject("clientState"))
    return MatchState(
      matchId = obj.getString("matchId"),
      hostId = obj.optString("hostId", "host"),
      clientId = obj.optString("clientId", "client"),
      hostName = obj.optString("hostName", "Host Wizard"),
      clientName = obj.optString("clientName", "Challenger"),
      hostReady = obj.optBoolean("hostReady", false),
      clientReady = obj.optBoolean("clientReady", false),
      roundNumber = obj.optInt("roundNumber", 1),
      maxHp = obj.optInt("maxHp", 120),
      activeTurnPlayerId = obj.optString("activeTurnPlayerId", "host"),
      hostState = hostState,
      clientState = clientState,
      status = runCatching {
        LanMatchStatus.valueOf(obj.optString("status", "WAITING_FOR_PLAYER"))
      }.getOrDefault(LanMatchStatus.WAITING_FOR_PLAYER),
      lastEventText = obj.optString("lastEventText", ""),
      comboBanner = obj.optString("comboBanner", "").ifBlank { null },
      winnerId = obj.optString("winnerId", "").ifBlank { null }
    )
  }

  private fun encodePlayerState(player: PlayerState): JSONObject {
    val obj = JSONObject()
    obj.put("id", player.id)
    obj.put("name", player.name)
    obj.put("maxHp", player.maxHp)
    obj.put("hp", player.hp)
    obj.put("shield", player.shield)
    obj.put("attackBonus", player.attackBonus)
    obj.put("defense", player.defense)
    obj.put("shieldBonus", player.shieldBonus)
    obj.put("healBonus", player.healBonus)
    player.lastSpellId?.let { obj.put("lastSpellId", it) }

    val cdObj = JSONObject()
    player.cooldowns.forEach { (k, v) -> cdObj.put(k, v) }
    obj.put("cooldowns", cdObj)

    val statusArr = JSONArray()
    player.statuses.forEach { st ->
      val sObj = JSONObject()
      sObj.put("type", st.type.name)
      sObj.put("magnitude", st.magnitude)
      sObj.put("remainingTurns", st.remainingTurns)
      statusArr.put(sObj)
    }
    obj.put("statuses", statusArr)
    return obj
  }

  private fun decodePlayerState(obj: JSONObject): PlayerState {
    val cooldowns = mutableMapOf<String, Int>()
    val cdObj = obj.optJSONObject("cooldowns")
    if (cdObj != null) {
      val keys = cdObj.keys()
      while (keys.hasNext()) {
        val k = keys.next()
        cooldowns[k] = cdObj.optInt(k, 0)
      }
    }

    val statuses = mutableListOf<ActiveStatus>()
    val statusArr = obj.optJSONArray("statuses")
    if (statusArr != null) {
      for (i in 0 until statusArr.length()) {
        val sObj = statusArr.getJSONObject(i)
        val type = runCatching {
          StatusEffectType.valueOf(sObj.optString("type", "NONE"))
        }.getOrDefault(StatusEffectType.NONE)
        if (type != StatusEffectType.NONE) {
          statuses.add(
            ActiveStatus(
              type = type,
              magnitude = sObj.optInt("magnitude", 0),
              remainingTurns = sObj.optInt("remainingTurns", 0)
            )
          )
        }
      }
    }

    return PlayerState(
      id = obj.getString("id"),
      name = obj.getString("name"),
      maxHp = obj.optInt("maxHp", 120),
      hp = obj.optInt("hp", 120),
      shield = obj.optInt("shield", 0),
      attackBonus = obj.optInt("attackBonus", 0),
      defense = obj.optInt("defense", 0),
      shieldBonus = obj.optInt("shieldBonus", 0),
      healBonus = obj.optInt("healBonus", 0),
      cooldowns = cooldowns,
      statuses = statuses,
      lastSpellId = obj.optString("lastSpellId", "").ifBlank { null }
    )
  }
}
