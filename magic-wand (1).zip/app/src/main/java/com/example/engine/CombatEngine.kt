package com.example.engine

import com.example.model.ActiveStatus
import com.example.model.Arena
import com.example.model.ComboDefinition
import com.example.model.PlayerState
import com.example.model.Spell
import com.example.model.StatusEffectType
import kotlin.math.roundToInt

data class CastOutcome(
  val updatedActor: PlayerState,
  val updatedTarget: PlayerState,
  val damageDealtToHp: Int,
  val shieldAbsorbed: Int,
  val shieldGained: Int,
  val healGained: Int,
  val reflectedDamage: Int,
  val comboTriggered: ComboDefinition?,
  val summaryLine: String
)

data class EndRoundOutcome(
  val updatedState: PlayerState,
  val burnDamage: Int,
  val regenHeal: Int,
  val notes: List<String>
)

object CombatEngine {

  fun resolveSpellCast(
    actor: PlayerState,
    target: PlayerState,
    spell: Spell,
    combos: List<ComboDefinition>,
    arena: Arena,
    damageMultiplier: Float = 1.0f
  ): CastOutcome {
    if (actor.isStunned) {
      val nextActor = actor.copy(lastSpellId = null)
      return CastOutcome(
        updatedActor = nextActor,
        updatedTarget = target,
        damageDealtToHp = 0,
        shieldAbsorbed = 0,
        shieldGained = 0,
        healGained = 0,
        reflectedDamage = 0,
        comboTriggered = null,
        summaryLine = "${actor.name} is stunned and cannot cast this turn!"
      )
    }

    val combo = combos.firstOrNull {
      it.firstSpellId == actor.lastSpellId && it.secondSpellId == spell.id
    }

    var newActor = actor
    var newTarget = target

    // 1. Shield shattering combo
    var shatteredShieldMsg = ""
    if (combo?.shatterEnemyShield == true && newTarget.shield > 0) {
      shatteredShieldMsg = " Shattered ${newTarget.shield} shield!"
      newTarget = newTarget.copy(shield = 0)
    }

    // 2. Offensive damage calculation
    var hpDamage = 0
    var shieldAbsorbed = 0
    var reflectedDamage = 0
    if (spell.baseDamage > 0 || (combo?.bonusDamage ?: 0) > 0) {
      val raw = spell.baseDamage + actor.attackBonus + arena.attackModifier + (combo?.bonusDamage ?: 0)
      val scaled = (raw * damageMultiplier).roundToInt()
      val weakenFactor = (100 - actor.weakenPercent).coerceIn(30, 100) / 100f
      val weakened = (scaled * weakenFactor).roundToInt()
      val mitigated = (weakened - (target.defense / 2)).coerceAtLeast(4)

      if (newTarget.shield >= mitigated) {
        shieldAbsorbed = mitigated
        newTarget = newTarget.copy(shield = newTarget.shield - mitigated)
      } else {
        shieldAbsorbed = newTarget.shield
        val remainder = mitigated - newTarget.shield
        hpDamage = remainder.coerceAtMost(newTarget.hp)
        newTarget = newTarget.copy(
          shield = 0,
          hp = (newTarget.hp - remainder).coerceAtLeast(0)
        )
      }

      // Check Ward Reflect
      val reflectPct = target.reflectPercent
      if (reflectPct > 0 && mitigated > 0) {
        reflectedDamage = ((mitigated * reflectPct) / 100f).roundToInt().coerceAtLeast(1)
        newActor = applyDirectDamage(newActor, reflectedDamage)
      }
    }

    // 3. Shield & Heal for actor
    var shieldGained = 0
    if (spell.baseShield > 0 || (combo?.bonusShield ?: 0) > 0) {
      shieldGained = spell.baseShield + actor.shieldBonus + arena.shieldModifier + (combo?.bonusShield ?: 0)
      newActor = newActor.copy(shield = (newActor.shield + shieldGained).coerceAtMost(80))
    }

    var healGained = 0
    if (spell.baseHeal > 0 || (combo?.bonusHeal ?: 0) > 0) {
      val desiredHeal = spell.baseHeal + actor.healBonus + (combo?.bonusHeal ?: 0)
      val actualHeal = (newActor.hp + desiredHeal).coerceAtMost(newActor.maxHp) - newActor.hp
      healGained = actualHeal.coerceAtLeast(0)
      newActor = newActor.copy(hp = (newActor.hp + desiredHeal).coerceAtMost(newActor.maxHp))
    }

    // 4. Status effects
    var statusMsg = ""
    if (spell.statusType != StatusEffectType.NONE && spell.statusDuration > 0) {
      val activeStatus = ActiveStatus(
        type = spell.statusType,
        magnitude = spell.statusMagnitude,
        remainingTurns = spell.statusDuration
      )
      when (spell.statusType) {
        StatusEffectType.BURN, StatusEffectType.STUN, StatusEffectType.WEAKEN -> {
          val filtered = newTarget.statuses.filterNot { it.type == spell.statusType }
          newTarget = newTarget.copy(statuses = filtered + activeStatus)
          statusMsg = " Inflicted ${spell.statusType.displayName}!"
        }
        StatusEffectType.REGEN, StatusEffectType.WARD_REFLECT -> {
          val filtered = newActor.statuses.filterNot { it.type == spell.statusType }
          newActor = newActor.copy(statuses = filtered + activeStatus)
          statusMsg = " Gained ${spell.statusType.displayName}!"
        }
        StatusEffectType.NONE -> Unit
      }
    }

    // 5. Cooldown + lastSpellId
    val updatedCooldowns = newActor.cooldowns.toMutableMap()
    if (spell.cooldown > 0) {
      updatedCooldowns[spell.id] = spell.cooldown + 1
    }
    newActor = newActor.copy(
      cooldowns = updatedCooldowns,
      lastSpellId = spell.id
    )

    val parts = mutableListOf<String>()
    parts.add("${actor.name} cast ${spell.name}")
    if (hpDamage > 0) parts.add("${hpDamage} HP dmg")
    if (shieldAbsorbed > 0) parts.add("${shieldAbsorbed} blocked")
    if (shieldGained > 0) parts.add("+${shieldGained} shield")
    if (healGained > 0) parts.add("+${healGained} HP")
    if (reflectedDamage > 0) parts.add("${reflectedDamage} reflected")

    val comboPrefix = if (combo != null) "COMBO [${combo.name}]! " else ""
    val summary = comboPrefix + parts.joinToString(" • ") + shatteredShieldMsg + statusMsg

    return CastOutcome(
      updatedActor = newActor,
      updatedTarget = newTarget,
      damageDealtToHp = hpDamage,
      shieldAbsorbed = shieldAbsorbed,
      shieldGained = shieldGained,
      healGained = healGained,
      reflectedDamage = reflectedDamage,
      comboTriggered = combo,
      summaryLine = summary
    )
  }

  fun resolveEndOfRound(state: PlayerState): EndRoundOutcome {
    var current = state
    var burnDmg = 0
    var regenHeal = 0
    val notes = mutableListOf<String>()
    val nextStatuses = mutableListOf<ActiveStatus>()

    for (status in current.statuses) {
      when (status.type) {
        StatusEffectType.BURN -> {
          burnDmg += status.magnitude
          current = applyDirectDamage(current, status.magnitude)
          notes.add("${current.name} took ${status.magnitude} Burn damage")
        }
        StatusEffectType.REGEN -> {
          val healed = (current.hp + status.magnitude).coerceAtMost(current.maxHp) - current.hp
          if (healed > 0) {
            regenHeal += healed
            current = current.copy(hp = current.hp + healed)
            notes.add("${current.name} regenerated +$healed HP")
          }
        }
        else -> Unit
      }
      val rem = status.remainingTurns - 1
      if (rem > 0) {
        nextStatuses.add(status.copy(remainingTurns = rem))
      }
    }

    val nextCooldowns = current.cooldowns
      .mapValues { (_, cd) -> cd - 1 }
      .filterValues { it > 0 }

    current = current.copy(
      statuses = nextStatuses,
      cooldowns = nextCooldowns
    )

    return EndRoundOutcome(
      updatedState = current,
      burnDamage = burnDmg,
      regenHeal = regenHeal,
      notes = notes
    )
  }

  private fun applyDirectDamage(target: PlayerState, amount: Int): PlayerState {
    if (amount <= 0) return target
    return if (target.shield >= amount) {
      target.copy(shield = target.shield - amount)
    } else {
      val rem = amount - target.shield
      target.copy(shield = 0, hp = (target.hp - rem).coerceAtLeast(0))
    }
  }
}
