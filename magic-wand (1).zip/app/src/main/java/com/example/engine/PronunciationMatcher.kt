package com.example.engine

import com.example.model.Spell
import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class PronunciationMatchResult(
  val isMatch: Boolean,
  val recognizedText: String,
  val confidencePercent: Int,
  val feedback: String
)

/**
 * Deterministic local pronunciation matcher (zero AI/ML).
 * Normalizes speech-recognition hypotheses, checks exact/variant strings,
 * and computes normalized Levenshtein + phonetic-skeleton similarity.
 */
object PronunciationMatcher {

  private const val ACCEPT_THRESHOLD = 74

  fun evaluate(spell: Spell, hypotheses: List<String>): PronunciationMatchResult {
    val cleanedHypotheses = hypotheses.map { it.trim() }.filter { it.isNotEmpty() }
    if (cleanedHypotheses.isEmpty()) {
      return PronunciationMatchResult(
        isMatch = false,
        recognizedText = "",
        confidencePercent = 0,
        feedback = "No speech detected. Say \"${spell.name}\" (${spell.phoneticGuide})."
      )
    }

    val targets = (listOf(spell.name) + spell.voiceVariants)
      .map { normalizeText(it) }
      .filter { it.isNotEmpty() }
      .distinct()

    var bestScore = 0
    var bestSpoken = cleanedHypotheses.first()

    for (rawSpoken in cleanedHypotheses) {
      val normSpoken = normalizeText(rawSpoken)
      if (normSpoken.isEmpty()) continue

      // Also check individual sliding n-grams if the user spoke a short phrase around the spell
      val candidatesToCheck = buildList {
        add(normSpoken)
        val words = normSpoken.split(' ').filter { it.isNotBlank() }
        if (words.size in 2..5) {
          addAll(words)
          for (i in 0 until words.size - 1) {
            add("${words[i]} ${words[i + 1]}")
          }
        }
      }

      for (candidate in candidatesToCheck) {
        for (target in targets) {
          val score = similarityPercent(candidate, target)
          if (score > bestScore) {
            bestScore = score
            bestSpoken = rawSpoken
          }
        }
      }
    }

    val accepted = bestScore >= ACCEPT_THRESHOLD
    val feedback = if (accepted) {
      "Recognized \"$bestSpoken\" (${bestScore}% match)."
    } else {
      "Heard \"$bestSpoken\" (${bestScore}%). Expected \"${spell.name}\" (${spell.phoneticGuide})."
    }

    return PronunciationMatchResult(
      isMatch = accepted,
      recognizedText = bestSpoken,
      confidencePercent = bestScore,
      feedback = feedback
    )
  }

  internal fun normalizeText(input: String): String {
    val decomposed = Normalizer.normalize(input.lowercase(), Normalizer.Form.NFD)
    val ascii = decomposed.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "")
    return ascii
      .replace(Regex("[^a-z0-9\\s]"), " ")
      .replace(Regex("\\s+"), " ")
      .trim()
  }

  private fun phoneticSkeleton(text: String): String {
    return text
      .replace(" ", "")
      .replace("ph", "f")
      .replace("ae", "e")
      .replace("qu", "kw")
      .replace("x", "ks")
      .replace("ck", "k")
      .replace("c", "k")
      .replace("y", "i")
      .replace(Regex("(.)\\1+"), "$1")
  }

  private fun similarityPercent(spoken: String, target: String): Int {
    if (spoken == target) return 100
    val compactSpoken = spoken.replace(" ", "")
    val compactTarget = target.replace(" ", "")
    if (compactSpoken == compactTarget) return 98

    val rawSim = levenshteinRatio(compactSpoken, compactTarget)
    val phonSim = levenshteinRatio(phoneticSkeleton(spoken), phoneticSkeleton(target))
    val combined = max(rawSim, phonSim * 0.96f)
    return (combined * 100f).roundToInt().coerceIn(0, 100)
  }

  private fun levenshteinRatio(a: String, b: String): Float {
    val maxLen = max(a.length, b.length)
    if (maxLen == 0) return 1f
    val dist = levenshteinDistance(a, b)
    return (1f - (dist.toFloat() / maxLen.toFloat())).coerceIn(0f, 1f)
  }

  private fun levenshteinDistance(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length

    var prev = IntArray(b.length + 1) { it }
    var curr = IntArray(b.length + 1)

    for (i in 1..a.length) {
      curr[0] = i
      for (j in 1..b.length) {
        val cost = if (a[i - 1] == b[j - 1]) 0 else 1
        curr[j] = min(
          min(curr[j - 1] + 1, prev[j] + 1),
          prev[j - 1] + cost
        )
      }
      val tmp = prev
      prev = curr
      curr = tmp
    }
    return prev[b.length]
  }
}
