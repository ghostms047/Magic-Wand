package com.example.engine

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class Point2D(val x: Float, val y: Float)

data class ValidationResult(
  val isSuccess: Boolean,
  val accuracyPercent: Int,
  val feedback: String
)

object PatternValidator {

  /**
   * Returns normalized [0f..1f] coordinates for each of the 9 rune nodes (0..8) in a 3x3 grid.
   */
  fun nodeCenter(nodeIndex: Int): Point2D {
    val row = nodeIndex / 3
    val col = nodeIndex % 3
    val xs = floatArrayOf(0.2f, 0.5f, 0.8f)
    val ys = floatArrayOf(0.2f, 0.5f, 0.8f)
    return Point2D(xs[col.coerceIn(0, 2)], ys[row.coerceIn(0, 2)])
  }

  /**
   * Deterministic pattern & stroke-precision validation.
   * No ML/AI is used: exact node sequence verification + perpendicular polyline deviation scoring.
   */
  fun validateTrace(
    expectedNodes: List<Int>,
    hitNodes: List<Int>,
    strokePoints: List<Point2D>,
    practiceGraceBonus: Int = 0
  ): ValidationResult {
    if (expectedNodes.isEmpty()) {
      return ValidationResult(false, 0, "Invalid spell pattern configuration.")
    }

    if (hitNodes.size < 2 || strokePoints.size < 2) {
      return ValidationResult(
        isSuccess = false,
        accuracyPercent = 0,
        feedback = "Trace continuously through all ${expectedNodes.size} runes."
      )
    }

    if (hitNodes != expectedNodes) {
      val matchingPrefix = hitNodes.zip(expectedNodes).takeWhile { it.first == it.second }.size
      val partialPct = ((matchingPrefix.toFloat() / expectedNodes.size.toFloat()) * 45f).roundToInt()
      val feedback = when {
        hitNodes.firstOrNull() != expectedNodes.firstOrNull() ->
          "Start at rune #${expectedNodes.first() + 1}, then follow the sequence."
        hitNodes.size < expectedNodes.size ->
          "Incomplete pattern (${hitNodes.size}/${expectedNodes.size} runes). Trace the full sigil."
        else ->
          "Incorrect rune sequence. Follow the numbered path carefully."
      }
      return ValidationResult(
        isSuccess = false,
        accuracyPercent = partialPct.coerceIn(0, 49),
        feedback = feedback
      )
    }

    // Exact node sequence matched -> compute deterministic geometric precision score
    val idealPoints = expectedNodes.map { nodeCenter(it) }
    var totalDistance = 0f
    for (pt in strokePoints) {
      var minSegmentDist = Float.MAX_VALUE
      for (i in 0 until idealPoints.size - 1) {
        val dist = pointToSegmentDistance(pt, idealPoints[i], idealPoints[i + 1])
        if (dist < minSegmentDist) {
          minSegmentDist = dist
        }
      }
      totalDistance += minSegmentDist
    }
    val avgDeviation = totalDistance / strokePoints.size.toFloat()
    // Ideal deviation <= 0.02 -> 100%, deviation 0.14 -> ~60%
    val normalizedError = ((avgDeviation - 0.015f) / 0.15f).coerceIn(0f, 1f)
    val baseAccuracy = (100f - normalizedError * 40f).roundToInt()
    val finalAccuracy = (baseAccuracy + practiceGraceBonus).coerceIn(60, 100)

    val feedback = when {
      finalAccuracy >= 95 -> "Flawless wandwork! Precision incantation."
      finalAccuracy >= 85 -> "Steady and crisp arcane trace."
      else -> "Spell cast succeeded. Smoother lines will raise accuracy."
    }
    return ValidationResult(
      isSuccess = true,
      accuracyPercent = finalAccuracy,
      feedback = feedback
    )
  }

  /**
   * Accessible tap-by-tap validation mode for players who prefer tapping nodes in order.
   */
  fun validateTapSequence(
    expectedNodes: List<Int>,
    tappedNodes: List<Int>,
    practiceGraceBonus: Int = 0
  ): ValidationResult {
    if (tappedNodes != expectedNodes) {
      val matchingPrefix = tappedNodes.zip(expectedNodes).takeWhile { it.first == it.second }.size
      val partialPct = ((matchingPrefix.toFloat() / expectedNodes.size.toFloat()) * 45f).roundToInt()
      return ValidationResult(
        isSuccess = false,
        accuracyPercent = partialPct.coerceIn(0, 49),
        feedback = "Incorrect rune order. Tap runes #${expectedNodes.joinToString(" -> ") { (it + 1).toString() }}."
      )
    }
    val accuracy = (90 + practiceGraceBonus).coerceIn(85, 100)
    return ValidationResult(
      isSuccess = true,
      accuracyPercent = accuracy,
      feedback = "Clean rune sequence cast!"
    )
  }

  private fun pointToSegmentDistance(p: Point2D, a: Point2D, b: Point2D): Float {
    val dx = b.x - a.x
    val dy = b.y - a.y
    val lenSq = dx * dx + dy * dy
    if (lenSq <= 1e-6f) {
      return hypot(p.x - a.x, p.y - a.y)
    }
    val t = max(0f, min(1f, ((p.x - a.x) * dx + (p.y - a.y) * dy) / lenSq))
    val projX = a.x + t * dx
    val projY = a.y + t * dy
    return hypot(p.x - projX, p.y - projY)
  }
}
