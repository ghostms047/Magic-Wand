package com.example.engine

import com.example.model.MasteryLevel
import com.example.model.Spell
import com.example.model.SpellProgress

object MasteryCalculator {

  fun computeMastery(spell: Spell, successfulPractices: Int, averageAccuracy: Int): MasteryLevel {
    return when {
      successfulPractices <= 0 -> MasteryLevel.LOCKED
      successfulPractices < spell.requiredPractice -> MasteryLevel.LEARNING
      successfulPractices >= spell.requiredPractice + 8 && averageAccuracy >= 85 -> MasteryLevel.MASTERED
      successfulPractices >= spell.requiredPractice + 4 && averageAccuracy >= 75 -> MasteryLevel.SKILLED
      else -> MasteryLevel.LEARNED
    }
  }

  fun recordPracticeAttempt(
    spell: Spell,
    current: SpellProgress,
    isSuccess: Boolean,
    accuracyPercent: Int
  ): SpellProgress {
    val newAttempts = current.totalAttempts + 1
    val newAccuracySum = current.totalAccuracySum + accuracyPercent
    val newSuccessful = if (isSuccess) current.successfulPractices + 1 else current.successfulPractices
    val newBest = if (isSuccess) maxOf(current.bestAccuracy, accuracyPercent) else current.bestAccuracy
    val avg = newAccuracySum / newAttempts
    val nowUnlocked = current.unlocked || newSuccessful >= spell.requiredPractice
    val mastery = computeMastery(spell, newSuccessful, avg)

    return current.copy(
      successfulPractices = newSuccessful,
      totalAttempts = newAttempts,
      totalAccuracySum = newAccuracySum,
      bestAccuracy = newBest,
      unlocked = nowUnlocked,
      masteryLevel = if (nowUnlocked && mastery == MasteryLevel.LEARNING) MasteryLevel.LEARNED else mastery
    )
  }

  fun nextMilestoneTarget(spell: Spell, progress: SpellProgress): Int {
    return when (progress.masteryLevel) {
      MasteryLevel.LOCKED, MasteryLevel.LEARNING -> spell.requiredPractice
      MasteryLevel.LEARNED -> spell.requiredPractice + 4
      MasteryLevel.SKILLED -> spell.requiredPractice + 8
      MasteryLevel.MASTERED -> progress.successfulPractices
    }
  }
}
